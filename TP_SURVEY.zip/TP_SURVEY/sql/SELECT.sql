-- [admin] 패키지
SELECT COUNT(*) FROM ADMIN_ID_INFO;
SELECT * FROM ADMIN_ID_INFO;

-- [survey] 패키지
DESC BASIC_SURVEY_INFO;
SELECT COUNT(*) FROM BASIC_SURVEY_INFO;
SELECT * FROM BASIC_SURVEY_INFO;

SELECT COUNT(*) FROM ADD_SURVEY_INFO;
SELECT * FROM ADD_SURVEY_INFO;

SELECT COUNT(*) FROM ADD_INFO_COLLECT;
SELECT * FROM ADD_INFO_COLLECT;

SELECT COUNT(*) FROM ID_CERTIFICATION;
SELECT * FROM ID_CERTIFICATION;

-- [composition(survey_new)] 패키지
SELECT COUNT(*) FROM QUESTION_INFO;
SELECT * FROM QUESTION_INFO ORDER BY SURVEY_ID_NUM, QUESTION_ID_NUM;

SELECT COUNT(*) FROM CHOICE_INFO;
SELECT * FROM CHOICE_INFO;

SELECT COUNT(*) FROM MULTIPLE_CHOICE;
SELECT * FROM MULTIPLE_CHOICE ORDER BY SURVEY_ID_NUM;

SELECT COUNT(*) FROM SUBJECTIVE_CHOICE;
SELECT * FROM SUBJECTIVE_CHOICE ORDER BY SURVEY_ID_NUM;

SELECT COUNT(*) FROM MATRIX_CHOICE;
SELECT * FROM MATRIX_CHOICE ORDER BY SURVEY_ID_NUM, QUESTION_ID_NUM;

SELECT COUNT(*) FROM MATRIX_QUESTION;
SELECT * FROM MATRIX_QUESTION ORDER BY SURVEY_ID_NUM, QUESTION_ID_NUM;

-- [userResponse] 패키지
SELECT COUNT(*) FROM USER_INFO;
SELECT COUNT(*) FROM USER_SURVEY;

-- test
insert into basic_survey_info 
		 (
		 	survey_id_num, 
		 	survey_type, 
		 	admin_title, 
		 	survey_start_date, 
		 	survey_end_date,
		 	admin_id,
		 	title_input,
		 	survey_notice,
		 	attached_image,
		 	survey_end_notice,
		 	survey_creation_date,
		 	last_modify_date,
		 	is_last_modify,
		 	consent_procedure_count,
		 	consent_notice_1,
		 	consent_notice_2,
		 	is_limit_respondent,
		 	limit_respondent_num
		 )
		 values
		 (
		 	1, 1, 1, TO_DATE('2022-01-01', 'YYYY-MM-DD'), TO_DATE('2022-01-03', 'YYYY-MM-DD'),
            1, 1, 1, 1, 1,
            TO_DATE('2022-01-01', 'YYYY-MM-DD'), TO_DATE('2022-01-02', 'YYYY-MM-DD'), 1, 1, 1,
            1, 1, 1
		 )