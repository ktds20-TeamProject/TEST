package com.main.java.survey.vo;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component("matrixChoiceVO")
public class MatrixChoiceVO {//표형 보기등록

	private String question_id_num; //질문식별번호
	private String survey_id_num; //설문 식별번호
	private String matrix_choice_num; //표형 보기 입력번호
	private String matrix_choice_contents; //표형 보기 입력내용
	
}
