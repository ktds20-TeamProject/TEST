package com.main.java.admin.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.main.java.admin.vo.AdminVO;


public interface AdminController {

	//로그인
	public ModelAndView login(@ModelAttribute("admin") AdminVO admin,
            RedirectAttributes rAttr,
            HttpServletRequest request, HttpServletResponse response) throws Exception;
	//로그아웃
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception;
	//회원가입
	public ModelAndView join(@ModelAttribute("admin") AdminVO adminVO,RedirectAttributes rAttr, HttpServletRequest request, HttpServletResponse response) throws Exception;
	//아이디 중복확인
	public int idDuplicated(@RequestParam("adminId") String adminId);	
	//비밀번호 체크
	public ModelAndView pwCheck (@ModelAttribute("admin") AdminVO admin,
			RedirectAttributes rAttr, 
            HttpServletRequest request, HttpServletResponse response) throws Exception;
	//회원정보 수정
	public ModelAndView adminUpdate (@ModelAttribute("admin") AdminVO admin, RedirectAttributes rAttr, HttpServletRequest request, HttpServletResponse response) throws Exception;
	//탈퇴시 비밀번호 체크 (기능)
	public ModelAndView deleteAdmin (@ModelAttribute("admin") AdminVO admin,
			RedirectAttributes rAttr, 
            HttpServletRequest request, HttpServletResponse response) throws Exception;
	//아이디 찾기(기능)
	public ModelAndView admin_find_id(@ModelAttribute("admin") AdminVO admin, HttpServletRequest request, HttpServletResponse response) throws Exception;
	//비밀번호 찾기 (기능)
	public ModelAndView findPw(@ModelAttribute("admin") AdminVO admin,
			RedirectAttributes rAttr, 
            HttpServletRequest request, HttpServletResponse response) throws Exception;	
	//관리자 설문 관리 리스트
	public ModelAndView admin_list(HttpServletRequest request, HttpServletResponse response) throws Exception;	
}
