package com.main.java.admin.vo;

import java.util.Date;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@Component("adminVO")
public class AdminVO {//관리자 개인정보
	
	private int adminNum; //관리자 번호
	private String adminId; //관리자 아이디
	private String password; //관리자 비밀번호
	private String name; //관리자 이름
	private String position; //직급
	private String phoneNum1; //핸드폰 번호 앞자리
	private String phoneNum2; //핸드폰 번호 중간자리
	private String phoneNum3; //핸드폰 번호 뒷자리
	private Date joinDate; //가입일자
	private String email1; //이메일 앞 주소
	private String email2; //이메일 뒷 주소
	
	public AdminVO() {}
	public AdminVO(String adminId, String password, String name, String position,
					String phoneNum1, String phoneNum2, String phoneNum3, 
					String email1, String email2) {
		this.adminId=adminId;
		this.password=password;
		this.name=name;
		this.position=position;
		this.phoneNum1=phoneNum1;
		this.phoneNum2=phoneNum2;
		this.phoneNum3=phoneNum3;
		this.email1=email1;
		this.email2=email2;
	}
	public AdminVO(String adminId) {
		this.adminId=adminId;
	}
}

