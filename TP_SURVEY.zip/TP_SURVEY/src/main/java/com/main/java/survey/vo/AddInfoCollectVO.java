package com.main.java.survey.vo;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Component("addInfoCollectVO")
public class AddInfoCollectVO     // 추가정보 수집 
{
	private String survey_id_num; // 설문 식별번호
	private String gender;        // 성별
	private String age;           // 나이
	private String education;     // 학력
	private String marriage;      // 결혼
	private String salary;        // 연봉
	private String religion;      // 종교
}