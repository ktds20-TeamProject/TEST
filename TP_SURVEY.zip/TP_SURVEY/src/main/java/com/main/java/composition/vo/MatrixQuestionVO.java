package com.main.java.composition.vo;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Component("MatrixQuestionVO")
public class MatrixQuestionVO 
{
    private String survey_id_num;                                     // 설문 식별번호
    private List<String> page_num;                                    // 페이지 번호   : 페이지가 여러 개이다.
    private Map<Integer, List<String>> question_id_num;               // 질문 식별번호 : 페이지가 여러 개이며, 페이지별 질문은 여러 개이다.
	private Map<Integer, Map<Integer, List<String>>> matrix_num;      // 표형 질문번호 : 페이지가 여러 개이며, 페이지별 질문은 여러 개이며, 질문별 표형 질문번호는 여러 개이다.
	private Map<Integer, Map<Integer, List<String>>> matrix_contents; // 표형 질문내용 : 페이지가 여러 개이며, 페이지별 질문은 여러 개이며, 질문별 표형 질문내용은 여러 개이다.
}