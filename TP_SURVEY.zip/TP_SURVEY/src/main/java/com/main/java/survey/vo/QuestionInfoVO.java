package com.main.java.survey.vo;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component("questionInfoVO")
public class QuestionInfoVO {//질문정보

	private String question_id_num; //질문식별번호
	private String survey_id_num; //설문 식별번호
	private String page_num; //페이지번호
	private String question_type; //질문유형
	private String question_contents; //질문내용
	private String is_required_response; //필수답변여부
	private String choice_description; //보기설명
}
