package com.main.java.userResponse.vo;

import java.util.Date;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@Component("totalUserSurveyVO")
public class TotalUserSurveyVO {

	private String survey_id_num;
	private String question_id_num;

	// 질문 개별 응답 수, 퍼센트
	private int multiple_count;
	private int multiple_percent;

	private int matrix_count;
	private int matrix_percent;

	// 주관식
	private String user_name;
	private String user_num;
	private String respondent_subjective;

}
