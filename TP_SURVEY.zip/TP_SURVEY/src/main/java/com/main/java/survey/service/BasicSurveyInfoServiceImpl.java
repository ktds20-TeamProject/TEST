package com.main.java.survey.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.main.java.survey.dao.BasicSurveyInfoDAO;
import com.main.java.survey.vo.BasicSurveyInfoVO;



@Service("BasicSurveyInfoService")
@Transactional(propagation = Propagation.REQUIRED)
public class BasicSurveyInfoServiceImpl implements BasicSurveyInfoService 
{
	@Autowired
	private BasicSurveyInfoDAO basicSurveyInfoDAO;
	
	@Override
	public List listBasicSurveyInfo() throws DataAccessException 
	{
		List basicSurveyInfoList = null;
		basicSurveyInfoList = basicSurveyInfoDAO.selectAllBasicSurveyInfoList();
		return basicSurveyInfoList;
	}
	
	@Override
	public int addBasicSurveyInfo(BasicSurveyInfoVO basicsurveyinfoVO) throws DataAccessException 
	{
		return basicSurveyInfoDAO.insertBasicSurveyInfo(basicsurveyinfoVO);
	}
//
//	@Override
//	public int removeMember(String id) throws DataAccessException {
//		return memberDAO.deleteMember(id);
//	}
//	
//	@Override
//	public SurveyVO login(SurveyVO memberVO) throws Exception{
//		return memberDAO.loginById(memberVO);
//	}

}
