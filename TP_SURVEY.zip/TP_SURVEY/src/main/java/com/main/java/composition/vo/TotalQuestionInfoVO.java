package com.main.java.composition.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import org.springframework.stereotype.Component;

@Getter
@Setter
@ToString
@Component("totalQuestionInfoVO")
public class TotalQuestionInfoVO {//질문정보

	private String question_id_num; //질문식별번호
	private String survey_id_num; //설문 식별번호
	private String page_num; //페이지번호
	private String question_type; //질문유형
	private String question_contents; //질문내용
	private String is_required_response; //필수답변여부
	private String choice_description; //보기설명
	
	
	//통계 - 객관식 출력용 추가 변수
	private int choice_count; //forEach End속성에 사용할 마지막 인덱스
	private String is_other_choice;
	private String min_multiple_choice;
	private String max_multiple_choice;
	
	//통계 - 주관식 출력용 추가 변수
	private int subjective_count; //forEach End속성에 사용할 마지막 인덱스
	
	//통계 - 표형 출력용 추가 변수
	private int matrix_q_count; //forEach End속성에 사용할 마지막 인덱스
	private int matrix_c_count; //forEach End속성에 사용할 마지막 인덱스
	
	//통계 - 질문별 총 응답자 수
	private int count;
}
