package com.main.java.survey.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.main.java.survey.vo.BasicSurveyInfoVO;


public interface BasicSurveyInfoDAO 
{
	public List selectAllBasicSurveyInfoList() throws DataAccessException;
	public int insertBasicSurveyInfo(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException;
	//	public int deleteBasicSurveyInfo(String id) throws DataAccessException;
	//	public BasicSurveyInfoVO loginById(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException;
}
