package com.main.java.survey.dao;

import org.springframework.dao.DataAccessException;

import com.main.java.survey.vo.ChoiceInfoVO;
import com.main.java.survey.vo.MatrixChoiceVO;
import com.main.java.survey.vo.MatrixQuestionVO;
import com.main.java.survey.vo.MultipleChoiceVO;
import com.main.java.survey.vo.QuestionInfoVO;
import com.main.java.survey.vo.SubjectiveChoiceVO;
import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.AddressEmailVO;
import com.main.java.survey.vo.AddressInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;



public interface SurveyDAO {
	
	public int insertAddInfoCollect(AddInfoCollectVO addInfoCollect) throws DataAccessException;
	public int insertAddSurveyInfo(AddSurveyInfoVO addSurveyInfo) throws DataAccessException;
	public int insertBasicSurveyInfo(BasicSurveyInfoVO basicSurveyInfo) throws DataAccessException;
	public int insertIdCertification(IdCertificationVO idCertification) throws DataAccessException;
	public int insertChoiceInfo(ChoiceInfoVO choiceInfo) throws DataAccessException;
	public int insertMatrixChoice(MatrixChoiceVO matrixChoice) throws DataAccessException;
	public int insertMatrixQuestion(MatrixQuestionVO matrixQuestion) throws DataAccessException;
	public int insertMultipleChoice(MultipleChoiceVO multipleChoice) throws DataAccessException;
	public int insertQuestionInfo(QuestionInfoVO questionInfo) throws DataAccessException;
	public int insertSubjectiveChoice(SubjectiveChoiceVO subjectiveChoice) throws DataAccessException;
	public int selectLastSurveyNum(BasicSurveyInfoVO basicSurveyInfo) throws DataAccessException;


	
	
	
	
	public BasicSurveyInfoVO surveyInfoView(String survey_id_num) throws DataAccessException; //설문 기본 정보 조회
	public int deleteAddressInfo (String survey_id_num) throws DataAccessException;  //주소록 기존 데이터 삭제
	public int insertAddressInfo (AddressInfoVO vo) throws DataAccessException; //주소록 데이터 삽입
	public int deleteAddressEmail (String survey_id_num) throws DataAccessException; //이메일 기존 데이터 삭제
	public int insertAddressEmail (AddressEmailVO vo) throws DataAccessException; //이메일 데이터 삽입




}
