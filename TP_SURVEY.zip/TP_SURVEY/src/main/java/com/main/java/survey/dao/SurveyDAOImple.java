package com.main.java.survey.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.main.java.survey.vo.ChoiceInfoVO;
import com.main.java.survey.vo.MatrixChoiceVO;
import com.main.java.survey.vo.MatrixQuestionVO;
import com.main.java.survey.vo.MultipleChoiceVO;
import com.main.java.survey.vo.QuestionInfoVO;
import com.main.java.survey.vo.SubjectiveChoiceVO;
import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.AddressEmailVO;
import com.main.java.survey.vo.AddressInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;


@Repository("SurveyDAO")
public class SurveyDAOImple implements SurveyDAO{
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public int insertAddInfoCollect(AddInfoCollectVO addInfoCollect) throws DataAccessException {
		int result = sqlSession.insert("mapper.survey.Survey.insertAddInfoCollect", addInfoCollect);
		return result;
	}

	@Override
	public int insertAddSurveyInfo(AddSurveyInfoVO addSurveyInfo) throws DataAccessException {
		int result = sqlSession.insert("mapper.survey.Survey.insertAddSurveyInfo", addSurveyInfo);
		return result;
	}

	@Override
	public int insertBasicSurveyInfo(BasicSurveyInfoVO basicSurveyInfo) throws DataAccessException {
		
		int result = sqlSession.insert("mapper.survey.Survey.insertBasicSurveyInfo", basicSurveyInfo);
		return result;
	}

	@Override
	public int insertIdCertification(IdCertificationVO idCertification) throws DataAccessException {
		int result = sqlSession.insert("mapper.survey.Survey.insertIdCertification", idCertification);
		return result;
	}

	@Override
	public int insertChoiceInfo(ChoiceInfoVO choiceInfo) throws DataAccessException {
		int result = sqlSession.insert("mapper.composition.composition.insertChoiceInfo", choiceInfo);
		return result;
	}

	@Override
	public int insertMatrixChoice(MatrixChoiceVO matrixChoice) throws DataAccessException {
		int result = sqlSession.insert("mapper.composition.composition.insertMatrixChoice", matrixChoice);
		return result;
	}

	@Override
	public int insertMatrixQuestion(MatrixQuestionVO matrixQuestion) throws DataAccessException {
		int result = sqlSession.insert("mapper.composition.composition.insertMatrixQuestion", matrixQuestion);
		return result;
	}

	@Override
	public int insertMultipleChoice(MultipleChoiceVO multipleChoice) throws DataAccessException {
		int result = sqlSession.insert("mapper.composition.composition.insertMultipleChoice", multipleChoice);
		return result;
	}

	@Override
	public int insertQuestionInfo(QuestionInfoVO questionInfo) throws DataAccessException {
		int result = sqlSession.insert("mapper.composition.composition.insertQuestionInfo", questionInfo);
		return result;
	}

	@Override
	public int insertSubjectiveChoice(SubjectiveChoiceVO subjectiveChoice) throws DataAccessException {
		int result = sqlSession.insert("mapper.composition.composition.insertSubjectiveChoice", subjectiveChoice);
		return result;
	}
	
	//최신 문서번호(Max survey num)
	@Override
	public int selectLastSurveyNum(BasicSurveyInfoVO basicSurveyInfo) throws DataAccessException {
		int result = sqlSession.selectOne("mapper.survey.Survey.selectLastSurveyNum", basicSurveyInfo);
		return result;
	}

	
	
	
	
	
	
	
	
	
	
	
	 //설문 기본 정보 조회
		@Override
		public BasicSurveyInfoVO surveyInfoView(String survey_id_num) throws DataAccessException {
			BasicSurveyInfoVO vo = sqlSession.selectOne("mapper.survey.surveyInfoView", survey_id_num);
			return vo;
		}
		
		//주소록 기존 데이터 삭제
		@Override
		public int deleteAddressInfo (String survey_id_num) throws DataAccessException {
			int result = sqlSession.delete("mapper.survey.deleteAddressInfo", survey_id_num);
			return result;
		}
		
		//주소록 데이터 삽입
		@Override
		public int insertAddressInfo (AddressInfoVO vo) throws DataAccessException {
			int result = sqlSession.insert("mapper.survey.insertAddressInfo", vo);
			return result;
		}
		
		//이메일 기존 데이터 삭제
		@Override
		public int deleteAddressEmail (String survey_id_num) throws DataAccessException {
			int result = sqlSession.delete("mapper.survey.deleteAddressEmail", survey_id_num);
			return result;
		}
		
		//이메일 데이터 삽입
		@Override
		public int insertAddressEmail (AddressEmailVO vo) throws DataAccessException {
			int result = sqlSession.insert("mapper.survey.insertAddressEmail", vo);
			return result;
		}
	
}
