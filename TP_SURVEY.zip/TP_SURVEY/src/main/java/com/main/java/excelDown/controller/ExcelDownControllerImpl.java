package com.main.java.excelDown.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.main.java.excelDown.service.ExcelDownService;
import com.main.java.excelDown.vo.ExcelDownVO;

@Controller("ExcelDownController")
public class ExcelDownControllerImpl implements ExcelDownController 
{
	@Autowired
	private ExcelDownService excelDownService;
	@Autowired 
	private ExcelDownVO excelDownVO;
	
	// 파일 경로 및 이름 지정
	public static String filePath = "C:\\Users\\User\\Desktop\\YHExcelFile";
	public static String fileName = "Success to download Excel.xlsx";

	@RequestMapping(value = "/excelDown1.do", method = { RequestMethod.GET, RequestMethod.POST })
    public void excel_down(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		
		// Workbook(엑셀) 및 시트 생성
		// Workbook wb = new HSSFWorkbook();
        Workbook wb = new XSSFWorkbook();
        Sheet sheet = wb.createSheet("응답결과");
        
        // 행, 셀 생성
        Row row = null;
        Cell cell = null;
        int rowNo = 0;
        
		// 게시판 목록조회 
    	List<ExcelDownVO> rowList = new ArrayList<ExcelDownVO>();
    	rowList = excelDownService.selectAllResult();
    	
    	// 셀 넓이 설정
    	sheet.setDefaultColumnWidth(5); // sheet 전체 기본 넓이
    	sheet.setColumnWidth(1, 5000); // 특정 셀 넓이 설정 => 1=B cell 2100=7.63
    	sheet.setColumnWidth(2, 10000); // 7=H 3400=12.63
    	sheet.setColumnWidth(3, 5800);
    	sheet.setColumnWidth(4, 4200);
    	sheet.setColumnWidth(5, 4200);

    	// 폰트 설정
    	Font headFont = wb.createFont();
    	headFont.setFontName("맑은고딕"); // 글꼴
    	headFont.setFontHeight((short)240); // 글자 크기 -> 260 = 13point
    	headFont.setBold(true); // 두껍게
    	
        // 테이블 헤더용 스타일
        CellStyle headStyle = wb.createCellStyle();
        // 가는 경계선 지정
        headStyle.setBorderTop(BorderStyle.THIN);
        headStyle.setBorderBottom(BorderStyle.THIN);
        headStyle.setBorderLeft(BorderStyle.THIN);
        headStyle.setBorderRight(BorderStyle.THIN);
        // 배경색 지정 = 노란색
        headStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
        headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        // 가운데 정렬
        headStyle.setAlignment(HorizontalAlignment.CENTER);
        headStyle.setFont(headFont); // 위에 선언한 폰트 적용

 //     cell.setCellStyle(headStyle);
        
        // Header 생성
        row = (sheet).createRow(rowNo++);
        cell = row.createCell(0);
        cell.setCellStyle(headStyle);
        cell.setCellValue("No");
        cell = row.createCell(1);
        cell.setCellStyle(headStyle);
        cell.setCellValue("제목");
        cell = row.createCell(2);
        cell.setCellStyle(headStyle);
        cell.setCellValue("진행기간");
        cell = row.createCell(3);
        cell.setCellStyle(headStyle);
        cell.setCellValue("응답수-문자/알림톡");
        cell = row.createCell(4);
        cell.setCellStyle(headStyle);
        cell.setCellValue("응답수-QR코드");
        cell = row.createCell(5);
        cell.setCellStyle(headStyle);
        cell.setCellValue("응답수-총합");

        // body 테두리 스타일 지정(BorderStyle.THIN = 가는선)
        CellStyle bodyStyle = wb.createCellStyle();
        bodyStyle.setBorderTop(BorderStyle.THIN);
        bodyStyle.setBorderBottom(BorderStyle.THIN);
        bodyStyle.setBorderLeft(BorderStyle.THIN);
        bodyStyle.setBorderRight(BorderStyle.THIN);
        // 가운데 정렬
        bodyStyle.setAlignment(HorizontalAlignment.CENTER);
        
        // Body 생성(행, 셀 적용)
        for(ExcelDownVO vo : rowList) {
            row = sheet.createRow(rowNo++);
            cell = row.createCell(0);
            cell.setCellStyle(bodyStyle);
            cell.setCellValue(vo.getExcelDown_num());
            cell = row.createCell(1);
            cell.setCellStyle(bodyStyle);
            cell.setCellValue(vo.getExcelDown_title());
            cell = row.createCell(2);
            cell.setCellStyle(bodyStyle);
            cell.setCellValue(vo.getProgress_date());
            cell = row.createCell(3);
            cell.setCellStyle(bodyStyle);
            cell.setCellValue(vo.getAnswer_text());
            cell = row.createCell(4);
            cell.setCellStyle(bodyStyle);
            cell.setCellValue(vo.getAnswer_qr());
            cell = row.createCell(5);
            cell.setCellStyle(bodyStyle);
            cell.setCellValue(vo.getAnswer_total());
        }
        
        // 엑셀 파일 저장
        FileOutputStream out = new FileOutputStream(new File(filePath, fileName));
        wb.write(out);
        
    }
}
