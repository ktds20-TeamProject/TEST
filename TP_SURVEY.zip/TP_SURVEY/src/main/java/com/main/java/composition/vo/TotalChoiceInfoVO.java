package com.main.java.composition.vo;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Component("totalChoiceInfoVO")
public class TotalChoiceInfoVO {

	//기본 식별번호
	private String survey_id_num;
	private String question_id_num;
	private String page_num;
	
	//객관식
	private String choice_num;
	private String choice_contents;
	private String choice_file_path;
	
	//주관식
	private String is_duplicate;
	
	//객관식 표형
	private String matrix_num;
	private String matrix_contents;
	private String matrix_choice_num;
	private String matrix_choice_contents;
	

	//유저답변 - 객관식 보기 최대갯수
	private int maxChoiceNum;
	
	//유저 답변 - 표형 문제 최대갯수 / 표형 보기 최대갯수
	private int maxMatrixQuestionNum;
	private int maxMatrixChoiceNum;
	
	//객관식 문항 라디오 value
	private int choiceNum;
	
	//표형문항 라디오 value
	private int matrixChoiceNum;
	
	public TotalChoiceInfoVO() {}
	
	//객관식 보기
	public TotalChoiceInfoVO(String survey_id_num, String question_id_num, String choice_num,
			String choice_contents, String choice_file_path) {
		this.survey_id_num=survey_id_num;
		this.question_id_num=question_id_num;
		this.choice_num=choice_num;
		this.choice_contents=choice_contents;
		this.choice_file_path=choice_file_path;
	}
	//주관식
	public TotalChoiceInfoVO(String survey_id_num, String question_id_num, String is_duplicate) {
		this.survey_id_num=survey_id_num;
		this.question_id_num=question_id_num;
		this.is_duplicate=is_duplicate;
	}
	//객관식 표형 질문
	public TotalChoiceInfoVO(String survey_id_num, String question_id_num, String matrix_num, 
			String matrix_contents) {
		this.survey_id_num=survey_id_num;
		this.question_id_num=question_id_num;
		this.matrix_num=matrix_num;
		this.matrix_contents=matrix_contents;
	}
	//객관식 표형 보기
	public TotalChoiceInfoVO(String survey_id_num, String question_id_num, String matrix_choice_num, 
			String matrix_choice_contents, int i) {
		this.survey_id_num=survey_id_num;
		this.question_id_num=question_id_num;
		this.matrix_choice_num=matrix_choice_num;
		this.matrix_choice_contents=matrix_choice_contents;
	}
	
}
