package com.main.java.survey.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.main.java.survey.vo.BasicSurveyInfoVO;


public interface BasicSurveyInfoController {

//	public ModelAndView InsertSurveyInfo(@ModelAttribute("survey") SurveyVO survey,
//			RedirectAttributes rAttr,
//			HttpServletRequest request, HttpServletResponse response) throws Exception;
	public ModelAndView AdminMain(HttpServletRequest request, HttpServletResponse response) throws Exception;
	public ModelAndView addBasicSurveyInfo(@ModelAttribute("info") BasicSurveyInfoVO basicsurveyinfoVO,HttpServletRequest request, HttpServletResponse response) throws Exception;
//	public ModelAndView removeBasicSurveyInfo(@RequestParam("id") String id, HttpServletRequest request, HttpServletResponse response) throws Exception;
//	public ModelAndView login(@ModelAttribute("survey") SurveyVO survey,
//                              RedirectAttributes rAttr,
//                              HttpServletRequest request, HttpServletResponse response) throws Exception;
//	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception;
}