package com.main.java.composition.vo;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Component("SubjectiveChoiceVO")
public class SubjectiveChoiceVO 
{
	private String survey_id_num;          // 설문 식별번호
	private List<String> page_num;         // 페이지 번호
	private Map<Integer, List<String>> question_id_num;  // 질문 식별번호
	private Map<Integer, List<String>> is_personal_info; // 개인정보 처리 여부 : 페이지가 여러 개이며, 페이지별 질문은 여러 개이며, 질문별 1개 있다. 
	private Map<Integer, List<String>> is_duplicate;     // 중복값 허용 여부
}