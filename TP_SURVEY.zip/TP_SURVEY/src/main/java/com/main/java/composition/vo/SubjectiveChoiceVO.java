package com.main.java.composition.vo;

import java.util.List;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Component("SubjectiveChoiceVO")
public class SubjectiveChoiceVO 
{
	private int survey_id_num;             // 설문 식별번호
	private List<String> question_id_num;  // 질문 식별번호
	private List<String> is_personal_info; // 개인정보 처리 여부 : 페이지가 여러 개이며, 페이지별 질문은 여러 개이며, 질문별 1개 있다. 
	private List<String> is_duplicate;     // 중복값 허용 여부
}