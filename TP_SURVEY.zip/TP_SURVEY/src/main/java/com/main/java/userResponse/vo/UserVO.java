package com.main.java.userResponse.vo;

import java.sql.Date;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@Component("userVO")
public class UserVO {
	
	private String user_num; //응답자 식별번호
	private String survey_id_num; //설문 식별번호
	private String question_id_num; //질문 식별번호
	private String matrix_num; //표형 질문번호
	private String respondent_multiple; //질문 응답번호
	private String respondent_subjective; //질문 응답내용
	private Date respondent_date; //응답일자
	private String other_contents; //기타 응답내용
	
	

}
