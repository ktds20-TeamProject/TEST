package com.main.java.composition.service;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;

public interface SurveyQuestionCompoService 
{
    // [survey] 패키지
    public int addBasicSurveyInfo(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException;
    public int addAddSurveyInfo(AddSurveyInfoVO addSurveyInfoVO) throws DataAccessException;
    public int addIdCertification(IdCertificationVO idCertificationVO) throws DataAccessException;
    public int addAddInfoCollect(AddInfoCollectVO addInfoCollectVO) throws DataAccessException;
	
    // [composition] 패키지
    public int addQuestionInfo(Map<String, Object> question_info_map, int page_count, List<Integer> question_counts) throws DataAccessException;
    public int addChoiceInfo(Map<String, Object> choice_info_map, int page_count, List<Integer> question_counts, List<Integer> choice_counts) throws DataAccessException;
    public int addMultipleChoice(Map<String, Object> multiple_choice_map, int page_count, List<Integer> question_counts) throws DataAccessException;
    public int addSubjectiveChoice(Map<String, Object> subjective_choice_map, int page_count, List<Integer> question_counts) throws DataAccessException;
    public int addMatrixQuestion(Map<String, Object> matrix_question_map, int page_count, List<Integer> question_counts, List<Integer> matrix_questions) throws DataAccessException;
	public int addMatrixChoice(Map<String, Object> matrix_choice_map, int page_count, List<Integer> question_counts, List<Integer> matrix_choices) throws DataAccessException;
}
