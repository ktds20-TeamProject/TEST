package com.main.java.composition.service;

import org.springframework.dao.DataAccessException;

import com.main.java.composition.vo.ChoiceInfoVO;
import com.main.java.composition.vo.MatrixChoiceVO;
import com.main.java.composition.vo.MatrixQuestionVO;
import com.main.java.composition.vo.MultipleChoiceVO;
import com.main.java.composition.vo.QuestionInfoVO;
import com.main.java.composition.vo.SubjectiveChoiceVO;
import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;

public interface SurveyQuestionCompoService 
{
    public int addBasicSurveyInfo(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException;
    public int addAddSurveyInfo(AddSurveyInfoVO addSurveyInfoVO) throws DataAccessException;
    public int addIdCertification(IdCertificationVO idCertificationVO) throws DataAccessException;
    public int addAddInfoCollect(AddInfoCollectVO addInfoCollectVO) throws DataAccessException;
	public int addChoiceInfo(ChoiceInfoVO choiceInfoVO) throws DataAccessException;
	public int addMatrixChoice(MatrixChoiceVO matrixChoiceVO) throws DataAccessException;
	public int addMatrixQuestion(MatrixQuestionVO matrixQuestionVO) throws DataAccessException;
	public int addMultipleChoice(MultipleChoiceVO multipleChoiceVO) throws DataAccessException;
	public int addQuestionInfo(QuestionInfoVO questionInfoVO) throws DataAccessException;
	public int addSubjectiveChoice(SubjectiveChoiceVO subjectiveChoiceVO) throws DataAccessException;
}
