package com.main.java.composition.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.main.java.composition.vo.ChoiceInfoVO;
import com.main.java.composition.vo.MatrixChoiceVO;
import com.main.java.composition.vo.MatrixQuestionVO;
import com.main.java.composition.vo.MultipleChoiceVO;
import com.main.java.composition.vo.QuestionInfoVO;
import com.main.java.composition.vo.SubjectiveChoiceVO;
import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;

public interface SurveyQuestionCompoService 
{
    // [survey] 패키지
    public int addBasicSurveyInfo(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException;
    public int addAddSurveyInfo(AddSurveyInfoVO addSurveyInfoVO) throws DataAccessException;
    public int addIdCertification(IdCertificationVO idCertificationVO) throws DataAccessException;
    public int addAddInfoCollect(AddInfoCollectVO addInfoCollectVO) throws DataAccessException;
	
    // [composition] 패키지
    public int addChoiceInfo(ChoiceInfoVO choiceInfoVO, int page_count, List<Integer> question_count) throws DataAccessException;
	public int addMatrixChoice(MatrixChoiceVO matrixChoiceVO, int page_count, List<Integer> question_count) throws DataAccessException;
	public int addMatrixQuestion(MatrixQuestionVO matrixQuestionVO, int page_count, List<Integer> question_count) throws DataAccessException;
	public int addMultipleChoice(MultipleChoiceVO multipleChoiceVO, int page_count) throws DataAccessException;
	public int addQuestionInfo(QuestionInfoVO questionInfoVO, int page_count) throws DataAccessException;
	public int addSubjectiveChoice(SubjectiveChoiceVO subjectiveChoiceVO, int page_count) throws DataAccessException;
}
