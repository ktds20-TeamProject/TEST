package com.main.java.composition.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;

@Repository("compositionDAO")
public class SurveyQuestionCompoDAOImpl implements SurveyQuestionCompoDAO 
{
    /* 의존성 주입 */
    
	@Autowired
	private SqlSession sqlSession;
	
	//----------------------------------------------------------------------------
	
	/* [survey] 패키지 */
	
	@Override
    public int insertBasicSurveyInfo(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException
    {
        int result = sqlSession.insert("mapper.survey.insertBasicSurveyInfo", basicSurveyInfoVO);
        return result;
    }
	
	@Override
    public int insertAddSurveyInfo(AddSurveyInfoVO addSurveyInfoVO) throws DataAccessException
    {
        int result = sqlSession.insert("mapper.survey.insertAddSurveyInfo", addSurveyInfoVO);
        return result;
    }
	
	@Override
    public int insertIdCertification(IdCertificationVO idCertificationVO) throws DataAccessException
    {
        int result = sqlSession.insert("mapper.survey.insertIdCertification", idCertificationVO);
        return result;
    }
	
	@Override
    public int insertAddInfoCollect(AddInfoCollectVO addInfoCollectVO) throws DataAccessException
    {
        int result = sqlSession.insert("mapper.survey.insertAddInfoCollect", addInfoCollectVO);
        return result;
    }
	
	//----------------------------------------------------------------------------
	
	/* [composition(new survey)] 패키지 */
	
    @Override
    public int insertQuestionInfo(Map<String, Object> question_info_map, int page_count) throws DataAccessException
    {
        
        /* 현재 작업 중 */
        
        int data_rows_affected_by_SqlSession;
        data_rows_affected_by_SqlSession = sqlSession.insert("mapper.composition.insertQuestionInfo", question_info_map);
        return data_rows_affected_by_SqlSession;
    }
	
	@Override
	public int insertChoiceInfo(Map<String, Object> choice_info_map, int page_count, List<Integer> question_count) throws DataAccessException
	{
	    /* 현재 작업 중 */
	    
		int data_rows_affected_by_SqlSession = sqlSession.insert("mapper.composition.insertChoiceInfo", choice_info_map);
		return data_rows_affected_by_SqlSession;
	}
	
	@Override
	public int insertMatrixChoice(Map<String, Object> multiple_choice_map, int page_count, List<Integer> question_count) throws DataAccessException
	{
	    /* 현재 작업 중 */
	    
		int data_rows_affected_by_SqlSession = sqlSession.insert("mapper.composition.insertMatrixChoice", multiple_choice_map);
		return data_rows_affected_by_SqlSession;
	}
	
	@Override
	public int insertMatrixQuestion(Map<String, Object> subjective_choice_map, int page_count, List<Integer> question_count) throws DataAccessException
	{
	    /* 현재 작업 중 */
	    
		int data_rows_affected_by_SqlSession = sqlSession.insert("mapper.composition.insertMatrixQuestion", subjective_choice_map);
		return data_rows_affected_by_SqlSession;
	}
	
	@Override
	public int insertMultipleChoice(Map<String, Object> matrix_choice_map, int page_count) throws DataAccessException
	{
	    /* 현재 작업 중 */
	    
		int data_rows_affected_by_SqlSession = 0; // insert문 실행 후 그 결과로 추가됐거나 반영된 Data Row 의 개수
		data_rows_affected_by_SqlSession = sqlSession.insert("mapper.composition.insertMultipleChoice", matrix_choice_map);
		return data_rows_affected_by_SqlSession;
	}
	
	@Override
	public int insertSubjectiveChoice(Map<String, Object> matrix_question_map, int page_count) throws DataAccessException
	{
	    /* 현재 작업 중 */
	    
		int result = sqlSession.insert("mapper.composition.insertSubjectiveChoice", matrix_question_map);
		return result;
	}
}