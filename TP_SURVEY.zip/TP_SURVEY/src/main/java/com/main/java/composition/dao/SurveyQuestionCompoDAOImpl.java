package com.main.java.composition.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.main.java.composition.vo.ChoiceInfoVO;
import com.main.java.composition.vo.MatrixChoiceVO;
import com.main.java.composition.vo.MatrixQuestionVO;
import com.main.java.composition.vo.MultipleChoiceVO;
import com.main.java.composition.vo.QuestionInfoVO;
import com.main.java.composition.vo.SubjectiveChoiceVO;
import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;

@Repository("compositionDAO")
public class SurveyQuestionCompoDAOImpl implements SurveyQuestionCompoDAO 
{
	@Autowired
	private SqlSession sqlSession;
	
	@Override
    public int insertBasicSurveyInfo(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException
    {
        int result = sqlSession.insert("mapper.survey.insertBasicSurveyInfo", basicSurveyInfoVO);
        return result;
    }
	
	@Override
    public int insertAddSurveyInfo(AddSurveyInfoVO addSurveyInfoVO) throws DataAccessException
    {
        int result = sqlSession.insert("mapper.survey.insertAddSurveyInfo", addSurveyInfoVO);
        return result;
    }
	
	@Override
    public int insertIdCertification(IdCertificationVO idCertificationVO) throws DataAccessException
    {
        int result = sqlSession.insert("mapper.survey.insertIdCertification", idCertificationVO);
        return result;
    }
	
	@Override
    public int insertAddInfoCollect(AddInfoCollectVO addInfoCollectVO) throws DataAccessException
    {
        int result = sqlSession.insert("mapper.survey.insertAddInfoCollect", addInfoCollectVO);
        return result;
    }
	
	@Override
	public int insertChoiceInfo(ChoiceInfoVO choiceInfoVO, int page_count, List<Integer> question_count) throws DataAccessException
	{
	    /* 현재 작업 중 */
	    
		int result = sqlSession.insert("mapper.composition.insertChoiceInfo", choiceInfoVO);
		return result;
	}
	
	@Override
	public int insertMatrixChoice(MatrixChoiceVO matrixChoiceVO, int page_count, List<Integer> question_count) throws DataAccessException
	{
	    /* 현재 작업 중 */
	    
		int result = sqlSession.insert("mapper.composition.insertMatrixChoice", matrixChoiceVO);
		return result;
	}
	
	@Override
	public int insertMatrixQuestion(MatrixQuestionVO matrixQuestionVO, int page_count, List<Integer> question_count) throws DataAccessException
	{
	    /* 현재 작업 중 */
	    
		int result = sqlSession.insert("mapper.composition.insertMatrixQuestion", matrixQuestionVO);
		return result;
	}
	
	@Override
	public int insertMultipleChoice(MultipleChoiceVO multipleChoiceVO, int page_count) throws DataAccessException
	{
	    /* 현재 작업 중 */
	    
		int result = 0; // insert문 실행 후 그 결과로 추가됐거나 반영된 Data Row 의 개수
		
		for(int i = 0; i < page_count; i++)
		{
		    sqlSession.insert("mapper.composition.insertMultipleChoice", multipleChoiceVO);
		}
		
		return result;
	}
	
	@Override
	public int insertQuestionInfo(QuestionInfoVO questionInfoVO, int page_count) throws DataAccessException
	{
	    
	    /* 현재 작업 중 */
	    
	    int result = 0;
	    List<QuestionInfoVO> result_list = new ArrayList<>();
	    for(int i = 0; i < page_count; i++)
	    {
	        result_list.add(i, questionInfoVO);
	        sqlSession.insert("mapper.composition.insertQuestionInfo", result_list.get(i));
	    }
	    
		return result;
	}
	
	@Override
	public int insertSubjectiveChoice(SubjectiveChoiceVO subjectiveChoiceVO, int page_count) throws DataAccessException
	{
	    /* 현재 작업 중 */
	    
		int result = sqlSession.insert("mapper.composition.insertSubjectiveChoice", subjectiveChoiceVO);
		return result;
	}
}