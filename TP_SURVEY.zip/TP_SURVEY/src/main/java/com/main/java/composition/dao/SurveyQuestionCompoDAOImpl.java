package com.main.java.composition.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;

@Repository("compositionDAO")
public class SurveyQuestionCompoDAOImpl implements SurveyQuestionCompoDAO 
{
    /* 의존성 주입 */
    
	@Autowired
	private SqlSession sqlSession;
	
	// 카운트 변수 설정
	int question_count;
	int choice_count;
	int matrix_question_count;
	int matrix_choice_count;
	
	//----------------------------------------------------------------------------
	
	/* 기타 */
	
	@Override
	public Date getSurvey_creation_date()
	{
		Date survey_creation_date = null;
		survey_creation_date = sqlSession.selectOne("mapper.composition.getSurveyCreationDate");
		return survey_creation_date;
	}
	
	@Override
	public String getSurvey_id_num() throws DataAccessException
	{
		String survey_id_num = "";
		survey_id_num = sqlSession.selectOne("mapper.composition.getSurveyIdNum");
		return survey_id_num;
	}
	
	//----------------------------------------------------------------------------
	
	/* [survey] 패키지 */
	
	@Override
    public int insertBasicSurveyInfo(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException
    {
        int result = sqlSession.insert("mapper.survey.insertBasicSurveyInfo", basicSurveyInfoVO);
        return result;
    }
	
	@Override
    public int insertAddSurveyInfo(AddSurveyInfoVO addSurveyInfoVO) throws DataAccessException
    {
        int result = sqlSession.insert("mapper.survey.insertAddSurveyInfo", addSurveyInfoVO);
        return result;
    }
	
	@Override
    public int insertIdCertification(IdCertificationVO idCertificationVO) throws DataAccessException
    {
        int result = sqlSession.insert("mapper.survey.insertIdCertification", idCertificationVO);
        return result;
    }
	
	@Override
    public int insertAddInfoCollect(AddInfoCollectVO addInfoCollectVO) throws DataAccessException
    {
        int result = sqlSession.insert("mapper.survey.insertAddInfoCollect", addInfoCollectVO);
        return result;
    }
	
	//----------------------------------------------------------------------------
	
	/* [composition(new survey)] 패키지 */
	
    @SuppressWarnings("unchecked")
    @Override
    public int insertQuestionInfo(Map<String, Object> question_info_map, int page_count, List<Integer> question_counts) throws DataAccessException
    {
    	System.out.println("---------------------------------------------");
    	System.out.println("< 질문 정보 테이블 DAO -> Mapper 처리 >");
    	
        // 1. SqlSession 실행 결과가 반영된 데이터 로우 개수를 받는 변수 선언
        int data_rows_affected_by_SqlSession = 0;
        
        // 2. 테이블 맵 데이터에 대한 하위 리스트 및 하위맵 생성
        List<Map<String, Object>> question_info_innerMap_list = new ArrayList<>();
        Map<String, Object> question_info_innerMap = new HashMap<>();
        
        // 3. 테이블 맵 1차 분해
        question_info_innerMap_list = (List<Map<String, Object>>) question_info_map.get("list");
        
        // 4. 카운트 변수 분해 및 테이블 맵 2~3차 분해 (계속)
        for(int i = 0; i < page_count; i++)
        {
            // 질문 카운트 매개변수 분해
            question_count = question_counts.get(i);
            
            for(int j = 0; j < question_count; j++)
            {
                if(i == 0)
                {
                    // 테이블 맵 2차 분해
                    question_info_innerMap = question_info_innerMap_list.get(j);
                    
                    // 테이블 하위맵 출력 테스트
                    System.out.println("question_info_innerMap["+j+"] : "+question_info_innerMap);
                }
                else
                {
                    // 테이블 맵 2차 분해
                    question_info_innerMap = question_info_innerMap_list.get(question_counts.get(i-1)+j);
                    
                    // 테이블 하위맵 출력 테스트
                    System.out.println("question_info_innerMap["+(question_counts.get(i-1)+j)+"] : "+question_info_innerMap);
                }
            }            
        }
        
        data_rows_affected_by_SqlSession = sqlSession.insert("mapper.composition.insertQuestionInfo", question_info_map);
        
        System.out.println("질문 정보 테이블에 데이터가 성공적으로 저장되었습니다!");
        
        return data_rows_affected_by_SqlSession;
    }
	
	@SuppressWarnings("unchecked")
    @Override
	public int insertChoiceInfo(Map<String, Object> choice_info_map, int page_count, List<Integer> question_counts, List<Integer> choice_counts) throws DataAccessException
	{
	    // 보기 정보 테이블로 DAO 데이터 -> Mapper 처리 안내
	    System.out.println("----------------------------------------");
	    System.out.println("< 보기 정보 테이블 DAO -> Mapper 처리 >");
	    
	    // 1. SqlSession 처리 결과 행(데이터 로우) 카운트 변수 설정
	    int data_rows_affected_by_SqlSession = 0;
	    
	    // 2. 테이블 맵 데이터에 대한 하위 리스트 및 하위맵 생성
        List<Map<String, Object>> choice_info_innerMap_list = new ArrayList<>();
        Map<String, Object> choice_info_innerMap = new HashMap<>();
        
        // 3. 테이블 맵 1차 분해
        choice_info_innerMap_list = (List<Map<String, Object>>) choice_info_map.get("list");
        
        System.out.println("choice_info_map.size() : " + choice_info_map.size());
        System.out.println("choice_info_innerMap_list.size() : " + choice_info_innerMap_list.size());
        
        // 질문 순번에 대한 누적 합산 변수 설정
        int accumulated_j = 0;
        int accumulated_k = 0;
        
        // 4. 카운트 변수 분해 및 테이블 맵 2~3차 분해 (계속)
        for(int i = 0; i < page_count; i++)
        {
            // 질문 카운트 매개변수 분해
            question_count = question_counts.get(i);
            System.out.println("question_counts.get(" + i + ") : " + question_count);
            
            for(int j = 0; j < question_count; j++)
            {
                // 보기 카운트 매개변수 분해 및 출력
                choice_count = choice_counts.get(accumulated_j + j);
                System.out.println("choice_count : " + choice_count);
                
                for(int k = 0; k < choice_count; k++)
                {
                    choice_info_innerMap = choice_info_innerMap_list.get(accumulated_k + k);
                    
                    // 테이블 하위맵 출력 테스트
                    System.out.println("question_info_innerMap.get(" + (accumulated_k + k) + ") : " + choice_info_innerMap);
                    
                    // 마지막 보기 순번인 경우
                    if(k == choice_count - 1)
                    {
                    	// 누적 보기 순번에 마지막 보기 순번을 저장
                        accumulated_k += (k + 1);
                    }
                }
                
                // 마지막 질문 순번인 경우
                if(j == question_count - 1)
                {
                	// 누적 질문 순번에 마지막 질문 순번을 저장
                    accumulated_j += (j + 1);
                }
            }            
        }
        
		data_rows_affected_by_SqlSession = sqlSession.insert("mapper.composition.insertChoiceInfo", choice_info_map);
		System.out.println("보기 정보 테이블에 성공적으로 데이터가 저장되었습니다!");
		return data_rows_affected_by_SqlSession;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public int insertMultipleChoice(Map<String, Object> multiple_choice_map, int page_count, List<Integer> question_counts) throws DataAccessException
	{
		// 1. 테이블 DAO -> Mapper 처리 파트 안내 출력
		System.out.println("---------------------------------------------");
    	System.out.println("< 객관식 보기 테이블 DAO -> Mapper 처리 >");
		
		// 2. insert문 실행 결과로 반영된 Data Row 개수
		int data_rows_affected_by_SqlSession = 0;
		
		// 3. 누적 카운트 변수 설정
		int accumulated_j = 0;
		
        // 4. 테이블 맵 데이터에 대한 하위 리스트 및 하위맵 생성
        List<Map<String, Object>> multiple_choice_innerMap_list = new ArrayList<>();
        Map<String, Object> multiple_choice_innerMap = new HashMap<>();
        
        // 5. 테이블 맵 1차 분해
        multiple_choice_innerMap_list = (List<Map<String, Object>>) multiple_choice_map.get("list");
        
        // 6. 카운트 변수 분해 및 테이블 맵 2차 분해
        // i : 페이지 순번 == (페이지 번호 - 1)
        for(int i = 0; i < page_count; i++)
        {
            // 질문 카운트 매개변수 분해
            question_count = question_counts.get(i);
            
            // j : 질문 순번 == (질문 번호 - 1)
            for(int j = 0; j < question_count; j++)
            {
                // 테이블 맵 2차 분해
            	multiple_choice_innerMap = multiple_choice_innerMap_list.get(accumulated_j+j);
                
                // 테이블 하위맵 출력 테스트
                System.out.println("multiple_choice_innerMap.get(" + (accumulated_j + j) + ") : " + multiple_choice_innerMap);
                
                // 마지막 질문 순번인 경우
                if(j == question_count - 1) 
                {
                	// 누적 카운트 변수에 마지막 질문 순번에 1을 추가한 값을 저장
                	accumulated_j += (j + 1);
                }
            }            
        }
        
        // 7. Mapper 처리
		data_rows_affected_by_SqlSession = sqlSession.insert("mapper.composition.insertMultipleChoice", multiple_choice_map);
		
		// 8. 처리된 행 개수를 리턴
		return data_rows_affected_by_SqlSession;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public int insertSubjectiveChoice(Map<String, Object> subjective_choice_map, int page_count, List<Integer> question_counts) throws DataAccessException
	{
	    // 1. 주관식 보기 테이블 DAO -> Mapper 처리 안내
		System.out.println("---------------------------------------------");
    	System.out.println("< 주관식 보기 테이블 DAO -> Mapper 처리 >");
    	
		// 2. insert문 실행 결과로 반영된 Data Row 개수
		int data_rows_affected_by_SqlSession = 0;
		
		// 3. 누적 카운트 변수 설정
		int accumulated_j = 0;
		
        // 4. 테이블 맵 데이터에 대한 하위 리스트 및 하위맵 생성
        List<Map<String, Object>> subjective_choice_innerMap_list = new ArrayList<>();
        Map<String, Object> subjective_choice_innerMap = new HashMap<>();
        
        // 5. 테이블 맵 1차 분해
        subjective_choice_innerMap_list = (List<Map<String, Object>>) subjective_choice_map.get("list");
        
        // 6. 카운트 변수 분해 및 테이블 맵 2차 분해
        // i : 페이지 순번 == (페이지 번호 - 1)
        for(int i = 0; i < page_count; i++)
        {
            // 질문 카운트 매개변수 분해
            question_count = question_counts.get(i);
            
            // j : 질문 순번 == (질문 번호 - 1)
            for(int j = 0; j < question_count; j++)
            {
                // 테이블 맵 2차 분해
            	subjective_choice_innerMap = subjective_choice_innerMap_list.get(accumulated_j+j);
                
                // 테이블 하위맵 출력 테스트
                System.out.println("subjective_choice_innerMap.get(" + (accumulated_j + j) + ") : " + subjective_choice_innerMap);
                
                // 마지막 질문 순번인 경우
                if(j == question_count - 1) 
                {
                	// 누적 카운트 변수에 마지막 질문 순번에 1을 추가한 값을 저장
                	accumulated_j += (j + 1);
                }
            }            
        }
        
        // 7. Mapper 처리
		data_rows_affected_by_SqlSession = sqlSession.insert("mapper.composition.insertSubjectiveChoice", subjective_choice_map);
		
		// 8. 성공 결과 출력 및 결과가 반영된 로우 개수 리턴
		System.out.println("주관식 보기 테이블에 데이터가 성공적으로 저장되었습니다!");
		return data_rows_affected_by_SqlSession;
	}

	@SuppressWarnings("unchecked")
	@Override
	public int insertMatrixQuestion(Map<String, Object> matrix_question_map, int page_count, List<Integer> question_counts, List<Integer> matrix_questions) throws DataAccessException
	{
		// 1. 표형-행-질문 테이블에 대한 DAO -> Mapper 처리 안내 출력
		System.out.println("---------------------------------------------");
    	System.out.println("< 표형-행-질문 테이블 DAO -> Mapper 처리 >");
		
	    // 2. SqlSession 처리 결과 행(데이터 로우) 카운트 변수 설정
	    int data_rows_affected_by_SqlSession = 0;
	    
	    // 3. 테이블 맵 데이터에 대한 하위 리스트 및 하위맵 생성
        List<Map<String, Object>> matrix_question_innerMap_list = new ArrayList<>();
        Map<String, Object> matrix_question_innerMap = new HashMap<>();
        
        // 4. 테이블 맵 1차 분해
        matrix_question_innerMap_list = (List<Map<String, Object>>) matrix_question_map.get("list");
        
        // 5. 사전 저장이 잘 되어 있는지 확인하기 위해 맵 크기 출력
        System.out.println("choice_info_map.size() : " + matrix_question_map.size());
        System.out.println("choice_info_innerMap_list.size() : " + matrix_question_innerMap_list.size());
        
        // 6. 질문 순번에 대한 누적 합산 변수 설정
        int accumulated_j = 0;
        int accumulated_k = 0;
        
        // 7. 카운트 변수 분해 및 테이블 맵 2~3차 분해
        for(int i = 0; i < page_count; i++)
        {
            // 질문 카운트 매개변수 분해
            question_count = question_counts.get(i);
            System.out.println("question_counts.get(" + i + ") : " + question_count);
            
            for(int j = 0; j < question_count; j++)
            {
                // 표형-행-질문 카운트 매개변수 대입시 null 이면
            	if(matrix_questions.get(accumulated_j + j) == null)
            	{
            		// null 값이면 0으로 대입 처리
            		matrix_questions.add(accumulated_j, 0);
            	}
            	
            	// 질문 순번에 해당하는 표형-행-질문 개수 값을 대입
            	matrix_question_count = matrix_questions.get(accumulated_j + j);
            	
            	
            	// 표형-행-질문 개수 출력
                System.out.println("matrix_question_count : " + matrix_question_count);
                
                // k : 표형-행-질문 순번 == (표형-행-질문번호 - 1)
                for(int k = 0; k < matrix_question_count; k++)
                {
                	matrix_question_innerMap = matrix_question_innerMap_list.get(accumulated_k + k);
                    
                    // 테이블 하위맵 출력 테스트
                    System.out.println("matrix_question_innerMap.get(" + (accumulated_k + k) + ") : " + matrix_question_innerMap);
                    
                    // 마지막 보기 순번인 경우
                    if(k == matrix_question_count - 1)
                    {
                    	// 누적 보기 순번에 마지막 보기 순번을 저장
                        accumulated_k += (k + 1);
                    }
                }
                
                // 마지막 질문 순번인 경우
                if(j == question_count - 1)
                {
                	// 누적 질문 순번에 마지막 질문 순번을 저장
                    accumulated_j += (j + 1);
                }
            }            
        }
        
        // 8. Mapper 처리 결과로 반영된 데이터 행 개수를 저장
		data_rows_affected_by_SqlSession = sqlSession.insert("mapper.composition.insertMatrixQuestion", matrix_question_map);
		
		// 9. Mapper 처리 완료 콘솔 출력 및 그 행 개수를 리턴
		System.out.println("표형-행-질문 테이블에 데이터가 성공적으로 저장되었습니다!");
		return data_rows_affected_by_SqlSession;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public int insertMatrixChoice(Map<String, Object> matrix_choice_map, int page_count, List<Integer> question_counts, List<Integer> matrix_choices) throws DataAccessException
	{
	    // 1. 표형-열-보기 테이블에 대한 DAO -> Mapper 처리 안내 문구 출력
		System.out.println("---------------------------------------------");
		System.out.println("< 표형-열-보기 테이블 DAO -> Mapper 처리 >");
		
	    // 2. SqlSession 처리 결과 행(데이터 로우) 카운트 변수 설정
	    int data_rows_affected_by_SqlSession = 0;
	    
	    // 3. 테이블 맵 데이터에 대한 하위 리스트 및 하위맵 생성
        List<Map<String, Object>> matrix_choice_innerMap_list = new ArrayList<>();
        Map<String, Object> matrix_choice_innerMap = new HashMap<>();
        
        // 4. 테이블 맵 1차 분해
        matrix_choice_innerMap_list = (List<Map<String, Object>>) matrix_choice_map.get("list");
        
        // 5. 사전 저장이 잘 되어 있는지 확인하기 위해 맵 크기 출력
        System.out.println("matrix_choice_map.size() : " + matrix_choice_map.size());
        System.out.println("matrix_choice_innerMap_list.size() : " + matrix_choice_innerMap_list.size());
        
        // 6. 질문 순번에 대한 누적 합산 변수 설정
        int accumulated_j = 0;
        int accumulated_k = 0;
        
        // 7. 카운트 변수 분해 및 테이블 맵 2~3차 분해
        for(int i = 0; i < page_count; i++)
        {
            // 질문 카운트 매개변수 분해
            question_count = question_counts.get(i);
            System.out.println("question_counts.get(" + i + ") : " + question_count);
            
            for(int j = 0; j < question_count; j++)
            {
                // 표형-열-보기 카운트 매개변수 대입시 null 이면
            	if(matrix_choices.get(accumulated_j + j) == null)
            	{
            		// null 값이면 0으로 대입 처리
            		matrix_choices.add(accumulated_j, 0);
            	}
            	
            	// 질문 순번에 해당하는 표형-행-질문 개수 값을 대입
            	matrix_choice_count = matrix_choices.get(accumulated_j + j);
            	
            	// 표형-열-보기 개수 출력
                System.out.println("matrix_choice_count : " + matrix_choice_count);
                
                // k : 표형-열-보기 순번 == (표형-열-보기번호 - 1)
                for(int k = 0; k < matrix_choice_count; k++)
                {
                	matrix_choice_innerMap = matrix_choice_innerMap_list.get(accumulated_k + k);
                    
                    // 테이블 하위맵 출력 테스트
                    System.out.println("matrix_choice_innerMap.get(" + (accumulated_k + k) + ") : " + matrix_choice_innerMap);
                    
                    // 마지막 표형-열-보기 순번인 경우
                    if(k == matrix_choice_count - 1)
                    {
                    	// 누적 보기 순번에 마지막 보기 순번을 저장
                        accumulated_k += (k + 1);
                    }
                }
                
                // 마지막 질문 순번인 경우
                if(j == question_count - 1)
                {
                	// 누적 질문 순번에 마지막 질문 순번을 저장
                    accumulated_j += (j + 1);
                }
            }            
        }
        
        // 8. Mapper 처리
		data_rows_affected_by_SqlSession = sqlSession.insert("mapper.composition.insertMatrixChoice", matrix_choice_map);
		
		// 9. Mapper 처리 성공 메시지 출력 및 처리 결과가 반영된 데이터 로우 개수 리턴
		System.out.println("표형-열-보기 테이블에 데이터가 성공적으로 저장되었습니다!");
		return data_rows_affected_by_SqlSession;
	}
	
}