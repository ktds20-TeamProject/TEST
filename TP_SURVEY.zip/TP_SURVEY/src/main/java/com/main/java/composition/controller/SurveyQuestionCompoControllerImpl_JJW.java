package com.main.java.composition.controller;

import java.sql.Date;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.main.java.admin.vo.AdminIdInfoVO;
import com.main.java.composition.service.SurveyQuestionCompoService;
import com.main.java.composition.vo.ChoiceInfoVO;
import com.main.java.composition.vo.MatrixChoiceVO;
import com.main.java.composition.vo.MatrixQuestionVO;
import com.main.java.composition.vo.MultipleChoiceVO;
import com.main.java.composition.vo.QuestionInfoVO;
import com.main.java.composition.vo.SubjectiveChoiceVO;
import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;

@Controller("compositionController")
public class SurveyQuestionCompoControllerImpl_JJW implements SurveyQuestionCompoController 
{
	// <서비스 인터페이스 객체에 대한 자동 의존성 주입>
	@Autowired
	private SurveyQuestionCompoService surveyQuestionCompoService;
	
	// <VO 객체 11(=1+6+4)개에 대한 자동 의존성 주입>
	// 1. admin 패키지 : 1개
	@Autowired
    AdminIdInfoVO adminIdInfoVO;
	// 2. survey 패키지 : 4개
	@Autowired
    BasicSurveyInfoVO basicSurveyInfoVO;
	@Autowired
    AddSurveyInfoVO addSurveyInfoVO;
	@Autowired
    IdCertificationVO idCertificationVO;
	@Autowired
	AddInfoCollectVO addInfoCollectVO;
	// 3. composition 패키지 : 6개
	@Autowired
	ChoiceInfoVO choiceInfoVO;
	@Autowired
	MatrixChoiceVO matrixChoiceVO;
	@Autowired
	MatrixQuestionVO matrixQuestionVO;
	@Autowired
	MultipleChoiceVO multipleChoiceVO;
	@Autowired
	QuestionInfoVO questionInfoVO;
	@Autowired
	SubjectiveChoiceVO subjectiveChoiceVO;
	
	// <VO 별 처리 결과를 받는 변수>
	int choiceInfoVO_Result;
	int matrixChoiceVO_Result;
	int matrixQuestionVO_Result;
	int multipleChoiceVO_Result;
	int questionInfoVO_Result;
	int subjectiveChoiceVO_Result;
	
	// <무한증식 대비용 변수 설정>
	ArrayList<Integer> page_nums = new ArrayList<>();
	
	@Override
	@RequestMapping(value = "/composition/survey_question_compo.do", method = RequestMethod.GET)
	public ModelAndView survey_question_compo_main(HttpServletRequest request, HttpServletResponse response) 
	{
		String viewName = (String)request.getAttribute("viewName");	
		System.out.println("viewName : "+viewName);
		ModelAndView mav = new ModelAndView();
		mav.setViewName(viewName);
		return mav;
	}
	
	@Override
	@RequestMapping(value = "/composition/insert.do", method = RequestMethod.POST)
	public ModelAndView insertVO
	(
		/* 매개변수 영역 */
		
	    // <매개변수 입력>
	    // 0-1. 공용 데이터는 QuestionInfoVO에 있다.
	    // 0-2. 그외 개별 데이터는 개별 테이블 관련 입력 사항에 정리해두었다.
	    // 1. survey_question_compo.jsp (객관식 기본)에 대한 매개변수 입력
	    // 1-1. QuestionInfo 테이블 관련 데이터 입력
	    @RequestParam(value = "page_num", required = false) ArrayList<Integer> page_num,                         // 페이지 번호
	    @RequestParam(value = "question_id_num", required = false) ArrayList<Integer> question_id_num,           // 질문 식별번호
	    @RequestParam(value = "question_type", required = false) ArrayList<String> question_type,            // 질문 유형
		@RequestParam(value = "question_contents", required = false) ArrayList<String> question_contents,    // 질문 내용
		
		// 1-2. CHOICE_INFO 관련 데이터 입력
		@RequestParam(value = "choice_description", required = false) String choice_description,  // 보기 설명
		@RequestParam(value = "choice_num", required = false) int choice_num,                     // 보기 입력번호
		@RequestParam(value = "choice_contents", required = false) String choice_contents,        // 보기 입력내용
		@RequestParam(value = "choice_file_path", required = false) String choice_file_path,      // 보기별 첨부파일 경로
		
		// 1-3. MULTIPLE_CHOICE 관련 데이터 입력
		@RequestParam(value = "choice_type", required = false) String choice_type,                // 보기 유형
		@RequestParam(value = "choice_type", required = false) String choice_type,
		@RequestParam(value = "is_other_choice", required = false) String is_other_choice,        // 기타 응답여부
		@RequestParam(value = "min_multiple_choice", required = false) int min_multiple_choice,   // 객관식 최소 답변수
		@RequestParam(value = "max_multiple_choice", required = false) int max_multiple_choice,   // 객관식 최대 답변수
		
		// 2. survey_question_compo_table.jsp (객관식 표형)에 대한 매개변수 입력
		@RequestParam(value = "max_multiple_choice", required = false) int max_multiple_choice,
		
		RedirectAttributes rAttr, 
		HttpServletRequest request, 
		HttpServletResponse response
	) 
	throws Exception
	{
		/* 실행 영역 */
		
		// <인코딩 방식 처리>
		request.setCharacterEncoding("utf-8");
		
		// <세션 처리>
		// 1. 이전 페이지에서 넘어온 세션 값을 모두 이곳에 남겨야 한다.
		// 2. 세션 객체를 먼저 호출하고, 이후 저장된 세션 Attribute를 가져온다.
		// 3. 단, 다른 테이블과 중복된 컬럼은 입력받은 최초 테이블에서 호출한다.
		// 3-0. 먼저 세션 객체를 호출한다.
		HttpSession session = request.getSession();
		
		// 3-1. [admin] 패키지의 AdminInfoVO 에 대한 세션 Attribute 호출
		String admin_id = (String) session.getAttribute("admin_id");
		String password = (String) session.getAttribute("password");
		String name = (String) session.getAttribute("name");
		String position = (String) session.getAttribute("position");
		String phone_num1 = (String) session.getAttribute("phone_num1");
		String phone_num2 = (String) session.getAttribute("phone_num2");
		String phone_num3 = (String) session.getAttribute("phone_num3");
		Date join_date = (Date) session.getAttribute("join_date");
		int admin_num = (int) session.getAttribute("admin_num");
		String email1 = (String) session.getAttribute("email1");
		String email2 = (String) session.getAttribute("email2");
		
		// 3-2. [survey] 패키지의 BasicSurveyInfo 에 대한 세션 Attribute 호출
		int survey_id_num = (int) session.getAttribute("survey_id_num");
		String survey_type = (String) session.getAttribute("survey_type");
		String admin_title = (String) session.getAttribute("admin_title");
		Date survey_start_date = (Date) session.getAttribute("survey_start_date");
		Date survey_end_date = (Date) session.getAttribute("survey_end_date");
		String title_input = (String) session.getAttribute("title_input");
		String survey_notice = (String) session.getAttribute("survey_notice");
		String attached_image = (String) session.getAttribute("attached_image");
		String survey_end_notice = (String) session.getAttribute("survey_end_notice");
		Date survey_creation_date = (Date) session.getAttribute("survey_creation_date");
		Date last_modify_date = (Date) session.getAttribute("last_modify_date");
		String is_last_modify = (String) session.getAttribute("is_last_modify");
		String is_collect_data = (String) session.getAttribute("is_collect_data");
		String is_limit_respondent = (String) session.getAttribute("is_limit_respondent");
		int limit_respondent_num = (int) session.getAttribute("limit_respondent_num");
		
		// 3-3. [survey] 패키지의 AddSurveyInfo 에 대한 세션 Attribute 호출
		String is_anonymous_respondent = (String) session.getAttribute("is_anonymous_respondent");
		String is_collect_add_info = (String) session.getAttribute("is_collect_add_info");
		String is_confirm_identification = (String) session.getAttribute("is_confirm_identification");
		
		// 3-4. [survey] 패키지의 IdCertificationVO 에 대한 세션 Attribute 호출
		String certification_notice = (String) session.getAttribute("certification_notice");
		String certification_info = (String) session.getAttribute("certification_info");
		
		// 3-5. [survey] 패키지의 AddInfoCollectVO 에 대한 세션 Attribute 호출
		String sex = (String) session.getAttribute("sex");
		int age = (int) session.getAttribute("age");
		String education = (String) session.getAttribute("education");
		String marriage = (String) session.getAttribute("marriage");
		String salary = (String) session.getAttribute("salary");
		String religion = (String) session.getAttribute("religion");
		
		// 4. 세션이 잘 넘어왔는지 이클립스 콘솔창에 변수 출력으로 확인해본다.
		System.out.println("<세션 정보>");
		System.out.println("1. [admin] 패키지의 AdminInfoVO 에 대한 세션 Attribute 호출");
		System.out.println("admin_id : "+admin_id);
		System.out.println("password : "+password);
		System.out.println("name : "+name);
		System.out.println("position : "+position);
		System.out.println("phone_num1 : "+phone_num1);
		System.out.println("phone_num2 : "+phone_num2);
		System.out.println("phone_num3 : "+phone_num3);
		System.out.println("join_date : "+join_date);
		System.out.println("admin_num : "+admin_num);
		System.out.println("email1 : "+email1);
		System.out.println("email2 : "+email2);
		System.out.println();
		System.out.println("2. [survey] 패키지의 BasicSurveyInfo 에 대한 세션 Attribute 호출");
		System.out.println("survey_id_num : "+survey_id_num);
		System.out.println("survey_type : "+survey_type);
		System.out.println("admin_title : "+admin_title);
		System.out.println("survey_start_date : "+survey_start_date);
		System.out.println("survey_end_date : "+survey_end_date);
		System.out.println("title_input : "+title_input);
		System.out.println("survey_notice : "+survey_notice);
		System.out.println("attached_image : "+attached_image);
		System.out.println("survey_end_notice : "+survey_end_notice);
		System.out.println("survey_creation_date : "+survey_creation_date);
		System.out.println("last_modify_date : "+last_modify_date);
		System.out.println("is_last_modify : "+is_last_modify);
		System.out.println("is_collect_data : "+is_collect_data);
		System.out.println("is_limit_respondent : "+is_limit_respondent);
		System.out.println("limit_respondent_num : "+limit_respondent_num);
		System.out.println();
		System.out.println("3. [survey] 패키지의 AddSurveyInfo 에 대한 세션 Attribute 호출");
		System.out.println("is_anonymous_respondent : "+is_anonymous_respondent);
		System.out.println("is_collect_add_info : "+is_collect_add_info);
		System.out.println("is_confirm_identification : "+is_confirm_identification);
		System.out.println();
		System.out.println("4. [survey] 패키지의 IdCertificationVO 에 대한 세션 Attribute 호출");
		System.out.println("certification_notice : "+certification_notice);
		System.out.println("certification_info : "+certification_info);
		System.out.println();
		System.out.println("5. [survey] 패키지의 AddInfoCollectVO 에 대한 세션 Attribute 호출");
		System.out.println("sex : "+sex);
		System.out.println("age : "+age);
		System.out.println("education : "+education);
		System.out.println("marriage : "+marriage);
		System.out.println("salary : "+salary);
		System.out.println("religion : "+religion);
		
		// <세션/폼에서 넘어온 데이터 VO에 저장>
		// 1. 넘어온 세션 데이터에 대해 각 VO에 모두 저장한다.
		// 2. 이번에는 아까와 달리 중복된 세션 데이터라도 빠짐없이 저장해야 한다.
		// 3-1. [admin] 패키지의 AdminInfoVO 에 setter로 저장
		adminIdInfoVO.setAdmin_id(admin_id);
		adminIdInfoVO.setPassword(password);
		adminIdInfoVO.setName(name);
		adminIdInfoVO.setPosition(position);
		adminIdInfoVO.setPhone_num1(phone_num1);
		adminIdInfoVO.setPhone_num2(phone_num2);
		adminIdInfoVO.setPhone_num3(phone_num3);
		adminIdInfoVO.setJoin_date(join_date);
		adminIdInfoVO.setAdmin_num(admin_num);
		adminIdInfoVO.setEmail1(email1);
		adminIdInfoVO.setEmail2(email2);
		
		// 3-2. [survey] 패키지의 BasicSurveyInfo 에 setter로 저장
		basicSurveyInfoVO.setSurvey_id_num(survey_id_num);
		basicSurveyInfoVO.setSurvey_type(survey_type);
		basicSurveyInfoVO.setAdmin_title(admin_title);
		basicSurveyInfoVO.setSurvey_start_date(survey_start_date);
		basicSurveyInfoVO.setSurvey_end_date(survey_end_date);
		basicSurveyInfoVO.setAdmin_id(admin_id);
		basicSurveyInfoVO.setTitle_input(title_input);
		basicSurveyInfoVO.setSurvey_notice(survey_notice);
		basicSurveyInfoVO.setAttached_image(attached_image);
		basicSurveyInfoVO.setSurvey_end_notice(survey_end_notice);
		basicSurveyInfoVO.setLast_modify_date(last_modify_date);
		basicSurveyInfoVO.setIs_last_modify(is_last_modify);
		basicSurveyInfoVO.setIs_collect_data(is_collect_data);
		basicSurveyInfoVO.setIs_limit_respondent(is_limit_respondent);
		basicSurveyInfoVO.setLimit_respondent_num(limit_respondent_num);
		
		// 3-3. [survey] 패키지의 AddSurveyInfo 에 setter로 저장
		addSurveyInfoVO.setSurvey_id_num(survey_id_num);
		addSurveyInfoVO.setIs_anonymous_respondent(is_anonymous_respondent);
		addSurveyInfoVO.setIs_collect_add_info(is_collect_add_info);
		addSurveyInfoVO.setIs_confirm_identification(is_confirm_identification);
		
		// 3-4. [survey] 패키지의 IdCertificationVO 에 setter로 저장
		idCertificationVO.setSurvey_id_num(survey_id_num);
		idCertificationVO.setCertification_notice(certification_notice);
		idCertificationVO.setCertification_info(certification_info);
		
		// 3-5. [survey] 패키지의 AddInfoCollectVO 에 setter로 저장
		addInfoCollectVO.setSurvey_id_num(survey_id_num);
		addInfoCollectVO.setSex(sex);
		addInfoCollectVO.setAge(age);
		addInfoCollectVO.setEducation(education);
		addInfoCollectVO.setMarriage(marriage);
		addInfoCollectVO.setSalary(salary);
		addInfoCollectVO.setReligion(religion);
		
		// <입력된 데이터에 대한 분기 처리>
		// 1. 넘어온 매개변수들 중 일부만 넘어올 수 있다.
		// 2. 넘어온 매개변수들의 입력된 상태에 맞춰서 처리해야 한다.
		// -----------------------------------------------------------
		// ChoiceInfoVO 값 -> 넘어오면 처리  
		if(choiceInfoVO != null)
		{
			choiceInfoVO_Result = surveyQuestionCompoService.addChoiceInfo(choiceInfoVO);
		}
		
		// MatrixChoiceVO 값 -> 넘어오면 처리 
		if(matrixChoiceVO != null)
		{
			matrixChoiceVO_Result = surveyQuestionCompoService.addMatrixChoice(matrixChoiceVO);
		}
		
		// MatrixQuestionVO 값 -> 넘어오면 처리 
		if(matrixQuestionVO != null)
		{
			matrixQuestionVO_Result = surveyQuestionCompoService.addMatrixQuestion(matrixQuestionVO);
		}
		
		// MultipleChoiceVO 값 -> 넘어오면 처리
		if(multipleChoiceVO != null)
		{
			multipleChoiceVO_Result = surveyQuestionCompoService.addMultipleChoice(multipleChoiceVO);
		}
		
		// QuestionInfoVO 값 -> 넘어오면 처리
		if(questionInfoVO != null)
		{
			questionInfoVO_Result = surveyQuestionCompoService.addQuestionInfo(questionInfoVO);
		}
		
		// SubjectiveChoiceVO 값 -> 넘어오면 처리
		if(subjectiveChoiceVO != null)
		{
			subjectiveChoiceVO_Result = surveyQuestionCompoService.addSubjectiveChoice(subjectiveChoiceVO);
		}
		
		// <리디렉션 처리>
		// 1. ModelAndView 객체에 redirect 주소값 전송
		// 2. 해당 주소값을 가진 ModelAndView 객체를 리턴시킴
		ModelAndView mav = new ModelAndView("redirect:/composition/survey_result_main.do");
		return mav;
	}
}
