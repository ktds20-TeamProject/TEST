package com.main.java.survey.vo;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component("choiceInfoVO")
public class ChoiceInfoVO {//객관식 보기정보
	
	private String survey_id_num; //설문 식별번호
	private String question_id_num; //질문식별번호
	private String choice_num; //보기입력 번호
	private String choice_contents; //보기입력 내용
	private String choice_file_path; //보기별 첨부파일 경로
	private String page_num; //페이지 번호
}
