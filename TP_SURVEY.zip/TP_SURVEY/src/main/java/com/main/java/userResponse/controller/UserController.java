package com.main.java.userResponse.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.main.java.survey.vo.BasicSurveyInfoVO;

public interface UserController {
	
	public ModelAndView main(HttpServletRequest request, HttpServletResponse response);

	public ModelAndView agree_terms(String survey_id_num, HttpServletRequest request,
			HttpServletResponse response)throws Exception;
	
	public ModelAndView agree_terms_next(String survey_id_num,String page_num, HttpServletRequest request, HttpServletResponse response)
			throws Exception;
	
	public ModelAndView response(String survey_id_num,String page_num,HttpServletRequest request,
			HttpServletResponse response)throws Exception;

	public ModelAndView response_nextPage(HttpServletRequest request, HttpServletResponse response)
			throws Exception;

	public ModelAndView responseSubmit(HttpServletRequest request, HttpServletResponse response)
		throws Exception;
	
	public ModelAndView survey_end_terms(HttpServletRequest request, HttpServletResponse response)
			throws Exception;
}
