package com.main.java.survey.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.main.java.survey.vo.BasicSurveyInfoVO;

public interface BasicSurveyInfoService 
{
	public List listBasicSurveyInfo() throws DataAccessException;
	public int addBasicSurveyInfo(BasicSurveyInfoVO basicsurveyinfoVO) throws DataAccessException;
//	public int removeBasicSurveyInfo(String id) throws DataAccessException;
//	public BasicSurveyInfoVO login(BasicSurveyInfoVO memberVO) throws Exception;
}
