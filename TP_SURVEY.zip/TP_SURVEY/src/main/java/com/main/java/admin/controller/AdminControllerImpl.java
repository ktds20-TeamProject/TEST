package com.main.java.admin.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.main.java.admin.passwordSHA256;
import com.main.java.admin.service.AdminService;
import com.main.java.admin.vo.AdminVO;
import com.main.java.composition.vo.TotalChoiceInfoVO;
import com.main.java.composition.vo.TotalQuestionInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.userResponse.vo.TotalUserSurveyVO;

@Controller("adminController")
public class AdminControllerImpl implements AdminController {
	@Autowired
	private AdminService adminService;
	@Autowired
	AdminVO adminVO;
	@Autowired // 의존성 주입
	BasicSurveyInfoVO basicSurveyInfoVO;
	@Autowired
	TotalQuestionInfoVO totalQuestionInfoVO;
	@Autowired
	TotalChoiceInfoVO totalChoiceInfoVO;
	@Autowired
	TotalUserSurveyVO totalUserSurveyVO;

	// 테스트용
	@RequestMapping(value = { "/test.do" }, method = { RequestMethod.GET, RequestMethod.POST })
	private ModelAndView test(HttpServletRequest request, HttpServletResponse response) {
		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView();
		mav.setViewName(viewName);
		return mav;
	}
	@RequestMapping(value = { "/test2.do" }, method = { RequestMethod.GET, RequestMethod.POST })
	private ModelAndView test2(
			HttpServletRequest request, HttpServletResponse response) {
		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView();
		
		
		mav.setViewName("redirect:/test.do");
		return mav;
	}
	

	// 로그인 화면(관리자 메인) 접속
	@RequestMapping(value = "/admin_main_login.do", method = { RequestMethod.GET, RequestMethod.POST })
	private ModelAndView loginForm(@RequestParam(value = "result", required = false) String result,
			@RequestParam(value = "action", required = false) String action, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");
		HttpSession session = request.getSession();
		session.setAttribute("action", action);
		ModelAndView mav = new ModelAndView();
		mav.addObject("result", result);
		mav.setViewName(viewName);
		return mav;
	}

	// 로그인 (기능)
	@Override
	@RequestMapping(value = "/login.do", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView login(@ModelAttribute("admin") AdminVO admin, RedirectAttributes rAttr,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		// 비밀번호 암호화
		String encryPassword = passwordSHA256.encrypt(admin.getPassword());
		admin.setPassword(encryPassword);
		// 입력된 로그인 정보로 데이터베이스와 정보 일치 확인
		adminVO = adminService.login(admin);
		// 정보 일치 확인될 경우 세션에 로그인 정보와 기본정보(id, 이름) 세팅. action값 있을 시 그쪽으로 리다이렉트.
		if (adminVO != null) {
			HttpSession session = request.getSession();
			session.setAttribute("admin", adminVO);
			session.setAttribute("isLogOn", true);
			String action = (String) session.getAttribute("action");
			session.removeAttribute("action");
			if (action != null) {
				mav.setViewName("redirect:" + action);
			} else {
				mav.setViewName("redirect:/admin_list.do");
			}
		}
		// 정보 불일치시 로그인 실패 정보를 담아 로그인 화면으로 리다이렉트
		else {
			rAttr.addAttribute("result", "loginFailed");
			mav.setViewName("redirect:/admin_main_login.do");
		}
		return mav;
	}

	// 로그아웃 (기능)
	@Override
	@RequestMapping(value = "/logout.do", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		// 세션에서 기본정보와 로그인여부를 삭제 후 로그인 화면으로 리다이렉트
		session.removeAttribute("admin");//
		session.removeAttribute("isLogOn");
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:admin_main_login.do");
		return mav;
	}

	// 회원가입 화면 접속
	@RequestMapping(value = "/admin_join.do", method = { RequestMethod.GET, RequestMethod.POST })
	private ModelAndView joinForm(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView();
		mav.setViewName(viewName);
		return mav;
	}

	// 회원가입 (기능)
	@Override
	@RequestMapping(value = "/join.do", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView join(@ModelAttribute("admin") AdminVO admin, RedirectAttributes rAttr,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		// 비밀번호 암호화 후 데이터베이스에 저장, 가입완료 메세지 담아 로그인 화면으로 리다이렉트
		String encryPassword = passwordSHA256.encrypt(admin.getPassword());
		admin.setPassword(encryPassword);
		int result = adminService.join(admin);
		ModelAndView mav = new ModelAndView("redirect:/admin_main_login.do");
		rAttr.addAttribute("result", "joinDone");
		return mav;
	}

	// 아이디 중복확인 (기능)
	@Override
	@RequestMapping(value = "/idDuplicated.do", method = { RequestMethod.GET, RequestMethod.POST })
	@ResponseBody
	public int idDuplicated(@RequestParam("adminId") String adminId) {
		int data = 0;
		// 입력된 아이디로 기존 데이터베이스를 검색해 일치하는 아이디가 있는지 리턴
		data = adminService.idDuplicated(adminId);
		return data;
	}

	// 회원정보 수정 전 비밀번호 체크 화면 접속
	@RequestMapping(value = "/admin_pw_check.do", method = { RequestMethod.GET, RequestMethod.POST })
	private ModelAndView pwCheckForm(@RequestParam(value = "result", required = false) String result,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView();
		mav.addObject("result", result);
		mav.setViewName(viewName);
		return mav;
	}

	// 회원정보 수정 화면 접속
	@RequestMapping(value = "/admin_info_update.do", method = { RequestMethod.GET, RequestMethod.POST })
	private ModelAndView UpdateForm(@RequestParam(value = "result", required = false) String result,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView();
		HttpSession session = request.getSession();
		// 세션에 담겨있는 기본정보로 회원의 모든 정보를 불러와 바인딩해 화면에 넘김
		AdminVO admin = (AdminVO) session.getAttribute("admin");
		AdminVO adminInfo = adminService.infoView(admin);
		mav.addObject("adminInfo", adminInfo);
		mav.addObject("result", result);
		mav.setViewName(viewName);
		return mav;
	}

	// 비밀번호 체크 후 수정 화면 접속하기 (기능)
	@Override
	@RequestMapping(value = "/pw_check.do", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView pwCheck(@ModelAttribute("admin") AdminVO admin, RedirectAttributes rAttr,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		// 비밀번호 암호화 후 일치 여부 확인
		String encryPassword = passwordSHA256.encrypt(admin.getPassword());
		admin.setPassword(encryPassword);
		adminVO = adminService.pwCheck(admin);
		// 일치할 경우 회원정보 수정 화면으로 리다이렉트
		if (adminVO != null) {
			mav.setViewName("redirect:/admin_info_update.do");
		}
		// 일치하지 않을 경우 비밀번호 불일치 정보 담아 비밀번호 체크 화면으로 리다이렉트
		else {
			rAttr.addAttribute("result", "pwdCheckFailed");
			mav.setViewName("redirect: /admin_pw_check.do");
		}
		return mav;
	}

	// 회원정보 수정 (기능)
	@Override
	@RequestMapping(value = "/admin_update.do", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView adminUpdate(@ModelAttribute("admin") AdminVO admin, RedirectAttributes rAttr,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		ModelAndView mav = new ModelAndView();
		// 비밀번호 암호화 후 데이터베이스에 수정 정보 저장하고 수정완료 정보 담아 회원정보 수정화면으로 리다이렉트
		String encryPassword = passwordSHA256.encrypt(admin.getPassword());
		admin.setPassword(encryPassword);
		int result = adminService.adminUpdate(admin);
		rAttr.addAttribute("result", "updateDone");
		mav.setViewName("redirect:/admin_info_update.do");
		return mav;
	}

	// 회원탈퇴 화면 접속
	@RequestMapping(value = "admin_delete.do", method = { RequestMethod.GET, RequestMethod.POST })
	private ModelAndView deleteForm(@RequestParam(value = "result", required = false) String result,
			HttpServletRequest request, HttpServletResponse response) {
		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView();
		mav.addObject("result", result);
		mav.setViewName(viewName);
		return mav;
	}

	// 탈퇴시 비밀번호 체크하고 탈퇴하기 (기능)
	@Override
	@RequestMapping(value = "delete.do", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView deleteAdmin(@ModelAttribute("admin") AdminVO admin, RedirectAttributes rAttr,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		HttpSession session = request.getSession();
		// 비밀번호 암호화 후 일치여부 체크
		String encryPassword = passwordSHA256.encrypt(admin.getPassword());
		admin.setPassword(encryPassword);
		adminVO = adminService.pwCheck(admin);
		// 일치할 경우 탈퇴완료 정보 담아 로그인 화면으로 리다이렉트
		if (adminVO != null) {
			int deleted = adminService.deleteAdmin(admin);
			rAttr.addAttribute("result", "deleteDone");
			session.removeAttribute("admin");
			session.removeAttribute("isLogOn");
			mav.setViewName("redirect:/admin_main_login.do");
		}
		// 일치하지 않을 경우 비밀번호 불일치 정보 담아 탈퇴 화면으로 리다이렉트
		else {
			rAttr.addAttribute("result", "pwdCheckFailed");
			mav.setViewName("redirect: /admin_delete.do");
		}
		return mav;
	}

	// 아이디 찾기창 연결
	@RequestMapping(value = { "/admin_find_id.do" }, method = { RequestMethod.GET, RequestMethod.POST })
	private ModelAndView main(@RequestParam(value = "result", required = false) String result,
			@RequestParam(value = "failed", required = false) String failed, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");
		System.out.println(viewName);
		ModelAndView mav = new ModelAndView();
		mav.setViewName(viewName);
		mav.addObject("result", result);
		mav.addObject("failed", failed);
		return mav;
	}

	// 아이디 찾기 기능
	@RequestMapping(value = "/admin_find_id", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView admin_find_id(@ModelAttribute("admin") AdminVO admin, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");
		List result = adminService.admin_find_id(admin);
		System.out.println(result);
		ModelAndView mav = new ModelAndView();
		// mav.addObject("result", result);
		// 정보 일치 시 result값(id) 반환
		if (result != null) {
			mav.setViewName("redirect: /admin_find_id.do");
			mav.addObject("result", result);
			// 불일치 시 failed값 반환
		} else {
			mav.setViewName("redirect: /admin_find_id.do");
			mav.addObject("failed", "다시 입력 해주세요..");
		}
		return mav;
	}

	// 비밀번호 찾기 화면 접속
	@RequestMapping(value = "admin_find_pw.do", method = { RequestMethod.GET, RequestMethod.POST })
	private ModelAndView findPwForm(@RequestParam(value = "result", required = false) String result,
			HttpServletRequest request, HttpServletResponse response) {
		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView();
		mav.addObject("result", result);
		mav.setViewName(viewName);
		return mav;
	}

	// 비밀번호 찾기(기능)
	@Override
	@RequestMapping(value = "find_pw.do", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView findPw(@ModelAttribute("admin") AdminVO admin, RedirectAttributes rAttr,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		// 유효성 검증
		adminVO = adminService.findPwCheck(admin);
		// 검증한 값 변수에 저장해서 파라미터로 메일전송 메서드에 넘기기
		if (adminVO != null) {
			String adminId = admin.getAdminId();
			String email = admin.getEmail1() + "@" + admin.getEmail2();
			adminService.findPwSendMail(adminId, email, request);
			rAttr.addAttribute("result", "sendMailDone");
			mav.setViewName("redirect: /admin_main_login.do");
		} else {
			rAttr.addAttribute("result", "findPwCheckFailed");
			mav.setViewName("redirect: /admin_find_pw.do");
		}
		return mav;
	}

	// 관리자 메인 화면
	@RequestMapping(value = "admin_list.do", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView admin_list(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");

		int page = 1;// 쪽번호
		int limit = 8;// 한페이지에 보여지는 목록개수
		if (request.getParameter("page") != null) {
			page = Integer.parseInt(request.getParameter("page"));
		}
		String find_title = request.getParameter("find_title");// 검색어
		String find_field = request.getParameter("find_field");// 검색필드

		basicSurveyInfoVO.setFind_field(find_field);
		basicSurveyInfoVO.setFind_title("%" + find_title + "%");
		// %는 하나이상의 임의의 문자와 매핑 대응

		int listcount = this.adminService.surveyListCount(basicSurveyInfoVO);
		// 전체 레코드 개수 또는 검색전후 레코드 개수
		// System.out.println("총 게시물수:"+listcount+"개");
		basicSurveyInfoVO.setStartrow((page - 1) * 8 + 1);// 시작행번호
		basicSurveyInfoVO.setEndrow(basicSurveyInfoVO.getStartrow() + limit - 1);// 끝행번호
		// System.out.println(basicSurveyInfoVO.getStartrow()+"_"+basicSurveyInfoVO.getEndrow());
		List mainList = adminService.admin_list(basicSurveyInfoVO);
		// System.out.println(mainList);

		// 총페이지수
		int maxpage = (int) ((double) listcount / limit + 0.95);
		// 현재 페이지에 보여질 시작페이지 수(1,11,21)
		int startpage = (((int) ((double) page / 10 + 0.9)) - 1) * 10 + 1;
		// 현재 페이지에 보여줄 마지막 페이지 수(10,20,30)
		int endpage = maxpage;
		if (endpage > startpage + 10 - 1)
			endpage = startpage + 10 - 1;

		ModelAndView mav = new ModelAndView(viewName);
		mav.addObject("mainList", mainList);
		mav.addObject("page", page);
		mav.addObject("startpage", startpage);
		mav.addObject("endpage", endpage);
		mav.addObject("maxpage", maxpage);
		mav.addObject("listcount", listcount);
		mav.addObject("find_field", find_field);
		mav.addObject("find_title", find_title);

		return mav;
	}

	@RequestMapping(value = "survey_result_main.do", method = { RequestMethod.GET, RequestMethod.POST })
	private ModelAndView surveyResultForm(@RequestParam(value = "survey_id_num", required = false) String survey_id_num,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView(viewName);
		// 기본 설문 정보 불러오기
		basicSurveyInfoVO = adminService.surveyInfoView(survey_id_num);

		// 설문 정보의 설문 시작/마감 날짜와 현재 날짜를 비교해 String에 상태 입력
		Date survey_start_date = basicSurveyInfoVO.getSurvey_start_date();
		Date survey_end_date = basicSurveyInfoVO.getSurvey_end_date_r(); // 비교용 마감+1날짜
		Date sysdate = new Date(System.currentTimeMillis());
		String progress = "";
		if (sysdate.before(survey_start_date)) {
			// 오늘 날짜가 설문 시작 날짜보다 이전인 경우 대기중
			progress = "대기중 설문";
		} else if (sysdate.after(survey_end_date)) {
			// 오늘 날짜가 설문 마감 날짜보다 이후인 경우 종료된
			progress = "종료된 설문";
		} else {
			progress = "진행중 설문";
		}

		// 총 문항수, 총 응답자수 불러오기
		int countQuestion = adminService.countQuestion(survey_id_num);
		int countResponse = adminService.countResponse(survey_id_num);
		// 값 담아서 mav에 바인딩 할 리스트 선언
		List<TotalQuestionInfoVO> questionInfo = new ArrayList();
		List<Object> choiceInfo = new ArrayList();
		List<Object> userSurveyInfo = new ArrayList();
		//객관식 질문들의 번호를 담을 리스트 선언
		List<Integer> multipleQnum = new ArrayList();

		// VO를 담은 리스트(질문번호 오름차순 정렬)형태로 이 설문의 질문 기본정보를 조회해옴
		questionInfo = adminService.questionInfoView(survey_id_num);

		// 총 질문개수만큼 for문 반복
		for (int i = 0; i < countQuestion; i++) {
			// 질문 유형을 받아옴
			String qType = questionInfo.get(i).getQuestion_type();
			// 쿼리문에 파라미터로 넘길 이 설문의 번호와 현재 질문번호를 Map으로 만듦
			Map<String, Object> paraMap = new HashMap();
			paraMap.put("survey_id_num", survey_id_num);
			paraMap.put("question_id_num", i + 1);

			// 이 질문정보의 질문 유형이 multiple일 경우
			if (qType.equalsIgnoreCase("multipleChoiceDefault") || qType.equalsIgnoreCase("multipleChoiceDropdown")) {
				// 객관식 추가정보 조회
				TotalQuestionInfoVO vo2 = adminService.MqInfoView(paraMap);
				// 조회해온 객관식 질문의 추가정보를 이 질문의 질문정보에 추가세팅
				int choice_count = Integer.valueOf(vo2.getChoice_count());
				questionInfo.get(i).setChoice_count(choice_count - 1); // jsp에서 forEach End속성에 사용할 마지막 인덱스
				questionInfo.get(i).setIs_other_choice(vo2.getIs_other_choice());
				questionInfo.get(i).setMin_multiple_choice(vo2.getMin_multiple_choice());
				questionInfo.get(i).setMax_multiple_choice(vo2.getMax_multiple_choice());
				// VO를 담은 리스트(보기번호 오름차순 정렬)형태로 이 질문의 보기정보를 조회해옴
				List<TotalChoiceInfoVO> mChoiceInfo = adminService.mcInfoView(paraMap);
				choiceInfo.add(mChoiceInfo);
				
				//총 응답자 수를 질문 정보에 입력
				int count = adminService.CountMResponse(paraMap);
				questionInfo.get(i).setCount(count);
				
				//이 질문의 개별 응답정보를 담을 리스트 선언
				List<TotalUserSurveyVO> multipleResponse = new ArrayList();
				
				//총 보기 개수만큼 vo를 불러와 순서대로 입력해줌 (선택받지 않은 선택지가 있을 수 있으므로 한 번에 불러오지 않음)
				for(int j=0; j < choice_count; j++) {
					paraMap.put("respondent_multiple", j+1);
					TotalUserSurveyVO vo = adminService.mResponseView(paraMap);
					if (vo!=null) {
						TotalUserSurveyVO ifvo = new TotalUserSurveyVO();
						ifvo.setMultiple_count(vo.getMultiple_count());
						if (ifvo != null) {
							double thisCount = (double)vo.getMultiple_count();
							double multiple_percent = (double)(thisCount/(double)count)*100;
							vo.setMultiple_percent((int)multiple_percent);
						}
					}
					multipleResponse.add(vo);
				}
				userSurveyInfo.add(multipleResponse);
				
				multipleQnum.add(i+1);
			}

			// 이 질문정보의 질문 유형이 subjective일 경우
			else if (qType.equalsIgnoreCase("subjectiveType")) {
				// 주관식 정보로 담아줄 중복값 여부를 조회
				TotalChoiceInfoVO vo4 = adminService.scInfoView(paraMap);
				choiceInfo.add(vo4);
				
				//VO를 담은 리스트(보기번호 오름차순 정렬)형태로 이 질문의 개별 응답정보를 조회
				List<TotalUserSurveyVO> subjectiveResponse = adminService.sResponseView(paraMap);
				userSurveyInfo.add(subjectiveResponse);
								
				//총 응답자 수를 질문 정보에 입력
				int count = adminService.CountMResponse(paraMap);
				questionInfo.get(i).setCount(count);
				// jsp에서 forEach End속성에 사용하기 위해 질문 정보에 추가 세팅해줌
				questionInfo.get(i).setSubjective_count(count - 1);
			}

			// 이 질문정보의 질문 유형이 matrix일 경우
			else if (qType.equalsIgnoreCase("multipleChoiceTable")) {
				// 이 질문의 총 표형 질문/보기개수 각각 불러오기, 이 질문의 질문정보에 세팅
				int countMTableQ = adminService.countMtqQ(paraMap);
				int countMTableC = adminService.countMtqC(paraMap);
				// jsp에서 forEach End속성에 사용하기 위해 질문 정보에 추가 세팅해줌
				questionInfo.get(i).setMatrix_q_count(countMTableQ - 1);
				questionInfo.get(i).setMatrix_c_count(countMTableC - 1);
				// VO를 담은 리스트(보기번호 오름차순 정렬)형태로 이 질문의 표형 질문/보기정보를 각각 조회해옴
				List<TotalChoiceInfoVO> mTableQInfo = adminService.mTableQInfoView(paraMap);
				List<TotalChoiceInfoVO> mTableCInfo = adminService.mTableCInfoView(paraMap);
				// 한 질문에 대한 정보들이므로 한번에 담아 넘기기 위한 List 선언
				List<List<TotalChoiceInfoVO>> mTableInfo = new ArrayList();
				// 질문 보기 각각의 List를 순서대로 담아줌
				mTableInfo.add(mTableQInfo);
				mTableInfo.add(mTableCInfo);
				choiceInfo.add(mTableInfo);
				
				//총 응답자 수를 질문 정보에 입력
				int count = adminService.CountMTResponse(paraMap);
				questionInfo.get(i).setCount(count);
				
				//이 질문의 개별 응답정보를 담을 리스트 선언
				List<List<TotalUserSurveyVO>> matrixResponse = new ArrayList();
				
				//총 질문 개수의 총 보기 개수만큼 VO를 순서대로 불러와 입력함
				for (int j=0; j<countMTableQ; j++) {
					List<TotalUserSurveyVO> InnerResponse = new ArrayList();
					for (int k=0; k<countMTableC; k++) {
						//설문번호+질문번호+내부질문번호+보기번호까지 넘길 수 있도록 파라미터에 입력
						paraMap.put("matrix_num", j+1); 
						paraMap.put("respondent_multiple", k+1);
						TotalUserSurveyVO vo = adminService.mTableResponseView(paraMap);
						if (vo!=null) {
							TotalUserSurveyVO ifvo = new TotalUserSurveyVO();
							ifvo.setMatrix_count(vo.getMatrix_count());
							if(ifvo!=null) {
								double thisCount = (double)vo.getMatrix_count();
								double matrix_percent = (double)(thisCount/(double)count)*100;
								vo.setMatrix_percent((int)matrix_percent);
							}
						}
						InnerResponse.add(vo);
					}
					matrixResponse.add(InnerResponse);
				}
				userSurveyInfo.add(matrixResponse);
			}
		}
		//JSP출력시 값이 잘리지 않게 하기 위해 forEach문 돌아갈 횟수 중 가장 큰 값을 추출
		int maxC = countQuestion;
		//총 응답자 수와 비교해 큰 값 추출
		if (countQuestion<countResponse) { 
			maxC = countResponse;
		}
		//모든 보기 개수와 비교해 큰 값 추출
		for (int i=0; i<countQuestion; i++) {
			if (questionInfo.get(i) != null) {
				if (questionInfo.get(i).getChoice_count()+1 > maxC) {
					maxC = questionInfo.get(i).getChoice_count()+1;
				} else if (questionInfo.get(i).getMatrix_q_count()+1 > maxC) {
					maxC = questionInfo.get(i).getMatrix_q_count()+1;
				} else if (questionInfo.get(i).getMatrix_c_count()+1 > maxC) {
					maxC = questionInfo.get(i).getMatrix_c_count()+1;
				}
			}
		}
		//해당 인덱스의list로 만들어 넘김
		List <Integer> maxCount = new ArrayList();
		for (int i=0; i<maxC; i++) {
			maxCount.add(i);
		}
		System.out.println(maxCount);
		System.out.println(questionInfo);
		System.out.println(userSurveyInfo);
		System.out.println(multipleQnum);
		mav.addObject("basicSurveyInfo", basicSurveyInfoVO); // 기본 설문정보
		mav.addObject("progress", progress); // 현재 설문 진행 상태
		mav.addObject("countQuestion", countQuestion); // 총 질문 개수
		mav.addObject("countResponse", countResponse); // 총 응답 개수
		mav.addObject("questionInfo", questionInfo); // 질문 기본정보
		mav.addObject("choiceInfo", choiceInfo); // 질문 보기정보
		mav.addObject("userSurveyInfo", userSurveyInfo); //질문 응답정보
		mav.addObject("maxCount", maxCount); //JSP출력용 최대반복회수
		mav.addObject("multipleQnum", multipleQnum); //객관식 질문 번호 확인용 list
		return mav;
	}
	
	
}