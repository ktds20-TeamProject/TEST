package com.main.java.survey.vo;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component("matrixQuestionVO")
public class MatrixQuestionVO {// 표형 질문등록

	private String question_id_num; //질문식별번호
	private String survey_id_num; //설문 식별번호
	private String matrix_num; //표형 질문번호
	private String matrix_contents; //표형 질문내용
	private String page_num; //페이지번호
}
