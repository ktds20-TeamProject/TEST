package com.main.java.composition.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.main.java.composition.vo.ChoiceInfoVO;
import com.main.java.composition.vo.MatrixChoiceVO;
import com.main.java.composition.vo.MatrixQuestionVO;
import com.main.java.composition.vo.MultipleChoiceVO;
import com.main.java.composition.vo.QuestionInfoVO;
import com.main.java.composition.vo.SubjectiveChoiceVO;

public interface SurveyQuestionCompoController 
{	
	public ModelAndView survey_question_compo_main(HttpServletRequest request, HttpServletResponse response);
	public ModelAndView insertVO
	(
        @RequestParam(value = "multiple_choice_type", required = false) String choice_type,
        @RequestParam(value = "question_contents", required = false) String question_contents,
        @RequestParam(value = "question_file_path", required = false) String question_file_path,
        @RequestParam(value = "choice_description", required = false) String choice_description,
        @RequestParam(value = "choice_file_path", required = false) String choice_file_path,
        @RequestParam(value = "choice_input", required = false) String choice_input,
        @RequestParam(value = "is_other_choice", required = false) String is_other_choice,
        @RequestParam(value = "min_multiple_choice", required = false) int min_multiple_choice,
        @RequestParam(value = "max_multiple_choice", required = false) int max_multiple_choice,     
        RedirectAttributes rAttr, 
        HttpServletRequest request, 
        HttpServletResponse response
	) 
	throws Exception;
}