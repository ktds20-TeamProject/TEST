package com.main.java.composition.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

public interface SurveyQuestionCompoController 
{	
	public ModelAndView insertVO
	(
        /* 매개변수 영역 */
        
        RedirectAttributes rAttr, 
        HttpServletRequest request, 
        HttpServletResponse response
	) 
	throws Exception;
}