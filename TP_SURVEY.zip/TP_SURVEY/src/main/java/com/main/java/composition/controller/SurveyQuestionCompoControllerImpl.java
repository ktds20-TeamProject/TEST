package com.main.java.composition.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.main.java.admin.vo.AdminIdInfoVO;
import com.main.java.composition.service.SurveyQuestionCompoService;
import com.main.java.composition.vo.ChoiceInfoVO;
import com.main.java.composition.vo.MatrixChoiceVO;
import com.main.java.composition.vo.MatrixQuestionVO;
import com.main.java.composition.vo.MultipleChoiceVO;
import com.main.java.composition.vo.QuestionInfoVO;
import com.main.java.composition.vo.SubjectiveChoiceVO;
import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;

@Controller("compositionController")
public class SurveyQuestionCompoControllerImpl implements SurveyQuestionCompoController 
{
	// <서비스 인터페이스 객체에 대한 자동 의존성 주입>
	@Autowired
	private SurveyQuestionCompoService surveyQuestionCompoService;
	
	// <VO 객체 11(=1+6+4)개에 대한 자동 의존성 주입>
	// 1. admin 패키지 : 1개
	@Autowired
    AdminIdInfoVO adminIdInfoVO;
	// 2. survey 패키지 : 4개
	@Autowired
    BasicSurveyInfoVO basicSurveyInfoVO;
	@Autowired
    AddSurveyInfoVO addSurveyInfoVO;
	@Autowired
    IdCertificationVO idCertificationVO;
	@Autowired
	AddInfoCollectVO addInfoCollectVO;
	// 3. composition 패키지 : 6개
	@Autowired
	ChoiceInfoVO choiceInfoVO;
	@Autowired
	MatrixChoiceVO matrixChoiceVO;
	@Autowired
	MatrixQuestionVO matrixQuestionVO;
	@Autowired
	MultipleChoiceVO multipleChoiceVO;
	@Autowired
	QuestionInfoVO questionInfoVO;
	@Autowired
	SubjectiveChoiceVO subjectiveChoiceVO;
	
	// <VO 별 처리 결과를 받는 변수>
	// [survey] 패키지
	int basicSurveyInfoVO_Result;
	int addSurveyInfoVO_Result;
	int idCertificationVO_Result;
	int addInfoCollectVO_Result;
	
	// [composition(survey_new)] 패키지
	int choiceInfoVO_Result;
	int matrixChoiceVO_Result;
	int matrixQuestionVO_Result;
	int multipleChoiceVO_Result;
	int questionInfoVO_Result;
	int subjectiveChoiceVO_Result;
	
	@Override
	@RequestMapping(value = "/survey_new/admin_question_compo.do", method = RequestMethod.GET)
	public ModelAndView survey_question_compo_main(HttpServletRequest request, HttpServletResponse response) 
	{
		String viewName = (String)request.getAttribute("viewName");	
		System.out.println("viewName : "+viewName);
		ModelAndView mav = new ModelAndView();
		mav.setViewName(viewName);
		return mav;
	}
	
	@Override
	@RequestMapping(value = "/survey_new/insert.do", method = RequestMethod.POST)
	public ModelAndView insertVO
	(
		/* 매개변수 영역 */
		
		RedirectAttributes rAttr, 
		HttpServletRequest request, 
		HttpServletResponse response
	) 
	throws Exception
	{
		/* 실행 영역 */
		
		// <인코딩 방식 처리>
		request.setCharacterEncoding("utf-8");
		
		// <세션 처리>
		// 1. 이전 페이지에서 넘어온 세션 값을 모두 이곳에 남겨야 한다.
		// 2. 세션 객체를 먼저 호출하고, 이후 저장된 세션 Attribute를 가져온다.
		// 3. 단, 다른 테이블과 중복된 컬럼은 입력받은 최초 테이블에서 호출한다.
		// 4-1. 먼저 세션 객체를 호출한다.
		HttpSession session = request.getSession();
		
		// 4-2. [survey] 패키지의 BasicSurveyInfo 에 대한 세션 Attribute 호출
		String admin_id = (String) session.getAttribute("admin_id");
		String survey_id_num = (String) session.getAttribute("survey_id_num");
		String survey_type = (String) session.getAttribute("survey_type");
		String admin_title = (String) session.getAttribute("admin_title");
		Date survey_start_date = (Date) session.getAttribute("survey_start_date");
		Date survey_end_date = (Date) session.getAttribute("survey_end_date");
		String title_input = (String) session.getAttribute("title_input");
		String survey_notice = (String) session.getAttribute("survey_notice");
		String attached_image = (String) session.getAttribute("attached_image");
		String survey_end_notice = (String) session.getAttribute("survey_end_notice");
		Date survey_creation_date = (Date) session.getAttribute("survey_creation_date");
		Date last_modify_date = (Date) session.getAttribute("last_modify_date");
		String is_last_modify = (String) session.getAttribute("is_last_modify");
		String is_collect_data = (String) session.getAttribute("is_collect_data");
		String is_limit_respondent = (String) session.getAttribute("is_limit_respondent");
		String limit_respondent_num = (String) session.getAttribute("limit_respondent_num");
		
		// 4-3. [survey] 패키지의 AddSurveyInfo 에 대한 세션 Attribute 호출
		String is_anonymous_respondent = (String) session.getAttribute("is_anonymous_respondent");
		String is_collect_add_info = (String) session.getAttribute("is_collect_add_info");
		String is_certify_id = (String) session.getAttribute("is_certify_id");
		
		// 4-4. [survey] 패키지의 IdCertificationVO 에 대한 세션 Attribute 호출
		String certification_notice = (String) session.getAttribute("certification_notice");
		String certification_info = (String) session.getAttribute("certification_info");
		
		// 4-5. [survey] 패키지의 AddInfoCollectVO 에 대한 세션 Attribute 호출
		String gender = (String) session.getAttribute("gender");
		String age = (String) session.getAttribute("age");
		String education = (String) session.getAttribute("education");
		String marriage = (String) session.getAttribute("marriage");
		String salary = (String) session.getAttribute("salary");
		String religion = (String) session.getAttribute("religion");
		
		// 5. 세션이 잘 넘어왔는지 이클립스 콘솔창에 변수 출력으로 확인해본다.
		System.out.println("<세션 정보>");
		System.out.println("1. [survey] 패키지의 BasicSurveyInfo 에 대한 세션 Attribute 호출");
		System.out.println("admin_id : "+admin_id);
		System.out.println("survey_id_num : "+survey_id_num);
		System.out.println("survey_type : "+survey_type);
		System.out.println("admin_title : "+admin_title);
		System.out.println("survey_start_date : "+survey_start_date);
		System.out.println("survey_end_date : "+survey_end_date);
		System.out.println("title_input : "+title_input);
		System.out.println("survey_notice : "+survey_notice);
		System.out.println("attached_image : "+attached_image);
		System.out.println("survey_end_notice : "+survey_end_notice);
		System.out.println("survey_creation_date : "+survey_creation_date);
		System.out.println("last_modify_date : "+last_modify_date);
		System.out.println("is_last_modify : "+is_last_modify);
		System.out.println("is_collect_data : "+is_collect_data);
		System.out.println("is_limit_respondent : "+is_limit_respondent);
		System.out.println("limit_respondent_num : "+limit_respondent_num);
		System.out.println();
		System.out.println("2. [survey] 패키지의 AddSurveyInfo 에 대한 세션 Attribute 호출");
		System.out.println("is_anonymous_respondent : "+is_anonymous_respondent);
		System.out.println("is_collect_add_info : "+is_collect_add_info);
		System.out.println("is_certify_id : "+is_certify_id);
		System.out.println();
		System.out.println("3. [survey] 패키지의 IdCertificationVO 에 대한 세션 Attribute 호출");
		System.out.println("certification_notice : "+certification_notice);
		System.out.println("certification_info : "+certification_info);
		System.out.println();
		System.out.println("4. [survey] 패키지의 AddInfoCollectVO 에 대한 세션 Attribute 호출");
		System.out.println("gender : "+gender);
		System.out.println("age : "+age);
		System.out.println("education : "+education);
		System.out.println("marriage : "+marriage);
		System.out.println("salary : "+salary);
		System.out.println("religion : "+religion);
		System.out.println();
		
		// <폼 데이터 처리 및 출력>
		// 1. 모든 폼 데이터가 단일 데이터 뿐만 아니라 배열 데이터로 넘어온다.
		// 2. 고로, 배열 데이터를 컬렉션 객체에 저장하여 이를 SqlSession에 넘겨야 한다.
		// 3. 배열의 차수가 낮은 데이터는 맵에 바로 저장하면 된다.
		
		System.out.println("<폼 데이터 정보>");
		
		// 4-1. 보기 정보(QUESTION_INFO) 테이블 관련 폼 데이터 받기
		System.out.println("1. 보기 정보 테이블");
		
		// 0). SqlSession에 넘길 Map 생성
		Map<String, Object> question_info_map = new HashMap<>();
		
        // 1) 테이블 맵 데이터의 리스트 생성
        List<Map<String, Object>> question_info_list = new ArrayList<>();
        
		// 2) Map에 넘길 컬럼정보에 대한 리스트 생성
		List<String> page_num_list = new ArrayList<>();
		List<String> question_id_num_list = new ArrayList<>();
		List<String> question_type_list = new ArrayList<>();
		List<String> question_contents_list = new ArrayList<>();
		List<String> choice_description_list = new ArrayList<>();
		List<String> is_required_response_list = new ArrayList<>();
		
		// 3) 폼 데이터 순회 저장 및 출력
		// i : 페이지 순번 == (페이지 번호 - 1)
		for(int i = 0; i < request.getParameterValues("page_num").length; i++)
		{
		    // 페이지 번호 출력
            System.out.println("[PAGE "+i+"]");
		    
		    // 컬럼정보에 대한 리스트에 폼데이터 저장
            page_num_list.add(i, request.getParameterValues("page_num")[i]);
            
            // 저장된 폼 데이터 출력
            System.out.println("page_num : "+page_num_list.get(i));
            
            // j : 질문 순번 == (질문 번호 - 1)
		    for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
		    {
		        // 컬럼정보에 대한 리스트에 폼데이터 저장
	            question_id_num_list.add(j, request.getParameterValues("question_id_num_p"+(i+1))[j]);
	            question_type_list.add(j, request.getParameterValues("question_type_p"+(i+1))[j]);
	            question_contents_list.add(j, request.getParameterValues("question_contents_p"+(i+1))[j]);
	            choice_description_list.add(j, request.getParameterValues("choice_description_p"+(i+1))[j]);
	            is_required_response_list.add(j, request.getParameterValues("is_required_response_p"+(i+1))[j]);
	            
	            // 테이블 맵의 리스트 내에 컬럼정보 리스트의 요소를 저장
	            // 테이블 맵 : question_info_list.get(j)
	            question_info_list.get(j).put("page_num", page_num_list.get(i));
	            question_info_list.get(j).put("question_id_num", question_id_num_list.get(j));
	            question_info_list.get(j).put("question_type", question_type_list.get(j));
	            question_info_list.get(j).put("question_contents", question_contents_list.get(j));
	            question_info_list.get(j).put("choice_description", choice_description_list.get(j));
	            question_info_list.get(j).put("is_required_response", is_required_response_list.get(j));
	            
	            // 저장된 폼데이터 출력
	            System.out.println("question_id_num_p"+(i+1)+" : "+question_id_num_list.get(j));
	            System.out.println("question_type_p"+(i+1)+" : "+question_type_list.get(j));
	            System.out.println("question_contents_p"+(i+1)+" : "+question_contents_list.get(j));
	            System.out.println("choice_description_p"+(i+1)+" : "+choice_description_list.get(j));
	            System.out.println("is_required_response_p"+(i+1)+" : "+is_required_response_list.get(j));
		    }
		    
		    // 마지막 페이지의 경우, 맵에 리스트를 저장
		    if(i == request.getParameterValues("page_num").length - 1)
            {
		        question_info_map.put("survey_id_num", survey_id_num);
	            question_info_map.put("question_info_list", question_info_list);
            }
		}
		
		// 4-2. 보기 정보(CHOICE_INFO) 테이블 관련 폼 데이터 받기
        System.out.println("2. 보기 정보 테이블");
        
        // 0). SqlSession에 넘길 Map 생성
        Map<String, Object> choice_info_map = new HashMap<>();
        
        // 1) 테이블 맵 데이터의 리스트 생성
        List<Map<String, Object>> choice_info_list = new ArrayList<>();
        
        // 2) Map에 넘길 컬럼정보에 대한 리스트 생성
        List<String> choice_num_list = new ArrayList<>();
        List<String> choice_contents_list = new ArrayList<>();
        List<String> choice_file_path_list = new ArrayList<>();
        
        // 3) 폼 데이터 순회 저장 및 출력
        // i : 페이지 순번 == (페이지 번호 - 1)
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 출력
            System.out.println("[PAGE "+i+"]");
            
            // j : 질문 순번 == (질문 번호 - 1)
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 컬럼정보에 대한 리스트에 폼데이터 저장
                choice_description_list.add(j, request.getParameterValues("choice_description_p"+(i+1))[j]);
                
                // 저장된 폼데이터 출력
                System.out.println("choice_description_p"+(i+1)+" : "+choice_description_list.get(j));
                
                // k : 보기 순번 == (보기 번호 - 1)
                for(int k = 0; k < request.getParameterValues("choice_num_p"+(i+1)+"_q"+(j+1)).length; k++)
                {
                    // 컬럼정보에 대한 리스트에 폼데이터 저장
                    choice_num_list.add(k, request.getParameterValues("choice_num_p"+(i+1)+"_q"+(j+1))[k]);
                    choice_contents_list.add(k, request.getParameterValues("choice_contents_p"+(i+1)+"_q"+(j+1))[k]);
                    choice_file_path_list.add(k, request.getParameterValues("choice_file_path_p"+(i+1)+"_q"+(j+1))[k]);
                    
                    // 테이블 맵의 리스트 내에 컬럼정보 리스트의 요소를 저장
                    // 테이블 맵 : choice_info_list.get(k)
                    choice_info_list.get(k).put("choice_num", choice_num_list.get(j));
                    choice_info_list.get(k).put("choice_contents", choice_contents_list.get(j));
                    choice_info_list.get(k).put("choice_file_path", choice_file_path_list.get(j));
                    
                    // 저장된 폼 데이터 출력
                    System.out.println("choice_num_p"+(i+1)+"_q"+(j+1)+" : "+choice_num_list.get(k));
                    System.out.println("choice_contents_p"+(i+1)+"_q"+(j+1)+" : "+choice_contents_list.get(k));
                    System.out.println("choice_file_path_p"+(i+1)+"_q"+(j+1)+" : "+choice_file_path_list.get(k));
                }
            }
            
            // 마지막 페이지의 경우, 맵에 리스트를 저장
            if(i == request.getParameterValues("page_num").length - 1)
            {
                choice_info_map.put("survey_id_num", survey_id_num);
                choice_info_map.put("choice_info_list", choice_info_list);
            }
        }
        
        // 4-3. 객관식 보기(MULTIPLE_CHOICE) 테이블 관련 폼 데이터 받기
        System.out.println("3. 객관식 보기 테이블");
        
        // 0). SqlSession에 넘길 Map 생성
        Map<String, Object> multiple_choice_map = new HashMap<>();
        
        // 1) 테이블 맵 데이터의 리스트 생성
        List<Map<String, Object>> multiple_info_list = new ArrayList<>();
        
        // 2) Map에 넘길 컬럼정보에 대한 리스트 생성
        List<String> choice_count_list = new ArrayList<>();
        List<String> is_other_choice_list = new ArrayList<>();
        List<String> min_multiple_choice_list = new ArrayList<>();
        List<String> max_multiple_choice_list = new ArrayList<>();
        
        // 3) 폼 데이터 순회 저장 및 출력
        // i : 페이지 순번 == (페이지 번호 - 1)
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 출력
            System.out.println("[PAGE "+i+"]");
            
            // j : 질문 순번 == (질문 번호 - 1)
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 컬럼정보에 대한 리스트에 폼데이터 저장
                choice_count_list.add(j, request.getParameterValues("choice_count_p"+(i+1))[j]);
                is_other_choice_list.add(j, request.getParameterValues("is_other_choice_p"+(i+1))[j]);
                min_multiple_choice_list.add(j, request.getParameterValues("min_multiple_choice_p"+(i+1))[j]);
                max_multiple_choice_list.add(j, request.getParameterValues("max_multiple_choice_p"+(i+1))[j]);
             
                // 테이블 맵의 리스트 내에 컬럼정보 리스트의 요소를 저장
                // 테이블 맵 : multiple_info_list.get(j)
                multiple_info_list.get(j).put("choice_count", choice_description_list.get(i));
                multiple_info_list.get(j).put("is_other_choice", choice_num_list.get(j));
                multiple_info_list.get(j).put("min_multiple_choice", choice_contents_list.get(j));
                multiple_info_list.get(j).put("max_multiple_choice", choice_file_path_list.get(j));
                
                // 저장된 폼 데이터 출력
                System.out.println("choice_count_p"+(i+1)+" : "+choice_count_list);
                System.out.println("is_other_choice_p"+(i+1)+" : "+is_other_choice_list);
                System.out.println("min_multiple_choice_p"+(i+1)+" : "+min_multiple_choice_list);
                System.out.println("max_multiple_choice_p"+(i+1)+" : "+max_multiple_choice_list);
            }
            
            // 마지막 페이지의 경우, 맵에 리스트를 저장
            if(i == request.getParameterValues("page_num").length - 1)
            {
                multiple_choice_map.put("survey_id_num", survey_id_num);
                multiple_choice_map.put("multiple_info_list", multiple_info_list);
            }
        }
        
        // 4-4. 주관식 보기(SUBJECTIVE_CHOICE) 테이블 관련 폼 데이터 받기
        System.out.println("4. 주관식 보기 테이블");
        
        // 0) SqlSession에 넘길 Map 생성
        Map<String, Object> subjective_choice_map = new HashMap<>();
        
        // 1) 테이블 맵 데이터의 리스트 생성
        List<Map<String, Object>> subjective_choice_list = new ArrayList<>(); 
        
        // 2) Map에 넘길 컬럼정보에 대한 리스트 생성
        List<String> is_personal_info_list = new ArrayList<>();
        List<String> is_duplicate_list = new ArrayList<>();
        
        // 3) 폼 데이터 순회 저장 및 출력
        // i : 페이지 순번 == (페이지 번호 - 1)
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 출력
            System.out.println("[PAGE "+i+"]");
            
            // j : 질문 순번 == (질문 번호 - 1)
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 컬럼정보에 대한 리스트에 폼데이터 저장
                is_personal_info_list.add(j, request.getParameterValues("is_personal_info_p"+(i+1))[j]);
                is_duplicate_list.add(j, request.getParameterValues("is_duplicate_p"+(i+1))[j]);
                
                // 테이블 맵의 리스트 내에 컬럼정보 리스트의 요소를 저장
                // 테이블 맵 : subjective_choice_list.get(j)
                subjective_choice_list.get(j).put("is_personal_info", choice_description_list.get(i));
                subjective_choice_list.get(j).put("is_duplicate", choice_num_list.get(j));
                
                // 저장된 폼 데이터 출력
                System.out.println("is_personal_info_p"+(i+1)+" : "+is_personal_info_list.get(j));
                System.out.println("is_duplicate_p"+(i+1)+" : "+is_duplicate_list.get(j));
            }
            
            // 마지막 페이지의 경우, 맵에 리스트를 저장
            if(i == request.getParameterValues("page_num").length - 1)
            {
                subjective_choice_map.put("survey_id_num", survey_id_num);
                subjective_choice_map.put("subjective_choice_list", subjective_choice_list);
            }
        }
        
        // 4-5. 표형-행-질문(MATRIX_QUESTION) 테이블 관련 폼 데이터 받기
        System.out.println("5. 표형-행-질문 테이블");
        
        // 0). SqlSession에 넘길 Map 생성
        Map<String, Object> matrix_question_map = new HashMap<>();
        
        // 1) 테이블 맵 데이터의 리스트 생성
        List<Map<String, Object>> matrix_question_list = new ArrayList<>();
        
        // 2) Map에 넘길 컬럼정보에 대한 리스트 생성
        List<String> matrix_num_list = new ArrayList<>();
        List<String> matrix_contents_list = new ArrayList<>();
        
        // 3) 폼 데이터 순회 저장 및 출력
        // i : 페이지 순번 == (페이지 번호 - 1)
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 출력
            System.out.println("[PAGE "+i+"]");
            
            // j : 질문 순번 == (질문 번호 - 1)
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // k : 표형(행) 질문 순번 == (표형 행 질문 번호 - 1)
                for(int k = 0; k < request.getParameterValues("matrix_num_p"+(i+1)+"_q"+(j+1)).length; k++)
                {
                    // 컬럼정보에 대한 리스트에 폼데이터 저장
                    matrix_num_list.add(k, request.getParameterValues("matrix_num_p"+(i+1)+"_q"+(j+1))[k]);
                    matrix_contents_list.add(k, request.getParameterValues("matrix_contents_p"+(i+1)+"_q"+(j+1))[k]);
                    
                    // 테이블 맵의 리스트 내에 컬럼정보 리스트의 요소를 저장
                    // 테이블 맵 : matrix_question_list.get(k)
                    matrix_question_list.get(k).put("matrix_num", matrix_num_list.get(i));
                    matrix_question_list.get(k).put("matrix_contents", matrix_contents_list.get(j));
                    
                    // 저장된 폼 데이터 출력
                    System.out.println("matrix_num_p"+(i+1)+"_q"+(j+1)+" : "+matrix_num_list.get(k));
                    System.out.println("matrix_contents_p"+(i+1)+"_q"+(j+1)+" : "+matrix_contents_list.get(k));
                }
            }
            
            // 마지막 페이지의 경우, 맵에 리스트를 저장
            if(i == request.getParameterValues("page_num").length - 1)
            {
                matrix_question_map.put("survey_id_num", survey_id_num);
                matrix_question_map.put("matrix_question_list", matrix_question_list);
            }
        }
        
        // 4-6. 표형-열-보기(MATRIX_CHOICE) 테이블 관련 폼 데이터 받기
        System.out.println("6. 표형-열-보기 테이블");
        
        // 0). SqlSession에 넘길 Map 생성
        Map<String, Object> matrix_choice_map = new HashMap<>();
        
        // 1) 테이블 맵 데이터의 리스트 생성
        List<Map<String, Object>> matrix_choice_list = new ArrayList<>();
        
        // 2) Map에 넘길 컬럼정보에 대한 리스트 생성
        List<String> matrix_choice_num_list = new ArrayList<>();
        List<String> matrix_choice_contents_list = new ArrayList<>();
        
        // 3) 폼 데이터 순회 저장 및 출력
        // i : 페이지 순번 == (페이지 번호 - 1)
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 출력
            System.out.println("[PAGE "+i+"]");
            
            // j : 질문 순번 == (질문 번호 - 1)
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // k : 표형(열) 보기 순번 == (표형 열 보기 번호 - 1)
                for(int k = 0; k < request.getParameterValues("matrix_choice_num_p"+(i+1)+"_q"+(j+1)).length; k++)
                {
                    // 컬럼정보에 대한 리스트에 폼데이터 저장
                    matrix_choice_num_list.add(k, request.getParameterValues("matrix_choice_num_p"+(i+1)+"_q"+(j+1))[k]);
                    matrix_choice_contents_list.add(k, request.getParameterValues("matrix_choice_contents_p"+(i+1)+"_q"+(j+1))[k]);
                    
                    // 테이블 맵의 리스트 내에 컬럼정보 리스트의 요소를 저장
                    // 테이블 맵 : matrix_choice_list.get(k)
                    matrix_choice_list.get(k).put("matrix_choice_num", matrix_choice_num_list.get(i));
                    matrix_choice_list.get(k).put("matrix_choice_contents", matrix_choice_contents_list.get(j));
                    
                    // 저장된 폼 데이터 출력
                    System.out.println("matrix_choice_num_p"+(i+1)+"_q"+(j+1)+" : "+matrix_choice_num_list.get(k));
                    System.out.println("matrix_choice_contents_p"+(i+1)+"_q"+(j+1)+" : "+matrix_choice_contents_list.get(k));
                }
            }
            
            // 마지막 페이지의 경우, 맵에 리스트를 저장
            if(i == request.getParameterValues("page_num").length - 1)
            {
                matrix_choice_map.put("survey_id_num", survey_id_num);
                matrix_choice_map.put("page_num_list", page_num_list);
                matrix_choice_map.put("question_id_num_list", question_id_num_list);
                matrix_choice_map.put("matrix_choice_num_list", matrix_choice_num_list);
                matrix_choice_map.put("matrix_choice_contents_list", matrix_choice_contents_list);
            }
        }
		
		// <세션/폼에서 넘어온 데이터 VO에 저장>
		// 1. 넘어온 세션 데이터에 대해 각 VO에 모두 저장한다.
		// 2. 이번에는 아까와 달리 중복된 세션 데이터라도 빠짐없이 저장해야 한다.
        // -----------------------------------------------------------
		// 3-1. [survey] 패키지의 BasicSurveyInfo 에 setter로 저장
		basicSurveyInfoVO.setSurvey_id_num(survey_id_num);
		basicSurveyInfoVO.setSurvey_type(survey_type);
		basicSurveyInfoVO.setAdmin_title(admin_title);
		basicSurveyInfoVO.setSurvey_start_date(survey_start_date);
		basicSurveyInfoVO.setSurvey_end_date(survey_end_date);
		basicSurveyInfoVO.setAdmin_id(admin_id);
		basicSurveyInfoVO.setTitle_input(title_input);
		basicSurveyInfoVO.setSurvey_notice(survey_notice);
		basicSurveyInfoVO.setAttached_image(attached_image);
		basicSurveyInfoVO.setSurvey_end_notice(survey_end_notice);
		basicSurveyInfoVO.setLast_modify_date(last_modify_date);
		basicSurveyInfoVO.setIs_last_modify(is_last_modify);
		basicSurveyInfoVO.setIs_collect_data(is_collect_data);
		basicSurveyInfoVO.setIs_limit_respondent(is_limit_respondent);
		basicSurveyInfoVO.setLimit_respondent_num(limit_respondent_num);
		// -----------------------------------------------------------
		// 3-2. [survey] 패키지의 AddSurveyInfo 에 setter로 저장
		addSurveyInfoVO.setSurvey_id_num(survey_id_num);
		addSurveyInfoVO.setIs_anonymous_respondent(is_anonymous_respondent);
		addSurveyInfoVO.setIs_collect_add_info(is_collect_add_info);
		addSurveyInfoVO.setIs_certify_id(is_certify_id);
		// -----------------------------------------------------------
		// 3-3. [survey] 패키지의 IdCertificationVO 에 setter로 저장
		idCertificationVO.setSurvey_id_num(survey_id_num);
		idCertificationVO.setCertification_notice(certification_notice);
		idCertificationVO.setCertification_info(certification_info);
		// -----------------------------------------------------------
		// 3-4. [survey] 패키지의 AddInfoCollectVO 에 setter로 저장
		addInfoCollectVO.setSurvey_id_num(survey_id_num);
		addInfoCollectVO.setGender(gender);
		addInfoCollectVO.setAge(age);
		addInfoCollectVO.setEducation(education);
		addInfoCollectVO.setMarriage(marriage);
		addInfoCollectVO.setSalary(salary);
		addInfoCollectVO.setReligion(religion);
		
		// <카운트 변수 설정/출력 및 입력된 데이터에 대한 분기 처리>
		// 1. 넘어온 매개변수들 중 일부만 넘어올 수 있다.
		// 2. 넘어온 매개변수들의 입력된 상태에 맞춰서 처리해야 한다.
		// -----------------------------------------------------------
		System.out.println();
		System.out.println("<카운트 변수 정보>");
		
		// 3-1. 페이지 수 
		int page_count = request.getParameterValues("page_num").length;
		System.out.println("1. 페이지 수 : "+page_count);
		
		// 3-2. 페이지별 질문 수
		List<Integer> question_count = new ArrayList<>();
		System.out.println("2. 질문 수 : ");
		for(int i = 0; i < page_count; i++) // i : 페이지 순번
		{
		    // 페이지별 질문의 개수를 페이지 번호 별로 저장
		    question_count.add(i, request.getParameterValues("question_id_num_p"+(i+1)).length);
		    
		    // 페이지별 질문의 개수를 출력
		    System.out.println(i+" 페이지에 대한 질문 수 : "+question_count.get(i));
		}
		
		// 3-3. 질문별 표형(행) 질문 개수
		List<Integer> matrix_question_count_per_page = new ArrayList<>();
		List<List<Integer>> matrix_question_count = new ArrayList<>();
		System.out.println();
		System.out.println("3. 질문별 표형(행) 질문 개수 : ");
		
		// i : 페이지 순번(== 페이지 번호 - 1)
		for(int i = 0; i < page_count; i++)
		{
		    // 페이지 번호 출력
		    System.out.println("["+i+" 페이지]");
		    
		    // 페이지당 질문의 개수만큼 반복
		    for(int j = 0; j < question_count.get(i); j++)
		    {
		        // 페이지당 질문번호 단위로 표형 질문의 개수를 request 객체로부터 전달 받음
		        int matrix_question_count_per_question = request.getParameterValues("matrix_num_p"+(i+1)+"_q"+(j+1)).length;
		        
		        // 페이지당 질문번호 단위로 표형 질문의 개수를 저장
		        matrix_question_count_per_page.add(j, matrix_question_count_per_question);
		        
		        // 질문 번호 및 개수값 출력
                System.out.println(i+" 페이지의 "+j+"번 질문에 대한 표형(행) 질문의 개수 : "+matrix_question_count_per_page.get(j));
		    }
		    
		    // 페이지당 마지막 질문번호에 도달시 i+1 페이지의 matrix_question_count 에 저장 처리
		    matrix_question_count.add(i, matrix_question_count_per_page);
		    
		    // 청소
		    matrix_question_count_per_page.clear();
		}
		
		// 3-4. 질문별 표형(열) 보기 개수
        List<Integer> matrix_choice_count_per_page = new ArrayList<>();
        List<List<Integer>> matrix_choice_count = new ArrayList<>();
        System.out.println();
        System.out.println("4. 질문별 표형(열) 보기 개수 : ");
        
        // i : 페이지 순번(== 페이지 번호 - 1)
        for(int i = 0; i < page_count; i++)
        {
            // 페이지 번호 출력
            System.out.println("["+i+" 페이지]");
            
            // 페이지당 질문의 개수만큼 반복
            for(int j = 0; j < question_count.get(i); j++)
            {
                // 페이지당 질문번호 단위로 표형 질문의 개수를 request 객체로부터 전달 받음
                int matrix_choice_count_per_question = request.getParameterValues("matrix_num_p"+(i+1)+"_q"+(j+1)).length;
                
                // 페이지당 질문번호 단위로 표형 질문의 개수를 저장
                matrix_choice_count_per_page.add(j, matrix_choice_count_per_question);
                
                // 질문 번호 및 개수값 출력
                System.out.println(i+" 페이지의 "+j+"번 질문에 대한 표형(열) 보기의 개수 : "+matrix_choice_count_per_page.get(j));
            }
            
            // 페이지당 마지막 질문번호에 도달시 i+1 페이지의 matrix_question_count 에 저장 처리
            matrix_choice_count.add(i, matrix_choice_count_per_page);
            
            // 청소
            matrix_choice_count_per_page.clear();
        }
		// -----------------------------------------------------------
        
        /* [survey] 패키지 */
        
        // 4-1. BasicSurveyInfoVO 값 -> 넘어오면 처리 
        if(basicSurveyInfoVO != null)
        {
            basicSurveyInfoVO_Result = surveyQuestionCompoService.addBasicSurveyInfo(basicSurveyInfoVO);
        }
        
        // 4-2. AddSurveyInfoVO 값 -> 넘어오면 처리 
        if(addSurveyInfoVO != null)
        {
            addSurveyInfoVO_Result = surveyQuestionCompoService.addAddSurveyInfo(addSurveyInfoVO);
        }
        
        // 4-3. IdCertificationVO 값 -> 넘어오면 처리
        if(idCertificationVO != null)
        {
            idCertificationVO_Result = surveyQuestionCompoService.addIdCertification(idCertificationVO);
        }
        
        // 4-4. AddInfoCollectVO 값 -> 넘어오면 처리
        if(addInfoCollectVO != null)
        {
            addInfoCollectVO_Result = surveyQuestionCompoService.addAddInfoCollect(addInfoCollectVO);
        }
        
		// 4-5. ChoiceInfoVO 값 -> 넘어오면 처리  
		if(choiceInfoVO != null)
		{
			choiceInfoVO_Result = surveyQuestionCompoService.addChoiceInfo(choice_info_map, page_count, question_count);
		}
		
		// -----------------------------------------------------------
		
		/* [composition(new survey)] 패키지 */
		
		// 4-6. matrix_choice_map 값 -> 넘어오면 처리 
		if(matrix_choice_map != null)
		{
			matrixChoiceVO_Result = surveyQuestionCompoService.addMatrixChoice(matrix_choice_map, page_count, question_count);
		}
		
		// 4-7. matrix_question_map 값 -> 넘어오면 처리 
		if(matrix_question_map != null)
		{
			matrixQuestionVO_Result = surveyQuestionCompoService.addMatrixQuestion(matrix_question_map, page_count, question_count);
		}
		
		// 4-8. multiple_choice_map 값 -> 넘어오면 처리
		if(multiple_choice_map != null)
		{
			multipleChoiceVO_Result = surveyQuestionCompoService.addMultipleChoice(multiple_choice_map, page_count);
		}
		
		// 4-9. question_info_map 값 -> 넘어오면 처리
		if(question_info_map != null)
		{
			questionInfoVO_Result = surveyQuestionCompoService.addQuestionInfo(question_info_map, page_count);
		}
		
		// 4-10. subjective_choice_map 값 -> 넘어오면 처리
		if(subjective_choice_map != null)
		{
			subjectiveChoiceVO_Result = surveyQuestionCompoService.addSubjectiveChoice(subjective_choice_map, page_count);
		}
		
		// <뷰 처리>
		// 1. ModelAndView 객체에 view 주소값 전송
		// 2. 해당 주소값을 가진 ModelAndView 객체를 리턴시킴
		ModelAndView mav = new ModelAndView(); // 관리자 리스트 조회 화면으로 주소값을 전달
		mav.setViewName("/admin/admin_list"); // viewName을 "/admin/admin_list" 값으로 setter 메소드를 통해 저장
		return mav; // 해당 ModelAndView 객체를 tiles 라이브러리에서 처리하도록 ModelAndView 클래스 타입으로 반환 
	}
}