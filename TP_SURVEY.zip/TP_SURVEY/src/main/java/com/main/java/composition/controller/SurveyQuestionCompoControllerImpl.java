package com.main.java.composition.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.main.java.admin.vo.AdminIdInfoVO;
import com.main.java.composition.service.SurveyQuestionCompoService;
import com.main.java.composition.vo.ChoiceInfoVO;
import com.main.java.composition.vo.MatrixChoiceVO;
import com.main.java.composition.vo.MatrixQuestionVO;
import com.main.java.composition.vo.MultipleChoiceVO;
import com.main.java.composition.vo.QuestionInfoVO;
import com.main.java.composition.vo.SubjectiveChoiceVO;
import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;

@Controller("compositionController")
public class SurveyQuestionCompoControllerImpl implements SurveyQuestionCompoController 
{
	// <서비스 인터페이스 객체에 대한 자동 의존성 주입>
	@Autowired
	private SurveyQuestionCompoService surveyQuestionCompoService;
	
	// <VO 객체 11(=1+6+4)개에 대한 자동 의존성 주입>
	// 1. admin 패키지 : 1개
	@Autowired
    AdminIdInfoVO adminIdInfoVO;
	// 2. survey 패키지 : 4개
	@Autowired
    BasicSurveyInfoVO basicSurveyInfoVO;
	@Autowired
    AddSurveyInfoVO addSurveyInfoVO;
	@Autowired
    IdCertificationVO idCertificationVO;
	@Autowired
	AddInfoCollectVO addInfoCollectVO;
	// 3. composition 패키지 : 6개
	@Autowired
	ChoiceInfoVO choiceInfoVO;
	@Autowired
	MatrixChoiceVO matrixChoiceVO;
	@Autowired
	MatrixQuestionVO matrixQuestionVO;
	@Autowired
	MultipleChoiceVO multipleChoiceVO;
	@Autowired
	QuestionInfoVO questionInfoVO;
	@Autowired
	SubjectiveChoiceVO subjectiveChoiceVO;
	
	// <VO 별 처리 결과를 받는 변수>
	// [survey] 패키지
	int basicSurveyInfoVO_Result;
	int addSurveyInfoVO_Result;
	int idCertificationVO_Result;
	int addInfoCollectVO_Result;
	
	// <map 별 처리 결과를 받는 변수>
	// [composition(survey_new)] 패키지
	int choiceInfo_ResultMaps;
	int matrixChoice_ResultMaps;
	int matrixQuestion_ResultMaps;
	int multipleChoice_ResultMaps;
	int questionInfo_ResultMaps;
	int subjectiveChoice_ResultMaps;
	
	// 횟수 값을 받는 변수 (카운트 변수)
	int page_count;
	int question_count;
	int choice_count;
	int matrix_question_count;
	int matrix_choice_count;
	
	@Override
	@RequestMapping(value = "/survey_new/admin_question_compo.do", method = RequestMethod.GET)
	public ModelAndView survey_question_compo_main(HttpServletRequest request, HttpServletResponse response) 
	{
		String viewName = (String) request.getAttribute("viewName");	
		System.out.println("viewName : "+viewName);
		ModelAndView mav = new ModelAndView();
		mav.setViewName(viewName);
		return mav;
	}
	
	@Override
	@RequestMapping(value = "/survey_new/insert.do", method = RequestMethod.GET)
	public ModelAndView insertVO
	(
		/* 매개변수 영역 */
		
		RedirectAttributes rAttr, 
		HttpServletRequest request, 
		HttpServletResponse response
	) 
	throws Exception
	{
		/* 실행 영역 */
		
		// <인코딩 방식 처리>
		request.setCharacterEncoding("utf-8");
		
		// <세션 처리>
		// 1. 이전 페이지에서 넘어온 세션 값을 모두 이곳에 남겨야 한다.
		// 2. 세션 객체를 먼저 호출하고, 이후 저장된 세션 Attribute를 가져온다.
		// 3. 단, 다른 테이블과 중복된 컬럼은 입력받은 최초 테이블에서 호출한다.
		// 4-1. 먼저 세션 객체를 호출한다.
		HttpSession session = request.getSession();
		
		// 4-2. [survey] 패키지의 BasicSurveyInfo 에 대한 세션 Attribute 호출
		String admin_id = (String) session.getAttribute("admin_id");
		String survey_id_num = (String) session.getAttribute("survey_id_num");
		String survey_type = (String) session.getAttribute("survey_type");
		String admin_title = (String) session.getAttribute("admin_title");
		Date survey_start_date = (Date) session.getAttribute("survey_start_date");
		Date survey_end_date = (Date) session.getAttribute("survey_end_date");
		String title_input = (String) session.getAttribute("title_input");
		String survey_notice = (String) session.getAttribute("survey_notice");
		String attached_image = (String) session.getAttribute("attached_image");
		String survey_end_notice = (String) session.getAttribute("survey_end_notice");
		Date survey_creation_date = (Date) session.getAttribute("survey_creation_date");
		Date last_modify_date = (Date) session.getAttribute("last_modify_date");
		String is_last_modify = (String) session.getAttribute("is_last_modify");
		String is_limit_respondent = (String) session.getAttribute("is_limit_respondent");
		String limit_respondent_num = (String) session.getAttribute("limit_respondent_num");
		
		// 4-3. [survey] 패키지의 AddSurveyInfo 에 대한 세션 Attribute 호출
		String is_anonymous_respondent = (String) session.getAttribute("is_anonymous_respondent");
		String is_collect_add_info = (String) session.getAttribute("is_collect_add_info");
		String is_certify_id = (String) session.getAttribute("is_certify_id");
		
		// 4-4. [survey] 패키지의 IdCertificationVO 에 대한 세션 Attribute 호출
		String certification_notice = (String) session.getAttribute("certification_notice");
		String certification_info = (String) session.getAttribute("certification_info");
		
		// 4-5. [survey] 패키지의 AddInfoCollectVO 에 대한 세션 Attribute 호출
		String gender = (String) session.getAttribute("gender");
		String age = (String) session.getAttribute("age");
		String education = (String) session.getAttribute("education");
		String marriage = (String) session.getAttribute("marriage");
		String salary = (String) session.getAttribute("salary");
		String religion = (String) session.getAttribute("religion");
		
		// ** Garbage Data instead of Session Data ** //
		// 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
		// G1. [survey] 패키지의 BasicSurveyInfo
		admin_id = "aaaa";
		survey_id_num = "6";
		survey_type = "설문";
		admin_title = "관리용 제목 테스트1";
		survey_start_date = Date.valueOf("2022-10-24");
		survey_end_date = Date.valueOf("2022-10-31");
		title_input = "설문지 테스트 제목1";
		survey_notice = "저희 [(주)SORA_NETWORKS]의 서비스를 이용해 주셔서 감사합니다. \r\n"
		              + "고객님의 소중한 의견을 토대로 더 나은 모습을 보여드리기 위해 고객만족도 조사를 진행합니다. \r\n"
		              + "진솔한 고객의 소리를 부탁드립니다. \r\n"
		              + "감사합니다.";
		attached_image = "D:\\board\\article_image\\2\\YeonChoco(Edited).jpg";
		survey_end_notice = "저희 [(주)소라네트웍스]의 설문조사에 참여해주셔서 감사합니다.\r\n"
		                  + "고객님들의 소중한 의견을 토대로 보다 나은 서비스를 제공할 수 있도록 최선의 노력을 다하겠습니다. \r\n"
		                  + "감사합니다.";
		survey_creation_date = Date.valueOf("2022-10-24");
		last_modify_date = Date.valueOf("2022-10-25");
		is_last_modify = "false";
		String consent_procedure_count = "2";
		String consent_notice_1 = "㈜SORA_NETWORKS는 「개인정보보호법」에 의거하여, 아래와 같은 내용으로 개인정보를 수집하고 있습니다.\r\n"
		        + "귀하께서는 아래 내용을 자세히 읽어 보시고, 모든 내용을 이해하신 후에 동의 여부를 결정해 주시기 바랍니다.\r\n"
		        + "\r\n"
		        + "Ⅰ. 개인정보의 수집 및 이용 동의서\r\n"
		        + " - 이용자가 제공한 모든 정보는 다음의 목적을 위해 활용하며, 하기 목적 이외의 용도로는 사용되지 않습니다.\r\n"
		        + "\r\n"
		        + "① 개인정보 수집 항목 및 수집·이용 목적\r\n"
		        + " 가) 수집 항목 \r\n"
		        + "    - \r\n"
		        + " 나) 수집 및 이용 목적\r\n"
		        + "    -\r\n"
		        + "    -    \r\n"
		        + "    - \r\n"
		        + "\r\n"
		        + "② 개인정보 보유 및 이용기간\r\n"
		        + "    - \r\n"
		        + "\r\n"
		        + "③ 동의거부관리\r\n"
		        + " - 개인정보 수집 및 이용에 대해서는 거부할 수 있으며, 거부 시에는 (                 )가 불가합니다.";
		String consent_notice_2 = "㈜SORA_COMPANY는 「개인정보보호법」에 의거하여, 아래와 같은 내용으로 개인정보를 수집하고 있습니다.\r\n"
		        + "귀하께서는 아래 내용을 자세히 읽어 보시고, 모든 내용을 이해하신 후에 동의 여부를 결정해 주시기 바랍니다.\r\n"
		        + "\r\n"
		        + "Ⅰ. 개인정보의 수집 및 이용 동의서\r\n"
		        + " - 이용자가 제공한 모든 정보는 다음의 목적을 위해 활용하며, 하기 목적 이외의 용도로는 사용되지 않습니다.\r\n"
		        + "\r\n"
		        + "① 개인정보 수집 항목 및 수집·이용 목적\r\n"
		        + " 가) 수집 항목 \r\n"
		        + "    - \r\n"
		        + " 나) 수집 및 이용 목적\r\n"
		        + "    -\r\n"
		        + "    -    \r\n"
		        + "    - \r\n"
		        + "\r\n"
		        + "② 개인정보 보유 및 이용기간\r\n"
		        + "    - \r\n"
		        + "\r\n"
		        + "③ 동의거부관리\r\n"
		        + " - 개인정보 수집 및 이용에 대해서는 거부할 수 있으며, 거부 시에는 (                 )가 불가합니다.";
		is_limit_respondent = "true";
		limit_respondent_num = "9";
		
		// G2. [survey] 패키지의 AddSurveyInfo
		is_anonymous_respondent = "false";
		is_collect_add_info = "false";
		is_certify_id = "false";
		
		// G3. [survey] 패키지의 IdCertificationVO
		certification_notice = "이메일 주소를 입력하여 주십시오.";
		certification_info = "사용";
		
		// G4. [survey] 패키지의 AddInfoCollectVO
		gender = "true";
		age = "true";
		education = "true";
		marriage = "true";
		salary = "true";
		religion = "true";
		
		// 5-0. 세션이 잘 넘어왔는지 이클립스 콘솔창에 변수 출력으로 확인해본다.
		System.out.println("<세션 정보>");
		System.out.println("1. [survey] 패키지의 BasicSurveyInfo 에 대한 세션 Attribute 호출");
		System.out.println("admin_id : "+admin_id);
		System.out.println("survey_id_num : "+survey_id_num);
		System.out.println("survey_type : "+survey_type);
		System.out.println("admin_title : "+admin_title);
		System.out.println("survey_start_date : "+survey_start_date);
		System.out.println("survey_end_date : "+survey_end_date);
		System.out.println("title_input : "+title_input);
		System.out.println("survey_notice : "+survey_notice);
		System.out.println("attached_image : "+attached_image);
		System.out.println("survey_end_notice : "+survey_end_notice);
		System.out.println("survey_creation_date : "+survey_creation_date);
		System.out.println("last_modify_date : "+last_modify_date);
		System.out.println("is_last_modify : "+is_last_modify);
		System.out.println("is_limit_respondent : "+is_limit_respondent);
		System.out.println("limit_respondent_num : "+limit_respondent_num);
		System.out.println();
		System.out.println("2. [survey] 패키지의 AddSurveyInfo 에 대한 세션 Attribute 호출");
		System.out.println("is_anonymous_respondent : "+is_anonymous_respondent);
		System.out.println("is_collect_add_info : "+is_collect_add_info);
		System.out.println("is_certify_id : "+is_certify_id);
		System.out.println();
		System.out.println("3. [survey] 패키지의 IdCertificationVO 에 대한 세션 Attribute 호출");
		System.out.println("certification_notice : "+certification_notice);
		System.out.println();
		System.out.println("4. [survey] 패키지의 AddInfoCollectVO 에 대한 세션 Attribute 호출");
		System.out.println("gender : "+gender);
		System.out.println("age : "+age);
		System.out.println("education : "+education);
		System.out.println("marriage : "+marriage);
		System.out.println("salary : "+salary);
		System.out.println("religion : "+religion);
		System.out.println();
		
		// <폼 데이터 처리 및 출력>
		// 1. 모든 폼 데이터가 단일 데이터 뿐만 아니라 배열 데이터로 넘어온다.
		// 2. 고로, 배열 데이터를 컬렉션 객체에 저장하여 이를 SqlSession에 넘겨야 한다.
		// 3. 배열의 차수가 낮은 데이터는 맵에 바로 저장하면 된다.
		
		System.out.println("<폼 데이터 정보>");
		
		// 4-1. 질문 정보(QUESTION_INFO) 테이블 관련 폼 데이터 받기
		System.out.println("1. 질문 정보 테이블");
		
        // 0). SqlSession에 넘길 Map 생성
        Map<String, Object> question_info_map = new HashMap<>();
        
        // 1) 테이블 맵 데이터의 리스트 생성
        List<Map<String, Object>> question_info_innerMap_list = new ArrayList<>();
        
		// 2) Map에 넘길 컬럼정보에 대한 리스트 생성
		List<String> page_num_list = new ArrayList<>();
		List<String> question_id_num_list = new ArrayList<>();
		List<String> question_type_list = new ArrayList<>();
		List<String> question_contents_list = new ArrayList<>();
		List<String> choice_description_list = new ArrayList<>();
		List<String> is_required_response_list = new ArrayList<>();
		
		// 3) 폼 데이터 순회 저장 및 출력
		// 페이지 카운트 변수 설정
		// page_count = request.getParameterValues("page_num").length;
		
		// ** Garbage Insert ** //
		// 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
		page_num_list.add("1");
		page_num_list.add("2");
		page_count = page_num_list.size(); // page_num_list.size() == 2
		
		List<Integer> question_counts = new ArrayList<>();
        question_counts.add(5); // 1 페이지 question_count.get(0) == 5
        question_counts.add(3); // 2 페이지 question_count.get(1) == 3
        
        // 질문 순번 j에 대한 누적 합산 변수 설정
        int accumulated_j = 0;
        
		// i : 페이지 순번 == (페이지 번호 - 1)
		for(int i = 0; i < page_count; i++)
		{
		    // 페이지 번호 출력
            System.out.println("[PAGE "+(i+1)+"]");
		    
            // 질문 개수를 받는 변수 설정
            // question_count = request.getParameterValues("question_id_num_p"+(i+1)).length;
            
            // ** Garbage Insert ** //
            // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
            question_count = question_counts.get(i);
            System.out.println("question_counts.get("+i+") : "+question_counts.get(i));
            
            // j : 질문 순번 == (질문 번호 - 1)
		    for(int j = 0; j < question_count; j++)
		    {
		        Map<String, Object> question_info_innerMap = new HashMap<>();
		        
		        // 컬럼정보에 대한 리스트에 폼데이터 저장
	            // question_id_num_list.add(request.getParameterValues("question_id_num_p"+(i+1))[j]);
	            // question_type_list.add(request.getParameterValues("question_type_p"+(i+1))[j]);
	            // question_contents_list.add(request.getParameterValues("question_contents_p"+(i+1))[j]);
	            // choice_description_list.add(request.getParameterValues("choice_description_p"+(i+1))[j]);
	            // is_required_response_list.add(request.getParameterValues("is_required_response_p"+(i+1))[j]);
	            
	            // ** Replacement to Garbage Data from Form Data ** //
                // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
	            // 리스트 재삽입
                if(i == 0 && j == 0) // 첫번째 문항의 경우
                {
                    question_id_num_list.add("1");
                    question_type_list.add("객관식(기본)");
                    choice_description_list.add("VERY GOOD, GOOD, NOT BAD, BAD, TOO BAD : 5~1 POINTS");
                    question_contents_list.add
                    (
                        "QUESTION TEST1\r\n"
                      + "필수 응답이 체크되어 있습니다.\r\n"
                      + "객관식(기본) 문항입니다."
                    );
                    is_required_response_list.add("true");
                }
                else if(i == 0 && j == 1) // 두번째 문항의 경우
                {
                    question_id_num_list.add("2");
                    question_type_list.add("객관식(기본)");
                    choice_description_list.add("보기 설명 테스트1-1 입니다.");
                    question_contents_list.add
                    (
                        "테스트1 객관식(드롭다운) 문항입니다.\r\n"
                      + "필수응답이 체크되어 있지 않습니다."
                    );
                    is_required_response_list.add("false");
                }
                else if(i == 0 && j == 2) // 세번째 문항의 경우
                {
                    question_id_num_list.add("3");
                    question_type_list.add("객관식(표형)");
                    choice_description_list.add("보기 설명 테스트1-2 입니다.");
                    question_contents_list.add
                    (
                        "본 문항은 객관식(표형) 테스트1 입니다.\r\n"
                      + "필수응답이 체크되어 있습니다."
                    );
                    is_required_response_list.add("true");
                }
                else if(i == 0 && j == 3) // 네번째 문항의 경우
                {
                    question_id_num_list.add("4");
                    question_type_list.add("객관식(기본)");
                    choice_description_list.add("보기 설명 테스트1-3 입니다.");
                    question_contents_list.add
                    (
                        "객관식(기본) 문항 테스트1 입니다.\r\n"
                      + "필수응답이 체크되어 있습니다.\r\n"
                      + "보기가 무작위로 정렬되어 있습니다.\r\n"
                      + "분기적용이 체크되어 있습니다."
                    );
                    is_required_response_list.add("true");
                }
                else if(i == 0 && j == 4)// 다섯번째 문항의 경우
                {
                    question_id_num_list.add("5");
                    question_type_list.add("객관식(기본)");
                    choice_description_list.add("보기 설명 테스트1-4 입니다.");
                    question_contents_list.add
                    (
                        "객관식(드롭다운) 문항입니다.\r\n"
                      + "필수응답이 체크되어 있습니다.\r\n"
                      + "분기적용이 체크해제 되어 있습니다.\r\n"
                      + "보기선택수 : 최소 1 ~ 최대 3개입니다.\r\n"
                      + "보기는 순서대로 정렬되어 있습니다."
                    );
                    is_required_response_list.add("true");
                }
                else if(i == 1 && j == 0) // 첫번째 문항의 경우
                {
                    question_id_num_list.add("6");
                    question_type_list.add("주관식");
                    choice_description_list.add("N/A");
                    question_contents_list.add
                    (
                        "주관식 테스트1 질문입니다.\r\n"
                      + "개인정보수집, 중복 값 제한이 체크되어 있습니다."
                    );
                    is_required_response_list.add("true");
                }
                else if(i == 1 && j == 1) // 두번째 문항의 경우
                {
                    question_id_num_list.add("7");
                    question_type_list.add("주관식");
                    choice_description_list.add("N/A");
                    question_contents_list.add
                    (
                        "본 문항은 주관식 테스트1 입니다.\r\n"
                      + "개인정보수집이 체크되어 있습니다.\r\n"
                      + "중복 값 제한은 체크되어 있지 않습니다."
                    );
                    is_required_response_list.add("true");
                }
                else if(i == 1 && j == 2) // 세번째 문항의 경우
                {
                    question_id_num_list.add("8");
                    question_type_list.add("주관식");
                    choice_description_list.add("N/A");
                    question_contents_list.add
                    (
                        "주관식 8번 문항 테스트 1 입니다.\r\n"
                      + "필수응답이 체크되어 있습니다.\r\n"
                      + "개인정보수집은 체크되어 있지 않습니다.\r\n"
                      + "중복 값 제한이 체크되어 있습니다."
                    );
                    is_required_response_list.add("true");
                }
                
                // 테이블 맵에 컬럼정보 리스트의 요소를 저장
                // 테이블 맵 : question_info_innerMap == question_info_list.get(i).get(j)
                question_info_innerMap.put("survey_id_num", survey_id_num);
                question_info_innerMap.put("page_num", page_num_list.get(i));
                question_info_innerMap.put("question_id_num", question_id_num_list.get(accumulated_j+j));
                question_info_innerMap.put("question_type", question_type_list.get(accumulated_j+j));
                question_info_innerMap.put("question_contents", question_contents_list.get(accumulated_j+j));
                question_info_innerMap.put("question_id_num", question_id_num_list.get(accumulated_j+j));
                question_info_innerMap.put("choice_description", choice_description_list.get(accumulated_j+j));
                question_info_innerMap.put("is_required_response", is_required_response_list.get(accumulated_j+j));
                
                // 저장된 폼데이터 출력
                System.out.println("survey_id_num : "+survey_id_num);
                System.out.println("page_num : "+page_num_list.get(i));
                System.out.println("question_id_num_p"+(i+1)+" : "+question_id_num_list.get(accumulated_j+j));
                System.out.println("question_type_p"+(i+1)+" : "+question_type_list.get(accumulated_j+j));
                System.out.println("question_contents_p"+(i+1)+" : "+question_contents_list.get(accumulated_j+j));
                System.out.println("choice_description_p"+(i+1)+" : "+choice_description_list.get(accumulated_j+j));
                System.out.println("is_required_response_p"+(i+1)+" : "+is_required_response_list.get(accumulated_j+j));
                
                // innerMap 리스트에 저장 및 출력
                question_info_innerMap_list.add(question_info_innerMap);
                System.out.println("question_info_innerMap_list.get("+(accumulated_j+j)+") : "+question_info_innerMap_list.get(accumulated_j+j));
                
                // 마지막 페이지 순번에 도달한 경우
                if(j == question_count - 1)
                {
                    // 그 순번 값을 누적 카운트 변수에 저장
                    accumulated_j += j+1;
                }
		    }
		    
		    // 마지막 페이지의 경우, 맵에 리스트를 저장
		    if(i == page_count - 1)
            {
		        // 이 question_info_innerMap_list를 question_info_map 컬렉션 객체에 "list" 라는 key 값으로 지정하여 저장
		        question_info_map.put("list", question_info_innerMap_list);
            }
		}
		
		// 4-2. 보기 정보(CHOICE_INFO) 테이블 관련 폼 데이터 받기
		System.out.println("-------------------------------------");
        System.out.println("2. 보기 정보 테이블");
        
        // 0). SqlSession에 넘길 Map 생성
        Map<String, Object> choice_info_map = new HashMap<>();
        
        // Map에 넘길 컬럼정보에 대한 리스트 생성
        List<String> choice_num_list = new ArrayList<>();
        List<String> choice_contents_list = new ArrayList<>();
        List<String> choice_file_path_list = new ArrayList<>();
        
        // 3) 폼 데이터 순회 저장 및 출력
        // 보기 카운트용 리스트 선언
        List<Integer> choice_counts = new ArrayList<>();
        
        // 누적 카운트 합산 변수 초기화
        accumulated_j = 0;
        
        // ** Garbage Insert ** //
        // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
        // 보기 카운트 내부 리스트에 데이터 삽입
        for(int i = 0; i < page_count; i++)
        {
            // ** Garbage Insert ** //
            // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
            question_count = question_counts.get(i);
            System.out.println("question_counts.get("+i+") : "+question_counts.get(i));
            
            for(int j = 0; j < question_count; j++)
            {
                if(i == 0 && j == 0) choice_counts.add(5);
                if(i == 0 && j == 1) choice_counts.add(4);
                if(i == 0 && j == 2) choice_counts.add(0);
                if(i == 0 && j == 3) choice_counts.add(4);
                if(i == 0 && j == 4) choice_counts.add(4);
                if(i == 1 && j == 0) choice_counts.add(0);
                if(i == 1 && j == 1) choice_counts.add(0);
                if(i == 1 && j == 2) choice_counts.add(0);
                
                System.out.println("choice_counts.size() : "+choice_counts.size());
            }
        }
        
        // 누적 질문 순번 초기화
        accumulated_j = 0;
        
        // 객관식-보기/표형-행-질문/표형-열-보기에 대한 누적 순번 초기화
        int accumulated_k = 0;
        
        // i : 페이지 순번 == (페이지 번호 - 1)
        for(int i = 0; i < page_count; i++)
        {
            // 테이블의 하위맵에 대한 리스트 생성 및 초기화
            List<Map<String, Object>> choice_info_innerMap_list = new ArrayList<>();
            
            // 페이지 번호 출력
            System.out.println("[PAGE "+(i+1)+"]");
            
            // 질문 개수를 받는 변수 설정
            // question_count = request.getParameterValues("question_id_num_p"+(i+1)).length;
            
            // ** Garbage Insert ** //
            // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
            question_count = question_counts.get(i);
            System.out.println("question_counts.get("+i+") : "+question_count);
            
            // j : 질문 순번 == (질문 번호 - 1)
            for(int j = 0; j < question_count; j++)
            {
                // 보기 개수를 받는 변수 설정
                // choice_count = request.getParameterValues("choice_num_p"+(i+1)+"_q"+(j+1)).length;
                
                // ** Garbage Insert ** //
                // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
                choice_count = choice_counts.get(accumulated_j+j);
                System.out.println("choice_counts.get("+(accumulated_j+j)+") : "+choice_count);
                
                // k : 보기 순번 == (보기 번호 - 1)
                for(int k = 0; k < choice_count; k++)
                {
                    // 하위맵 생성 및 초기화
                    Map<String, Object> choice_info_innerMap = new HashMap<>();
                    
                    // 컬럼정보에 대한 리스트에 폼데이터 저장
                    // choice_num_list.add(request.getParameterValues("choice_num_p"+(i+1)+"_q"+(j+1))[k]);
                    // choice_contents_list.add(request.getParameterValues("choice_contents_p"+(i+1)+"_q"+(j+1))[k]);
                    // choice_file_path_list.add(request.getParameterValues("choice_file_path_p"+(i+1)+"_q"+(j+1))[k]);
                    
                    // ** Replacement to Garbage Data from Form Data **
                    // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
                    // 리스트 재삽입
                    if(i == 0 && j == 0 && k == 0)
                    {
                        choice_num_list.add("1");
                        choice_contents_list.add("VERY GOOD");
                        choice_file_path_list.add("C:\\Users\\211-11\\Pictures\\YeonChoco1-1-1.jpg");
                    }
                    if(i == 0 && j == 0 && k == 1)
                    {
                        choice_num_list.add("2");
                        choice_contents_list.add("GOOD");
                        choice_file_path_list.add("C:\\Users\\211-11\\Pictures\\YeonChoco1-1-2.jpg");
                    }
                    if(i == 0 && j == 0 && k == 2)
                    {
                        choice_num_list.add("3");
                        choice_contents_list.add("NOT BAD");
                        choice_file_path_list.add("C:\\Users\\211-11\\Pictures\\YeonChoco1-1-3.jpg");
                    }
                    if(i == 0 && j == 0 && k == 3)
                    {
                        choice_num_list.add("4");
                        choice_contents_list.add("BAD");
                        choice_file_path_list.add("C:\\Users\\211-11\\Pictures\\YeonChoco1-1-4.jpg");
                    }
                    if(i == 0 && j == 0 && k == 4)
                    {
                        choice_num_list.add("5");
                        choice_contents_list.add("TOO BAD");
                        choice_file_path_list.add("C:\\Users\\211-11\\Pictures\\YeonChoco1-1-5.jpg");
                    }
                    
                    // 2번 문항 보기 개수 : 4개
                    if(i == 0 && j == 1 && k == 0)
                    {
                        choice_num_list.add("1");
                        choice_contents_list.add("보기 2-1번");
                        choice_file_path_list.add(null);
                    }
                    if(i == 0 && j == 1 && k == 1)
                    {
                        choice_num_list.add("2");
                        choice_contents_list.add("보기 2-2번");
                        choice_file_path_list.add(null);
                    }
                    if(i == 0 && j == 1 && k == 2)
                    {
                        choice_num_list.add("3");
                        choice_contents_list.add("보기 2-3번");
                        choice_file_path_list.add(null);
                    }
                    if(i == 0 && j == 1 && k == 3)
                    {
                        choice_num_list.add("4");
                        choice_contents_list.add("보기 2-4번");
                        choice_file_path_list.add(null);
                    }
                    // 1 페이지 3번 문항의 경우 표형 질문이므로 해당 사항 X
                    if(i == 0 && j == 2) 
                    {
                        choice_num_list.add(null);
                        choice_contents_list.add(null);
                        choice_file_path_list.add(null);
                    }
                    // 1 페이지 4번 문항의 경우 보기 개수 3개
                    if(i == 0 && j == 3 && k == 0)
                    {
                        choice_num_list.add("1");
                        choice_contents_list.add("보기 4-1번");
                        choice_file_path_list.add("C:\\Users\\211-11\\Pictures\\YeonChoco1-4-1.jpg");
                    }
                    if(i == 0 && j == 3 && k == 1)
                    {
                        choice_num_list.add("2");
                        choice_contents_list.add("보기 4-2번");
                        choice_file_path_list.add("C:\\Users\\211-11\\Pictures\\YeonChoco1-4-2(Edited).jpg");
                    }
                    if(i == 0 && j == 3 && k == 2)
                    {
                        choice_num_list.add("3");
                        choice_contents_list.add("보기 4-3번");
                        choice_file_path_list.add("C:\\Users\\211-11\\Pictures\\YeonChoco1-4-3.jpg");
                    }
                    // 1 페이지 5번 문항의 경우 보기 개수 3개
                    if(i == 0 && j == 4 && k == 0)
                    {
                        choice_num_list.add("1");
                        choice_contents_list.add("보기 5-1번");
                        choice_file_path_list.add("C:\\Users\\211-11\\Pictures\\YeonChoco1-5-1.jpg");
                    }
                    if(i == 0 && j == 4 && k == 1)
                    {
                        choice_num_list.add("2");
                        choice_contents_list.add("보기 5-2번");
                        choice_file_path_list.add(null);
                    }
                    if(i == 0 && j == 4 && k == 2)
                    {
                        choice_num_list.add("3");
                        choice_contents_list.add("기타 응답");
                        choice_file_path_list.add("C:\\Users\\211-11\\Pictures\\YeonChoco1-5-3.jpg");
                    }
                    // 2 페이지인 경우
                    if(i == 1)
                    {
                        choice_num_list.add(null);
                        choice_contents_list.add(null);
                        choice_file_path_list.add(null);
                    }
                    
                    // 하위맵에 컬럼정보 리스트의 요소를 저장
                    // 하위맵 : choice_info_innerMap == choice_info_list.get(i).get(j).get(k)
                    choice_info_innerMap.put("survey_id_num", survey_id_num);
                    choice_info_innerMap.put("page_num", page_num_list.get(i));
                    choice_info_innerMap.put("question_id_num", question_id_num_list.get(accumulated_j+j));
                    choice_info_innerMap.put("choice_num", choice_num_list.get(k));
                    choice_info_innerMap.put("choice_contents", choice_contents_list.get(accumulated_k+k));
                    choice_info_innerMap.put("choice_file_path", choice_file_path_list.get(accumulated_k+k));
                    
                    // 저장된 폼 데이터 출력
                    System.out.println("survey_id_num : "+survey_id_num);
                    System.out.println("page_num : "+page_num_list.get(i));
                    System.out.println("question_id_num_p"+(i+1)+" : "+question_id_num_list.get(accumulated_j+j));
                    System.out.println("choice_num_p"+(i+1)+"_q"+(j+1)+" : "+choice_num_list.get(k));
                    System.out.println("choice_contents_p"+(i+1)+"_q"+(j+1)+" : "+choice_contents_list.get(accumulated_k+k));
                    System.out.println("choice_file_path_p"+(i+1)+"_q"+(j+1)+" : "+choice_file_path_list.get(accumulated_k+k));
                    
                    // 테이블 하위맵을 테이블 맵의 리스트에 저장
                    // 테이블 하위맵의 리스트 : choice_info_innerMap_list = choice_info_map.get(i).get(j)
                    choice_info_innerMap_list.add(choice_info_innerMap);
                    
                    System.out.println("choice_info_innerMap_list["+(accumulated_k+k)+"].size() : "+choice_info_innerMap_list.size());
                    
                    // 마지막 보기 순번인 경우
                    if(k == choice_count - 1)
                    {
                        // 누적 순번 카운트 변수에 마지막 보기 순번을 저장
                        accumulated_k += k+1;
                    }
                }
                
                // 마지막 질문 순번인 경우
                if(j == question_count - 1)
                {
                    // 누적 질문 순번에 마지막 질문 순번을 저장
                    accumulated_j += j+1;
                }
            }
            
            // 마지막 페이지의 경우
            if(i == page_count - 1)
            {
                // 테이블 맵에 하위 리스트 저장 
                choice_info_map.put("list", choice_info_innerMap_list);
            }
        }
        /*
        // 4-3. 객관식 보기(MULTIPLE_CHOICE) 테이블 관련 폼 데이터 받기
        System.out.println("3. 객관식 보기 테이블");
        
        // 0). SqlSession에 넘길 Map 생성
        Map<String, Object> multiple_choice_map = new HashMap<>();
        
        // 1) Map에 넘길 컬럼정보에 대한 리스트 생성
        List<Integer> choice_count_list = new ArrayList<>();
        List<String> is_other_choice_list = new ArrayList<>();
        List<String> min_multiple_choice_list = new ArrayList<>();
        List<String> max_multiple_choice_list = new ArrayList<>();
        
        // 카운트 변수 초기화
        accumulated_j = 0;
        
        // 3) 폼 데이터 순회 저장 및 출력
        // i : 페이지 순번 == (페이지 번호 - 1)
        for(int i = 0; i < page_count; i++)
        {
            // 페이지 번호 출력
            System.out.println("[PAGE "+(i+1)+"]");
            
            // 질문 개수를 받는 변수 설정
            // question_count = request.getParameterValues("question_id_num_p"+(i+1)).length;
            
            // 테이블 맵 데이터의 리스트 생성
            List<Map<String, Object>> multiple_choice_innerMap_list = new ArrayList<>();
            
            // ** Garbage Insert ** //
            // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
            question_count = question_counts.get(i);
            
            // j : 질문 순번 == (질문 번호 - 1)
            for(int j = 0; j < question_count; j++)
            {
                // 하위맵 초기화
                Map<String, Object> multiple_choice_innerMap = new HashMap<>();
                
                // 컬럼정보에 대한 리스트에 폼데이터 저장
                choice_count_list.add(choice_counts_list.get(accumulated_j+j));
                
                // is_other_choice_list.add(request.getParameterValues("is_other_choice_p"+(i+1))[j]);
                // min_multiple_choice_list.add(request.getParameterValues("min_multiple_choice_p"+(i+1))[j]);
                // max_multiple_choice_list.add(request.getParameterValues("max_multiple_choice_p"+(i+1))[j]);
                
                // ** Replacement to Garbage Data from Form Data **
                // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
                // 리스트 재삽입
                if(i == 0)
                {
                    if(j == 0)
                    {
                        is_other_choice_list.add(null);
                        min_multiple_choice_list.add("1");
                        max_multiple_choice_list.add("5");
                    }
                    else if(j == 1)
                    {
                        is_other_choice_list.add(null);
                        min_multiple_choice_list.add(null);
                        max_multiple_choice_list.add(null);
                    }
                    else if(j == 2)
                    {
                        is_other_choice_list.add(null);
                        min_multiple_choice_list.add(null);
                        max_multiple_choice_list.add(null);
                    }
                    else if(j == 3)
                    {
                        is_other_choice_list.add(null);
                        min_multiple_choice_list.add("1");
                        max_multiple_choice_list.add("1");
                    }
                    else if(j == 4)
                    {
                        is_other_choice_list.add("true");
                        min_multiple_choice_list.add("1");
                        max_multiple_choice_list.add("3");
                    }
                }
                else
                {
                    is_other_choice_list.add(null);
                }
             
                // 테이블 최하위 요소 맵에 컬럼정보 리스트의 요소를 저장
                // 테이블 최하위 요소 맵 : multiple_choice_innerMap == multiple_choice_map.get(i).get(j)
                multiple_choice_innerMap.put("survey_id_num", survey_id_num);
                multiple_choice_innerMap.put("page_num", page_num_list.get(i));
                multiple_choice_innerMap.put("question_id_num", question_id_num_list.get(accumulated_j+j));
                multiple_choice_innerMap.put("is_other_choice", is_other_choice_list.get(accumulated_j+j));
                multiple_choice_innerMap.put("min_multiple_choice", min_multiple_choice_list.get(accumulated_j+j));
                multiple_choice_innerMap.put("max_multiple_choice", max_multiple_choice_list.get(accumulated_j+j));
                
                // 저장된 폼 데이터 출력
                System.out.println("survey_id_num : "+survey_id_num);
                System.out.println("choice_count_p"+(i+1)+" : "+choice_count_list.get(i));
                System.out.println("is_other_choice_p"+(i+1)+" : "+is_other_choice_list.get(accumulated_j+j));
                System.out.println("min_multiple_choice_p"+(i+1)+" : "+min_multiple_choice_list.get(accumulated_j+j));
                System.out.println("max_multiple_choice_p"+(i+1)+" : "+max_multiple_choice_list.get(accumulated_j+j));
                
                // 하위맵을 하위맵 리스트에 저장 및 출력
                // 하위맵 리스트 : multiple_choice_innerMap_list == multiple_choice_map.get(i)
                multiple_choice_innerMap_list.add(multiple_choice_innerMap);
                System.out.println("multiple_choice_innerMap_list.get("+(accumulated_j+j)+") : "+multiple_choice_innerMap_list.get(accumulated_j+j));
                
                // 마지막 질문 순번에 도달한 경우
                if(j == question_count - 1)
                {
                    // 누적합산 변수에 그 질문 순번을 누적 저장
                    accumulated_j += j;
                }
            }
            
            // 마지막 페이지의 경우
            if(i == page_count - 1)
            {
                // 테이블 맵에 하위 리스트 저장
                multiple_choice_map.put("list", multiple_choice_innerMap_list);
            }
        }
        
        // 4-4. 주관식 보기(SUBJECTIVE_CHOICE) 테이블 관련 폼 데이터 받기
        System.out.println("4. 주관식 보기 테이블");
        
        // 0) SqlSession에 넘길 Map 생성
        Map<String, Object> subjective_choice_map = new HashMap<>();
        
        // 1) 테이블 맵 데이터의 리스트 생성
        List<List<Map<String, Object>>> subjective_choice_list = new ArrayList<>();
        List<Map<String, Object>> subjective_choice_innerMap_list = new ArrayList<>();
        Map<String, Object> subjective_choice_innerMap = new HashMap<>();
        
        // 2) Map에 넘길 컬럼정보에 대한 리스트 생성
        List<String> is_personal_info_list = new ArrayList<>();
        List<String> is_duplicate_list = new ArrayList<>();
        
        // 3) 폼 데이터 순회 저장 및 출력
        // i : 페이지 순번 == (페이지 번호 - 1)
        for(int i = 0; i < page_count; i++)
        {
            // 페이지 번호 출력
            System.out.println("[PAGE "+(i+1)+"]");
            
            // 질문 개수를 받는 변수 설정
            // question_count = request.getParameterValues("question_id_num_p"+(i+1)).length;
            
            // ** Garbage Insert ** //
            // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
            question_count = question_counts.get(i);
            
            // j : 질문 순번 == (질문 번호 - 1)
            for(int j = 0; j < question_count; j++)
            {
                // 컬럼정보에 대한 리스트에 폼데이터 저장
                // is_personal_info_list.add(request.getParameterValues("is_personal_info_p"+(i+1))[j]);
                // is_duplicate_list.add(request.getParameterValues("is_duplicate_p"+(i+1))[j]);
                
                // ** Garbage Insert ** //
                // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
                if(i == 0)
                {
                    switch(j)
                    {
                        case 0: 
                            is_personal_info_list.add(null);
                            is_duplicate_list.add(null);
                            break;
                        case 1:
                            is_personal_info_list.add(null);
                            is_duplicate_list.add(null);
                            break;
                        case 2:
                            is_personal_info_list.add(null);
                            is_duplicate_list.add(null);
                            break;
                        case 3:
                            is_personal_info_list.add(null);
                            is_duplicate_list.add(null);
                            break;
                        case 4:
                            is_personal_info_list.add(null);
                            is_duplicate_list.add(null);
                            break;
                    }
                }
                else if(i == 1)
                {
                    switch(j)
                    {
                        case 0:
                            is_personal_info_list.add("true");
                            is_duplicate_list.add("true");
                            break;
                        case 1:
                            is_personal_info_list.add("true");
                            is_duplicate_list.add("false");
                            break;
                        case 2:
                            is_personal_info_list.add("false");
                            is_duplicate_list.add("true");
                            break;
                    }
                }
                
                // 테이블 하위맵에 컬럼정보 리스트의 요소를 저장
                // 테이블 하위맵 : subjective_choice_innerMap == subjective_choice_list.get(i).get(j)
                subjective_choice_innerMap.put("is_personal_info", choice_description_list.get(i));
                subjective_choice_innerMap.put("is_duplicate", choice_num_list.get(j));
                
                // 저장된 폼 데이터 출력
                System.out.println("is_personal_info_p"+(i+1)+" : "+is_personal_info_list.get(j));
                System.out.println("is_duplicate_p"+(i+1)+" : "+is_duplicate_list.get(j));
            }
            
            // 누적 저장된 테이블 하위맵을 테이블 하위맵에 저장 & 누적 저장된 하위맵 초기화
            // 테이블 하위맵 리스트 : subjective_choice_innerMap_list == subjective_choice_list.get(i)
            subjective_choice_innerMap_list.add(subjective_choice_innerMap);
            subjective_choice_innerMap.clear();
            
            // 마지막 페이지의 경우, 맵에 리스트를 저장
            if(i == page_count - 1)
            {
                // 누적 저장된 하위맵 리스트를 테이블 리스트에 저장
                // 테이블 리스트 : subjective_choice_list
                subjective_choice_list.add(subjective_choice_innerMap_list);
                
                // 테이블에 설문 식별번호, 하위 리스트 저장
                subjective_choice_map.put("survey_id_num", survey_id_num);
                subjective_choice_map.put("subjective_choice_list", subjective_choice_list);
            }
        }
        
        // 4-5. 표형-행-질문(MATRIX_QUESTION) 테이블 관련 폼 데이터 받기
        System.out.println("5. 표형-행-질문 테이블");
        
        // 0). SqlSession에 넘길 Map 생성
        Map<String, Object> matrix_question_map = new HashMap<>();
        
        // 1) 테이블 맵 데이터의 리스트 생성
        List<List<List<Map<String, Object>>>> matrix_question_list = new ArrayList<>();
        List<List<Map<String, Object>>> matrix_question_inner_list = new ArrayList<>();
        List<Map<String, Object>> matrix_question_innerMap_list = new ArrayList<>();
        Map<String, Object> matrix_question_innerMap = new HashMap<>();
        
        // 2) Map에 넘길 컬럼정보에 대한 리스트 생성
        List<String> matrix_num_list = new ArrayList<>();
        List<String> matrix_contents_list = new ArrayList<>();
        
        // 3) 폼 데이터 순회 저장 및 출력
        
        // ** Garbage Insert ** //
        // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
        // 각 페이지의 질문별 표형-행-질문 개수를 받는 리스트와 내부 리스트를 선언
        List<List<Integer>> matrix_question_counts = new ArrayList<>();
        List<Integer> matrix_question_counts_inner_list = new ArrayList<>();
        
        // ** Garbage Insert ** //
        // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
        // 각 페이지의 질문별 표형-행-질문 개수를 받는 리스트에 데이터 삽입
        for(int i = 0; i < page_count; i++)
        {
            for(int j = 0; j < question_count; j++)
            {
                switch(i)
                {
                    case 0:
                        switch(j)
                        {
                            case 0:
                                matrix_question_counts_inner_list.add(0);
                                break;
                            case 1:
                                matrix_question_counts_inner_list.add(0);
                                break;
                            case 2:
                                matrix_question_counts_inner_list.add(2);
                                break;
                            case 3:
                                matrix_question_counts_inner_list.add(0);
                                break;
                            case 4:
                                matrix_question_counts_inner_list.add(0);
                                break;
                        }
                        break;
                    case 1:
                        switch(j)
                        {
                            case 0:
                                matrix_question_counts_inner_list.add(0);
                                break;
                            case 1:
                                matrix_question_counts_inner_list.add(0);
                                break;
                            case 2:
                                matrix_question_counts_inner_list.add(0);
                                break;
                        }
                        break;
                }
            }
            
            // 표형-행-질문 카운트 리스트에 누적 저장된 내부 리스트를 저장
            matrix_question_counts.add(matrix_question_counts_inner_list);
        }
        
        // i : 페이지 순번 == (페이지 번호 - 1)
        for(int i = 0; i < page_count; i++)
        {
            // 페이지 번호 출력
            System.out.println("[PAGE "+(i+1)+"]");
            
            // 질문 개수를 받는 변수 설정
            // question_count = request.getParameterValues("question_id_num_p"+(i+1)).length;
            
            // ** Garbage Insert ** //
            // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
            question_count = question_counts.get(i);
            
            // j : 질문 순번 == (질문 번호 - 1)
            for(int j = 0; j < question_count; j++)
            {
                // 표형-행-질문 개수를 받는 카운트 변수 초기화
                // matrix_question_count = request.getParameterValues("matrix_num_p"+(i+1)+"_q"+(j+1)).length;
                
                // ** Garbage Insert ** //
                // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
                matrix_question_count = matrix_question_counts_inner_list.get(j);
                
                // k : 표형(행) 질문 순번 == (표형 행 질문 번호 - 1)
                for(int k = 0; k < matrix_question_count; k++)
                {
                    // 컬럼정보에 대한 리스트에 폼데이터 저장
                    // matrix_num_list.add(request.getParameterValues("matrix_num_p"+(i+1)+"_q"+(j+1))[k]);
                    // matrix_contents_list.add(request.getParameterValues("matrix_contents_p"+(i+1)+"_q"+(j+1))[k]);
                    
                    // ** Garbage Insert ** //
                    // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
                    // 리스트 재삽입
                    switch(i)
                    {
                        case 0:
                            switch(j)
                            {
                                case 0: break;
                                case 1: break;
                                case 2:
                                    switch(k)
                                    {
                                        case 0:
                                            matrix_num_list.add("1");
                                            matrix_contents_list.add("나는 잘 생겼다.");
                                            break;
                                        case 1:
                                            matrix_num_list.add("2");
                                            matrix_contents_list.add("나는 못생겼다.");
                                            break;
                                    }
                                    break;
                                case 3: break;
                                case 4: break;
                            }
                            break;
                        case 1:
                            switch(j)
                            {
                                case 0: break;
                                case 1: break;
                                case 2: break;
                            }
                            break;
                    }
                    
                    // 테이블 하위맵에 컬럼정보 리스트의 요소를 저장
                    // 테이블 하위맵 : matrix_question_innerMap == matrix_question_list.get(i).get(j).get(k)
                    matrix_question_innerMap.put("matrix_num", matrix_num_list.get(i));
                    matrix_question_innerMap.put("matrix_contents", matrix_contents_list.get(k));
                    
                    // 저장된 폼 데이터 출력
                    System.out.println("matrix_num_p"+(i+1)+"_q"+(j+1)+" : "+matrix_num_list.get(i));
                    System.out.println("matrix_contents_p"+(i+1)+"_q"+(j+1)+" : "+matrix_contents_list.get(k));
                }
                
                // 누적 저장된 하위맵을 하위맵 리스트에 저장 & 누적 저장된 하위맵 초기화
                // 하위맵 리스트 : matrix_question_innerMap_list == matrix_question_list.get(i).get(j)
                matrix_question_innerMap_list.add(matrix_question_innerMap);
                matrix_question_innerMap.clear();
            }
            
            // 누적 저장된 하위맵 리스트를 내부 리스트에 저장 & 누적 저장된 하위맵 리스트 초기화
            // 내부 리스트 : matrix_question_inner_list == matrix_question_list.get(i)
            matrix_question_inner_list.add(matrix_question_innerMap_list);
            matrix_question_innerMap_list.clear();
            
            // 마지막 페이지의 경우, 맵에 리스트를 저장
            if(i == page_count - 1)
            {
                // 누적 저장된 내부 리스트를 테이블 리스트에 저장
                // 테이블 리스트 : matrix_question_list
                matrix_question_list.add(matrix_question_inner_list);
                
                // 테이블에 설문 식별번호, 하위 리스트 저장
                matrix_question_map.put("survey_id_num", survey_id_num);
                matrix_question_map.put("matrix_question_list", matrix_question_list);
            }
        }
        
        // 4-6. 표형-열-보기(MATRIX_CHOICE) 테이블 관련 폼 데이터 받기
        System.out.println("6. 표형-열-보기 테이블");
        
        // 0). SqlSession에 넘길 Map 생성
        Map<String, Object> matrix_choice_map = new HashMap<>();
        
        // 1) 테이블 맵 데이터의 리스트 생성
        List<List<List<Map<String, Object>>>> matrix_choice_list = new ArrayList<>();
        List<List<Map<String, Object>>> matrix_choice_inner_list = new ArrayList<>();
        List<Map<String, Object>> matrix_choice_innerMap_list = new ArrayList<>();
        Map<String, Object> matrix_choice_innerMap = new HashMap<>();
        
        // 2) Map에 넘길 컬럼정보에 대한 리스트 생성
        List<String> matrix_choice_num_list = new ArrayList<>();
        List<String> matrix_choice_contents_list = new ArrayList<>();
        
        // 3) 폼 데이터 순회 저장 및 출력
        
        // ** Garbage Insert ** //
        // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
        // 각 페이지의 질문별 표형-열-보기 개수를 할당하는 리스트와 내부 리스트를 선언
        List<List<Integer>> matrix_choice_counts = new ArrayList<>();
        List<Integer> matrix_choice_counts_inner_list = new ArrayList<>();
        
        // ** Garbage Insert ** //
        // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
        // 각 페이지의 질문별 표형-열-보기 개수를 할당하는 리스트와 내부 리스트에 데이터 삽입
        for(int i = 0; i < page_count; i++)
        {
            for(int j = 0; j < question_count; j++)
            {
                switch(i)
                {
                    case 0:
                        switch(j)
                        {
                            case 0:
                                matrix_choice_counts_inner_list.add(0);
                                break;
                            case 1:
                                matrix_choice_counts_inner_list.add(0);
                                break;
                            case 2:
                                matrix_choice_counts_inner_list.add(5);
                                break;
                            case 3:
                                matrix_choice_counts_inner_list.add(0);
                                break;
                            case 4:
                                matrix_choice_counts_inner_list.add(0);
                                break;
                        }
                        break;
                    case 1:
                        switch(j)
                        {
                            case 0:
                                matrix_choice_counts_inner_list.add(0);
                                break;
                            case 1:
                                matrix_choice_counts_inner_list.add(0);
                                break;
                            case 2:
                                matrix_choice_counts_inner_list.add(0);
                                break;
                        }
                        break;
                }
            }
            
            // 표형-행-질문 카운트 리스트에 누적 저장된 내부 리스트를 저장
            matrix_choice_counts.add(matrix_choice_counts_inner_list);
        }
        
        // i : 페이지 순번 == (페이지 번호 - 1)
        for(int i = 0; i < page_count; i++)
        {
            // 페이지 번호 출력
            System.out.println("[PAGE "+(i+1)+"]");
            
            // 질문 개수를 받는 변수 설정
            // question_count = request.getParameterValues("question_id_num_p"+(i+1)).length;
            
            // ** Garbage Insert ** //
            // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
            question_count = question_counts.get(i);
            
            // j : 질문 순번 == (질문 번호 - 1)
            for(int j = 0; j < question_count; j++)
            {
                // 표형-행-질문 개수를 받는 카운트 변수 초기화
                // matrix_choice_count = request.getParameterValues("matrix_num_p"+(i+1)+"_q"+(j+1)).length;
                
                // ** Garbage Insert ** //
                // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
                matrix_choice_count = matrix_choice_counts_inner_list.get(j);
                
                // k : 표형(열) 보기 순번 == (표형 열 보기 번호 - 1)
                for(int k = 0; k < matrix_choice_count; k++)
                {
                    // 컬럼정보에 대한 리스트에 폼데이터 저장
                    // matrix_choice_num_list.add(request.getParameterValues("matrix_choice_num_p"+(i+1)+"_q"+(j+1))[k]);
                    // matrix_choice_contents_list.add(request.getParameterValues("matrix_choice_contents_p"+(i+1)+"_q"+(j+1))[k]);
                    
                    // ** Garbage Insert ** //
                    // 참조 - 관리용 제목 테스트1 (https://www.letsmobile.co.kr/biz/survey/make/makeView.do)
                    // 리스트 재삽입
                    switch(i)
                    {
                        case 0:
                            switch(j)
                            {
                                case 0: break;
                                case 1: break;
                                case 2: 
                                    switch(k)
                                    {
                                        case 0:
                                            matrix_choice_num_list.add("1");
                                            matrix_choice_contents_list.add("매우 그렇다.");
                                            break;
                                        case 1:
                                            matrix_choice_num_list.add("2");
                                            matrix_choice_contents_list.add("그렇다.");
                                            break;
                                        case 2:
                                            matrix_choice_num_list.add("3");
                                            matrix_choice_contents_list.add("모르겠다.");
                                            break;
                                        case 3:
                                            matrix_choice_num_list.add("4");
                                            matrix_choice_contents_list.add("그렇지 않다.");
                                            break;
                                        case 4:
                                            matrix_choice_num_list.add("5");
                                            matrix_choice_contents_list.add("매우 그렇지 않다.");
                                            break;
                                    }
                                    break;
                                case 3: break;
                                case 4: break;
                            }
                            break;
                        case 1:
                            switch(j)
                            {
                                case 0: break;
                                case 1: break;
                                case 2: break;
                            }
                            break;
                    }
                    
                    // 하위맵에 컬럼정보 리스트의 요소를 저장
                    // 하위맵 : matrix_choice_innerMap == matrix_choice_list.get(i).get(j).get(k)
                    matrix_choice_innerMap.put("matrix_choice_num", matrix_choice_num_list.get(k));
                    matrix_choice_innerMap.put("matrix_choice_contents", matrix_choice_contents_list.get(k));
                    
                    // 저장된 폼 데이터 출력
                    System.out.println("matrix_choice_num_p"+(i+1)+"_q"+(j+1)+" : "+matrix_choice_num_list.get(k));
                    System.out.println("matrix_choice_contents_p"+(i+1)+"_q"+(j+1)+" : "+matrix_choice_contents_list.get(k));
                }
                
                // 누적 저장된 하위맵을 하위맵 리스트에 저장 & 누적 저장된 하위맵 초기화
                // 하위맵 리스트 : matrix_choice_innerMap_list == matrix_choice_list.get(i).get(j)
                matrix_choice_innerMap_list.add(matrix_choice_innerMap);
                matrix_choice_innerMap.clear();
            }
            
            // 누적 저장된 하위맵 리스트를 내부 리스트에 저장 & 누적 저장된 하위맵 리스트 초기화
            // 하위맵 리스트 : matrix_choice_inner_list == matrix_choice_list.get(i)
            matrix_choice_inner_list.add(matrix_choice_innerMap_list);
            matrix_choice_innerMap_list.clear();
            
            // 마지막 페이지의 경우, 맵에 리스트를 저장
            if(i == page_count - 1)
            {
                // 누적 저장된 내부 리스트를 테이블 리스트에 저장
                // 테이블 리스트 : matrix_choice_list
                matrix_choice_list.add(matrix_choice_inner_list);
                
                // 테이블에 설문 식별번호, 하위 리스트 저장
                matrix_choice_map.put("survey_id_num", survey_id_num);
                matrix_choice_map.put("matrix_choice_list", matrix_choice_list);
            }
        }
		*/
		// <세션/폼에서 넘어온 데이터 VO에 저장>
		// 1. 넘어온 세션 데이터에 대해 각 VO에 모두 저장한다.
		// 2. 이번에는 아까와 달리 중복된 세션 데이터라도 빠짐없이 저장해야 한다.
        // -----------------------------------------------------------
		// 3-1. [survey] 패키지의 BasicSurveyInfo 에 setter로 저장
		basicSurveyInfoVO.setSurvey_id_num(survey_id_num);
		basicSurveyInfoVO.setSurvey_type(survey_type);
		basicSurveyInfoVO.setAdmin_title(admin_title);
		basicSurveyInfoVO.setSurvey_start_date(survey_start_date);
		basicSurveyInfoVO.setSurvey_end_date(survey_end_date);
		basicSurveyInfoVO.setAdmin_id(admin_id);
		basicSurveyInfoVO.setTitle_input(title_input);
		basicSurveyInfoVO.setSurvey_notice(survey_notice);
		basicSurveyInfoVO.setAttached_image(attached_image);
		basicSurveyInfoVO.setSurvey_end_notice(survey_end_notice);
		basicSurveyInfoVO.setSurvey_creation_date(survey_creation_date);
		basicSurveyInfoVO.setLast_modify_date(last_modify_date);
		basicSurveyInfoVO.setIs_last_modify(is_last_modify);
		basicSurveyInfoVO.setConsent_procedure_count(consent_procedure_count);
		basicSurveyInfoVO.setConsent_notice_1(consent_notice_1);
		basicSurveyInfoVO.setConsent_notice_2(consent_notice_2);
		basicSurveyInfoVO.setIs_limit_respondent(is_limit_respondent);
		basicSurveyInfoVO.setLimit_respondent_num(limit_respondent_num);
		
		System.out.println();
		System.out.println("---------------------------------------------");
		System.out.println("           <기본설문정보 setter 확인>        ");
		System.out.println("basicSurveyInfoVO.getSurvey_id_num() : "+basicSurveyInfoVO.getSurvey_id_num());
		System.out.println("basicSurveyInfoVO.getSurvey_type() : "+basicSurveyInfoVO.getSurvey_type());
		System.out.println("basicSurveyInfoVO.getAdmin_title() : "+basicSurveyInfoVO.getAdmin_title());
		System.out.println("basicSurveyInfoVO.getSurvey_start_date() : "+basicSurveyInfoVO.getSurvey_start_date());
		System.out.println("basicSurveyInfoVO.getSurvey_end_date() : "+basicSurveyInfoVO.getSurvey_end_date());
		System.out.println("basicSurveyInfoVO.getAdmin_id() : "+basicSurveyInfoVO.getAdmin_id());
		System.out.println("basicSurveyInfoVO.getTitle_input() : "+basicSurveyInfoVO.getTitle_input());
		System.out.println("basicSurveyInfoVO.getSurvey_notice() : "+basicSurveyInfoVO.getSurvey_notice());
		System.out.println("basicSurveyInfoVO.getAttached_image() : "+basicSurveyInfoVO.getAttached_image());
		System.out.println("basicSurveyInfoVO.getSurvey_end_notice() : "+basicSurveyInfoVO.getSurvey_end_notice());
		System.out.println("basicSurveyInfoVO.getSurvey_creation_date() : "+basicSurveyInfoVO.getSurvey_creation_date());
		System.out.println("basicSurveyInfoVO.getLast_modify_date() : "+basicSurveyInfoVO.getLast_modify_date());
		System.out.println("basicSurveyInfoVO.getIs_last_modify() : "+basicSurveyInfoVO.getIs_last_modify());
		System.out.println("basicSurveyInfoVO.getConsent_procedure_count() : "+basicSurveyInfoVO.getConsent_procedure_count());
		System.out.println("basicSurveyInfoVO.getConsent_notice_1() : "+basicSurveyInfoVO.getConsent_notice_1());
		System.out.println("basicSurveyInfoVO.getConsent_notice_2() : "+basicSurveyInfoVO.getConsent_notice_2());
		System.out.println("basicSurveyInfoVO.getIs_limit_respondent() : "+basicSurveyInfoVO.getIs_limit_respondent());
		System.out.println("basicSurveyInfoVO.getLimit_respondent_num() : "+basicSurveyInfoVO.getLimit_respondent_num());
		System.out.println("---------------------------------------------");
		// -----------------------------------------------------------
		// 3-2. [survey] 패키지의 AddSurveyInfo 에 setter로 저장
		addSurveyInfoVO.setSurvey_id_num(survey_id_num);
		addSurveyInfoVO.setIs_anonymous_respondent(is_anonymous_respondent);
		addSurveyInfoVO.setIs_collect_add_info(is_collect_add_info);
		addSurveyInfoVO.setIs_certify_id(is_certify_id);
        System.out.println("           <추가설문정보 setter 확인>        ");
        System.out.println("addSurveyInfoVO.getSurvey_id_num() : "+addSurveyInfoVO.getSurvey_id_num());
        System.out.println("addSurveyInfoVO.getIs_anonymous_respondent() : "+addSurveyInfoVO.getIs_anonymous_respondent());
        System.out.println("addSurveyInfoVO.getIs_collect_add_info() : "+addSurveyInfoVO.getIs_collect_add_info());
        System.out.println("addSurveyInfoVO.getIs_certify_id() : "+addSurveyInfoVO.getIs_certify_id());
        System.out.println("---------------------------------------------");
		// -----------------------------------------------------------
		// 3-3. [survey] 패키지의 IdCertificationVO 에 setter로 저장
		idCertificationVO.setSurvey_id_num(survey_id_num);
		idCertificationVO.setCertification_notice(certification_notice);
		idCertificationVO.setCertification_info(certification_info);
        System.out.println("           <본인인증 setter 확인>        ");
        System.out.println("idCertificationVO.getSurvey_id_num() : "+idCertificationVO.getSurvey_id_num());
        System.out.println("idCertificationVO.getCertification_notice() : "+idCertificationVO.getCertification_notice());
        System.out.println("idCertificationVO.getCertification_info() : "+idCertificationVO.getCertification_info());
        System.out.println("---------------------------------------------");
		// -----------------------------------------------------------
		// 3-4. [survey] 패키지의 AddInfoCollectVO 에 setter로 저장
		addInfoCollectVO.setSurvey_id_num(survey_id_num);
		addInfoCollectVO.setGender(gender);
		addInfoCollectVO.setAge(age);
		addInfoCollectVO.setReligion(religion);
		System.out.println("           <추가정보수집 setter 확인>        ");
        System.out.println("addInfoCollectVO.getSurvey_id_num() : "+addInfoCollectVO.getSurvey_id_num());
        System.out.println("addInfoCollectVO.getGender() : "+addInfoCollectVO.getGender());
        System.out.println("addInfoCollectVO.getAge() : "+addInfoCollectVO.getAge());
        System.out.println("addInfoCollectVO.getReligion() : "+addInfoCollectVO.getReligion());
        System.out.println("---------------------------------------------");
		
		// <입력된 데이터에 대한 분기 처리>
		// 1. VO/MAP 유무에 따라 DAO-MAPPER 처리
		// 2. [survey] 패키지 : VO 유무에 따라 처리
		// 3. [composition(survey_new)] 패키지 : map 유무에 따라 처리
        
        /* [survey] 패키지 */
        
        // 4-1. BasicSurveyInfoVO 값 -> 넘어오면 처리 
        if(basicSurveyInfoVO != null)
        {
            basicSurveyInfoVO_Result = surveyQuestionCompoService.addBasicSurveyInfo(basicSurveyInfoVO);
        }
        
        // 4-2. AddSurveyInfoVO 값 -> 넘어오면 처리 
        if(addSurveyInfoVO != null)
        {
            addSurveyInfoVO_Result = surveyQuestionCompoService.addAddSurveyInfo(addSurveyInfoVO);
        }
        
        // 4-3. IdCertificationVO 값 -> 넘어오면 처리
        if(idCertificationVO != null)
        {
            idCertificationVO_Result = surveyQuestionCompoService.addIdCertification(idCertificationVO);
        }
        
        // 4-4. AddInfoCollectVO 값 -> 넘어오면 처리
        if(addInfoCollectVO != null)
        {
            addInfoCollectVO_Result = surveyQuestionCompoService.addAddInfoCollect(addInfoCollectVO);
        }
        
        // -----------------------------------------------------------
        
        /* [composition(new survey)] 패키지 */
        
        // 4-5. question_info_map 값 -> 넘어오면 처리
        if(question_info_map != null)
        {
            questionInfo_ResultMaps = surveyQuestionCompoService.addQuestionInfo(question_info_map, page_count, question_counts);
        }
        
		// 4-6. choice_info_map 값 -> 넘어오면 처리  
		if(choice_info_map != null)
		{
			choiceInfo_ResultMaps = surveyQuestionCompoService.addChoiceInfo(choice_info_map, page_count, question_counts, choice_counts);
		}
		
        /*
        // 4-7. multiple_choice_map 값 -> 넘어오면 처리
        if(multiple_choice_map != null)
        {
            multipleChoice_ResultMaps = surveyQuestionCompoService.addMultipleChoice(multiple_choice_map);
        }
        
        // 4-8. subjective_choice_map 값 -> 넘어오면 처리
        if(subjective_choice_map != null)
        {
            subjectiveChoice_ResultMaps = surveyQuestionCompoService.addSubjectiveChoice(subjective_choice_map);
        }
		
		// 4-9. matrix_question_map 값 -> 넘어오면 처리 
		if(matrix_question_map != null)
		{
			matrixQuestion_ResultMaps = surveyQuestionCompoService.addMatrixQuestion(matrix_question_map);
		}
		
        // 4-10. matrix_choice_map 값 -> 넘어오면 처리
        if(matrix_choice_map != null)
        {
            matrixChoice_ResultMaps = surveyQuestionCompoService.addMatrixChoice(matrix_choice_map);
        }
        */
		// <뷰 처리>
		// 1. ModelAndView 객체에 view 주소값 전송
		// 2. 해당 주소값을 가진 ModelAndView 객체를 리턴시킴
		ModelAndView mav = new ModelAndView(); // 관리자 리스트 조회 화면으로 주소값을 전달
		mav.setViewName("/admin/admin_main"); // viewName을 "/admin/admin_main" 값으로 setter 메소드를 통해 저장
		return mav; // 해당 ModelAndView 객체를 tiles 라이브러리에서 처리하도록 ModelAndView 클래스 타입으로 반환 
	}
}