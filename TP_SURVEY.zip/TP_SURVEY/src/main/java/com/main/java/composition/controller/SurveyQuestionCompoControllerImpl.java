package com.main.java.composition.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.main.java.admin.vo.AdminIdInfoVO;
import com.main.java.composition.service.SurveyQuestionCompoService;
import com.main.java.composition.vo.ChoiceInfoVO;
import com.main.java.composition.vo.MatrixChoiceVO;
import com.main.java.composition.vo.MatrixQuestionVO;
import com.main.java.composition.vo.MultipleChoiceVO;
import com.main.java.composition.vo.QuestionInfoVO;
import com.main.java.composition.vo.SubjectiveChoiceVO;
import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;

@Controller("compositionController")
public class SurveyQuestionCompoControllerImpl implements SurveyQuestionCompoController 
{
	// <서비스 인터페이스 객체에 대한 자동 의존성 주입>
	@Autowired
	private SurveyQuestionCompoService surveyQuestionCompoService;
	
	// <VO 객체 11(=1+6+4)개에 대한 자동 의존성 주입>
	// 1. admin 패키지 : 1개
	@Autowired
    AdminIdInfoVO adminIdInfoVO;
	// 2. survey 패키지 : 4개
	@Autowired
    BasicSurveyInfoVO basicSurveyInfoVO;
	@Autowired
    AddSurveyInfoVO addSurveyInfoVO;
	@Autowired
    IdCertificationVO idCertificationVO;
	@Autowired
	AddInfoCollectVO addInfoCollectVO;
	// 3. composition 패키지 : 6개
	@Autowired
	ChoiceInfoVO choiceInfoVO;
	@Autowired
	MatrixChoiceVO matrixChoiceVO;
	@Autowired
	MatrixQuestionVO matrixQuestionVO;
	@Autowired
	MultipleChoiceVO multipleChoiceVO;
	@Autowired
	QuestionInfoVO questionInfoVO;
	@Autowired
	SubjectiveChoiceVO subjectiveChoiceVO;
	
	// <VO 별 처리 결과를 받는 변수>
	int adminIdInfoVO_Result;
	int basicSurveyInfoVO_Result;
	int addSurveyInfoVO_Result;
	int idCertificationVO_Result;
	int addInfoCollectVO_Result;
	int choiceInfoVO_Result;
	int matrixChoiceVO_Result;
	int matrixQuestionVO_Result;
	int multipleChoiceVO_Result;
	int questionInfoVO_Result;
	int subjectiveChoiceVO_Result;
	
	@Override
	@RequestMapping(value = "/composition/survey_question_compo.do", method = RequestMethod.GET)
	public ModelAndView survey_question_compo_main(HttpServletRequest request, HttpServletResponse response) 
	{
		String viewName = (String)request.getAttribute("viewName");	
		System.out.println("viewName : "+viewName);
		ModelAndView mav = new ModelAndView();
		mav.setViewName(viewName);
		return mav;
	}
	
	@Override
	@RequestMapping(value = "/composition/insert.do", method = RequestMethod.POST)
	public ModelAndView insertVO
	(
		/* 매개변수 영역 */
		
		RedirectAttributes rAttr, 
		HttpServletRequest request, 
		HttpServletResponse response
	) 
	throws Exception
	{
		/* 실행 영역 */
		
		// <인코딩 방식 처리>
		request.setCharacterEncoding("utf-8");
		
		// <세션 처리>
		// 1. 이전 페이지에서 넘어온 세션 값을 모두 이곳에 남겨야 한다.
		// 2. 세션 객체를 먼저 호출하고, 이후 저장된 세션 Attribute를 가져온다.
		// 3. 단, 다른 테이블과 중복된 컬럼은 입력받은 최초 테이블에서 호출한다.
		// 4-1. 먼저 세션 객체를 호출한다.
		HttpSession session = request.getSession();
		
		// 4-2. [survey] 패키지의 BasicSurveyInfo 에 대한 세션 Attribute 호출
		String admin_id = (String) session.getAttribute("admin_id");
		String survey_id_num = (String) session.getAttribute("survey_id_num");
		String survey_type = (String) session.getAttribute("survey_type");
		String admin_title = (String) session.getAttribute("admin_title");
		Date survey_start_date = (Date) session.getAttribute("survey_start_date");
		Date survey_end_date = (Date) session.getAttribute("survey_end_date");
		String title_input = (String) session.getAttribute("title_input");
		String survey_notice = (String) session.getAttribute("survey_notice");
		String attached_image = (String) session.getAttribute("attached_image");
		String survey_end_notice = (String) session.getAttribute("survey_end_notice");
		Date survey_creation_date = (Date) session.getAttribute("survey_creation_date");
		Date last_modify_date = (Date) session.getAttribute("last_modify_date");
		String is_last_modify = (String) session.getAttribute("is_last_modify");
		String is_collect_data = (String) session.getAttribute("is_collect_data");
		String is_limit_respondent = (String) session.getAttribute("is_limit_respondent");
		String limit_respondent_num = (String) session.getAttribute("limit_respondent_num");
		
		// 4-3. [survey] 패키지의 AddSurveyInfo 에 대한 세션 Attribute 호출
		String is_anonymous_respondent = (String) session.getAttribute("is_anonymous_respondent");
		String is_collect_add_info = (String) session.getAttribute("is_collect_add_info");
		String is_certify_id = (String) session.getAttribute("is_certify_id");
		
		// 4-4. [survey] 패키지의 IdCertificationVO 에 대한 세션 Attribute 호출
		String certification_notice = (String) session.getAttribute("certification_notice");
		String certification_info = (String) session.getAttribute("certification_info");
		
		// 4-5. [survey] 패키지의 AddInfoCollectVO 에 대한 세션 Attribute 호출
		String gender = (String) session.getAttribute("gender");
		String age = (String) session.getAttribute("age");
		String education = (String) session.getAttribute("education");
		String marriage = (String) session.getAttribute("marriage");
		String salary = (String) session.getAttribute("salary");
		String religion = (String) session.getAttribute("religion");
		
		// 5. 세션이 잘 넘어왔는지 이클립스 콘솔창에 변수 출력으로 확인해본다.
		System.out.println("<세션 정보>");
		System.out.println("1. [survey] 패키지의 BasicSurveyInfo 에 대한 세션 Attribute 호출");
		System.out.println("admin_id : "+admin_id);
		System.out.println("survey_id_num : "+survey_id_num);
		System.out.println("survey_type : "+survey_type);
		System.out.println("admin_title : "+admin_title);
		System.out.println("survey_start_date : "+survey_start_date);
		System.out.println("survey_end_date : "+survey_end_date);
		System.out.println("title_input : "+title_input);
		System.out.println("survey_notice : "+survey_notice);
		System.out.println("attached_image : "+attached_image);
		System.out.println("survey_end_notice : "+survey_end_notice);
		System.out.println("survey_creation_date : "+survey_creation_date);
		System.out.println("last_modify_date : "+last_modify_date);
		System.out.println("is_last_modify : "+is_last_modify);
		System.out.println("is_collect_data : "+is_collect_data);
		System.out.println("is_limit_respondent : "+is_limit_respondent);
		System.out.println("limit_respondent_num : "+limit_respondent_num);
		System.out.println();
		System.out.println("2. [survey] 패키지의 AddSurveyInfo 에 대한 세션 Attribute 호출");
		System.out.println("is_anonymous_respondent : "+is_anonymous_respondent);
		System.out.println("is_collect_add_info : "+is_collect_add_info);
		System.out.println("is_certify_id : "+is_certify_id);
		System.out.println();
		System.out.println("3. [survey] 패키지의 IdCertificationVO 에 대한 세션 Attribute 호출");
		System.out.println("certification_notice : "+certification_notice);
		System.out.println("certification_info : "+certification_info);
		System.out.println();
		System.out.println("4. [survey] 패키지의 AddInfoCollectVO 에 대한 세션 Attribute 호출");
		System.out.println("gender : "+gender);
		System.out.println("age : "+age);
		System.out.println("education : "+education);
		System.out.println("marriage : "+marriage);
		System.out.println("salary : "+salary);
		System.out.println("religion : "+religion);
		System.out.println();
		
		// <폼 데이터 처리 및 출력>
		// 1. 모든 폼 데이터가 단일 데이터가 아닌 배열 데이터로 넘어온다.
		// 2. 고로, 배열 데이터를 처리하는 과정이 추가된다.
		// 3. 중복된 데이터는 첫 테이블 항목에서만 받는 걸로 로직을 구성했다.
		
		System.out.println("<폼 데이터 정보>");
		
		// 4-1. QUESTION_INFO 테이블 관련 폼 데이터 입수 및 형변환
		// 1) 페이지 번호 : 여러 개 존재 가능
		List<String> page_num = new ArrayList<>();
		System.out.print("page_num[] : ");
		// i : page_num 의 개수
		for(int i = 0; i < request.getParameterValues("page_num").length; i++)
		{
		    // 자체 자바 자료 구조를 통해 데이터 저장
		    page_num.add(request.getParameterValues("page_num")[i]);
		    
		    // 마지막 순번 데이터에 대한 출력 마감 처리, 또는 중간 출력
		    if(i == request.getParameterValues("page_num").length - 1)
		    {
		        System.out.println(page_num.get(i));
		    }
		    else 
		    {
		        // 처음 ~ 중간 요소 출력 처리
	            System.out.print(page_num.get(i)+", ");
		    }
		    
		}
		
		// 2) 질문 식별번호 : 페이지별 여러 개 존재 가능
		List<String> question_id_num_per_page = new ArrayList<>();
		List<List<String>> question_id_num = new ArrayList<>();
		System.out.println("question_id_num[][] : ");
		// i : page_num 의 개수
		for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
		    // 페이지 번호 표시
		    System.out.print("- [Page "+(i+1)+"] : ");
		    
		    // j : question_id_num 의 개수
		    for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
		    {
		        // 질문의 개수만큼 페이지당 질문 식변번호에 저장 
		        question_id_num_per_page.add(request.getParameterValues("question_id_num_p"+(i+1))[j]);
		        
		        // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 임시 저장소 청소
		        if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
		        {
		            System.out.println(request.getParameterValues("question_id_num_p"+(i+1))[j]);
		            question_id_num.add(i, question_id_num_per_page);
		            question_id_num_per_page.clear();
		        }
		        else 
		        {
		            // 그렇지 않으면, 중간 출력
		            System.out.print(question_id_num_per_page.get(j)+", ");
		        }
		    }
        }
		
		// 3) 질문 유형 : 페이지별 여러 개 존재 가능
		List<String> question_type_per_page = new ArrayList<>();
		List<List<String>> question_type = new ArrayList<>();
		System.out.println("question_type[][] : ");
		// i : page_num 의 개수
		for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
		    // 페이지 번호 표시
            System.out.print("- [Page "+(i+1)+"] : ");
		    
		    // j : question_id_num 의 개수
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 질문의 개수만큼 페이지당 질문 식변번호에 저장 
                question_type_per_page.add(request.getParameterValues("question_type_p"+(i+1))[j]);
                
                // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 중간 출력 방지
                if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
                {
                    System.out.println(request.getParameterValues("question_type_p"+(i+1))[j]);
                    question_type.add(i, question_type_per_page);
                    question_type_per_page.clear();
                }
                else
                {
                    // 그렇지 않으면, 중간 출력
                    System.out.print(question_type_per_page.get(j)+", ");
                }
            }
        }
		
		// 4) 질문 내용
		List<String> question_contents_per_page = new ArrayList<>();
		List<List<String>> question_contents = new ArrayList<>();
		System.out.println("question_contents[][] : ");
		// i : page_num 의 개수
		for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
		    // 페이지 번호 표시
            System.out.print("- [Page "+(i+1)+"] : ");
            
		    // j : question_id_num 의 개수
		    for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
		    {
		        // 질문 개수 만큼 페이지당 질문 식변번호에 저장 
		        question_contents_per_page.add(request.getParameterValues("question_contents_p"+(i+1))[j]);
		        
		        // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 임시 저장소 청소
                if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
                {
                    System.out.println(request.getParameterValues("question_contents_p"+(i+1))[j]);
                    question_contents.add(i, question_contents_per_page);
                    question_contents_per_page.clear();
                }
                else
                {
                    // 그렇지 않으면, 중간 출력
                    System.out.print(question_contents_per_page.get(j)+", ");
                }
		    }
        }
		
		// 3-2. CHOICE_INFO 관련 폼 데이터 입수
		// 1) 보기 설명(choice_description) : 여러 질문 번호에 대해 여러 개 존재 가능
		List<String> choice_description_per_page = new ArrayList<>();
		List<List<String>> choice_description = new ArrayList<>();
		System.out.println("choice_description[][] : ");
		// i : page_num 의 개수
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 표시
            System.out.print("- [Page "+(i+1)+"] : ");
            
            // j : question_id_num 의 개수
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 질문 개수 만큼 페이지당 질문 식변번호에 저장 
                choice_description_per_page.add(request.getParameterValues("choice_description_p"+(i+1))[j]);
                
                // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 임시 저장소 청소
                if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
                {
                    System.out.println(choice_description_per_page.get(j));
                    choice_description.add(i, choice_description_per_page);
                    choice_description_per_page.clear();
                }
                else
                {
                    // 그렇지 않으면, 중간 출력
                    System.out.print(choice_description_per_page.get(j)+", ");
                }
            }
        }
		
		// 2) 보기 번호(choice_num) : 여러 질문 번호에 대해 여러 개 존재 가능
		List<String> choice_num_per_question = new ArrayList<>();
		List<List<String>> choice_num_per_page = new ArrayList<>();
		List<List<List<String>>> choice_num = new ArrayList<>();
		System.out.println("choice_num[][][] : ");
		// i : page_num 의 개수
		for(int i = 0; i < request.getParameterValues("page_num").length; i++)
		{
		    // 페이지 번호 표시
            System.out.println("- [Page "+(i+1)+"] : ");
		    
		    // j : 페이지당 question 의 개수
		    for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
		    {
		        // 질문 번호 표시
                System.out.print("-- [Question "+(j+1)+"] : ");
		        
		        // k : 질문당 choice 의 개수
		        for(int k = 0; k < request.getParameterValues("choice_num_p"+(i+1)+"_q"+(j+1)).length; k++)
		        {
		            // 보기 개수만큼 choice_num_per_question 에 저장
		            choice_num_per_question.add(request.getParameterValues("choice_num_p"+(i+1)+"_q"+(j+1))[k]);
		            
		            // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 임시 저장소 청소
		            if(k == request.getParameterValues("choice_num_p"+(i+1)+"_q"+(j+1)).length - 1)
		            {
		                System.out.println(choice_num_per_question.get(k));
		                choice_num_per_page.add(j, choice_num_per_question);
		                choice_num_per_question.clear();
		            }
		            else
		            {
		                System.out.print(choice_num_per_question.get(k)+", ");
		            }
		        }
		        
		        // j번째 질문에 대한 보기 번호를 모은 정보 출력
		        System.out.println("- [Page "+(i+1)+"] : "+choice_num_per_page.get(j));
		        
		        // 마지막 question 번호에 대한 저장
		        if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
		        {
		            choice_num.add(i, choice_num_per_page);
		            choice_num_per_page.clear();
		        }
		    }
		}
		
		// 3) 보기 내용(choice_contents) : 여러 질문 번호에 대해 여러 개 존재 가능
		List<String> choice_contents_per_question = new ArrayList<>();
		List<List<String>> choice_contents_per_page = new ArrayList<>();
		List<List<List<String>>> choice_contents = new ArrayList<>();
		System.out.println("choice_contents[][][] : ");
        // i : page_num 의 개수
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 표시
            System.out.println("- [Page "+(i+1)+"] : ");
            
            // j : 페이지당 question 의 개수
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 질문 번호 표시
                System.out.print("-- [Question "+(j+1)+"] : ");
                
                // k : 질문당 choice 의 개수
                for(int k = 0; k < request.getParameterValues("choice_contents_p"+(i+1)+"_q"+(j+1)).length; k++)
                {
                    // 보기 개수만큼 choice_num_per_question 에 저장
                    choice_contents_per_question.add(request.getParameterValues("choice_contents_p"+(i+1)+"_q"+(j+1))[k]);
                    
                    // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 임시 저장소 청소
                    if(k == request.getParameterValues("choice_contents_p"+(i+1)+"_q"+(j+1)).length - 1)
                    {
                        System.out.println(choice_contents_per_question.get(k));
                        choice_contents_per_page.add(j, choice_contents_per_question);
                        choice_contents_per_question.clear();
                    }
                    else
                    {
                        System.out.print(choice_contents_per_question.get(k)+", ");
                    }
                }
                
                // j번째 질문에 대한 보기 번호를 모은 정보 출력
                System.out.println("- [Page "+(i+1)+"] : "+choice_contents_per_page.get(j));
                
                // 마지막 question 번호에 대한 저장
                if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
                {
                    choice_contents.add(i, choice_contents_per_page);
                    choice_contents_per_page.clear();
                }
            }
        }
		
        // 4) 보기별 첨부파일 경로(choice_file_path) : 여러 질문 번호에 대해 여러 개 존재 가능
        List<String> choice_file_path_per_question = new ArrayList<>();
        List<List<String>> choice_file_path_per_page = new ArrayList<>();
        List<List<List<String>>> choice_file_path = new ArrayList<>();
        System.out.println("choice_file_path[][][] : ");
        // i : page_num 의 개수
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 표시
            System.out.println("- [Page "+(i+1)+"] : ");
            
            // j : 페이지당 question 의 개수
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 질문 번호 표시
                System.out.print("-- [Question "+(j+1)+"] : ");
                
                // k : 질문당 choice 의 개수
                for(int k = 0; k < request.getParameterValues("choice_file_path_p"+(i+1)+"_q"+(j+1)).length; k++)
                {
                    // 보기 개수만큼 choice_num_per_question 에 저장
                    choice_file_path_per_question.add(request.getParameterValues("choice_file_path_p"+(i+1)+"_q"+(j+1))[k]);
                    
                    // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 임시 저장소 청소
                    if(k == request.getParameterValues("choice_file_path_p"+(i+1)+"_q"+(j+1)).length - 1)
                    {
                        System.out.println(choice_file_path_per_question.get(k));
                        choice_file_path_per_page.add(j, choice_file_path_per_question);
                        choice_file_path_per_question.clear();
                    }
                    else
                    {
                        System.out.print(choice_file_path_per_question.get(k)+", ");
                    }
                }
                
                // j번째 질문에 대한 보기 번호를 모은 정보 출력
                System.out.println("- [Page "+(i+1)+"] : "+choice_file_path_per_page.get(j));
                
                // 마지막 question 번호에 대한 저장
                if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
                {
                    choice_file_path.add(i, choice_file_path_per_page);
                    choice_file_path_per_page.clear();
                }
            }
        }
        
        // 3-3. MULTIPLE_CHOICE 테이블 관련 폼 데이터 입수
        // 1) 보기 개수
        List<String> choice_count_per_page = new ArrayList<>();
        List<List<String>> choice_count = new ArrayList<>();
        System.out.println("choice_count[][] : ");
        // i : page_num 의 개수
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 표시
            System.out.print("- [Page "+(i+1)+"] : ");
            
            // j : question_id_num 의 개수
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 질문 개수 만큼 페이지당 질문 식변번호에 저장 
                choice_count_per_page.add(request.getParameterValues("choice_count_p"+(i+1))[j]);
                
                // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 임시 저장소 청소
                if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
                {
                    System.out.println(choice_count_per_page.get(j));
                    choice_count.add(i, choice_count_per_page);
                    choice_count_per_page.clear();
                }
                else
                {
                    // 그렇지 않으면, 중간 출력
                    System.out.print(choice_count_per_page.get(j)+", ");
                }
            }
        }
        
        // 2) 기타 응답 여부
        List<String> is_other_choice_per_page = new ArrayList<>();
        List<List<String>> is_other_choice = new ArrayList<>();
        System.out.println("is_other_choice[][] : ");
        // i : page_num 의 개수
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 표시
            System.out.print("- [Page "+(i+1)+"] : ");
            
            // j : question_id_num 의 개수
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 질문 개수 만큼 페이지당 질문 식변번호에 저장 
                is_other_choice_per_page.add(request.getParameterValues("is_other_choice_p"+(i+1))[j]);
                
                // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 임시 저장소 청소
                if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
                {
                    System.out.println(is_other_choice_per_page.get(j));
                    is_other_choice.add(i, is_other_choice_per_page);
                    is_other_choice_per_page.clear();
                }
                else
                {
                    // 그렇지 않으면, 중간 출력
                    System.out.print(is_other_choice_per_page.get(j)+", ");
                }
            }
        }
        
        // 3) 객관식 최소 답변수
        List<String> min_multiple_choice_per_page = new ArrayList<>();
        List<List<String>> min_multiple_choice = new ArrayList<>();
        System.out.println("min_multiple_choice[][] : ");
        // i : page_num 의 개수
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 표시
            System.out.print("- [Page "+(i+1)+"] : ");
            
            // j : question_id_num 의 개수
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 질문 개수 만큼 페이지당 질문 식변번호에 저장 
                min_multiple_choice_per_page.add(request.getParameterValues("min_multiple_choice_p"+(i+1))[j]);
                
                // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 임시 저장소 청소
                if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
                {
                    System.out.println(min_multiple_choice_per_page.get(j));
                    min_multiple_choice.add(i, min_multiple_choice_per_page);
                    min_multiple_choice_per_page.clear();
                }
                else
                {
                    // 그렇지 않으면, 중간 출력
                    System.out.print(min_multiple_choice_per_page.get(j)+", ");
                }
            }
        }
        
        // 4) 객관식 최대 답변수
        List<String> max_multiple_choice_per_page = new ArrayList<>();
        List<List<String>> max_multiple_choice = new ArrayList<>();
        System.out.println("max_multiple_choice[][] : ");
        // i : page_num 의 개수
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 표시
            System.out.print("- [Page "+(i+1)+"] : ");
            
            // j : question_id_num 의 개수
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 질문 개수 만큼 페이지당 질문 식변번호에 저장 
                max_multiple_choice_per_page.add(request.getParameterValues("max_multiple_choice_p"+(i+1))[j]);
                
                // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 임시 저장소 청소
                if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
                {
                    System.out.println(max_multiple_choice_per_page.get(j));
                    max_multiple_choice.add(i, max_multiple_choice_per_page);
                    max_multiple_choice_per_page.clear();
                }
                else
                {
                    // 그렇지 않으면, 중간 출력
                    System.out.print(max_multiple_choice_per_page.get(j)+", ");
                }
            }
        }
        
        // 3-2. SUBJECTIVE_CHOICE 관련 폼 데이터 입수
        // 1) 개인정보 처리 여부
        List<String> is_personal_info_per_page = new ArrayList<>();
        List<List<String>> is_personal_info = new ArrayList<>();
        System.out.println("is_personal_info[][] : ");
        // i : page_num 의 개수
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 표시
            System.out.print("- [Page "+(i+1)+"] : ");
            
            // j : question_id_num 의 개수
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 질문 개수 만큼 페이지당 질문 식변번호에 저장 
                is_personal_info_per_page.add(request.getParameterValues("is_personal_info_p"+(i+1))[j]);
                
                // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 임시 저장소 청소
                if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
                {
                    System.out.println(is_personal_info_per_page.get(j));
                    is_personal_info.add(i, is_personal_info_per_page);
                    is_personal_info_per_page.clear();
                }
                else
                {
                    // 그렇지 않으면, 중간 출력
                    System.out.print(is_personal_info_per_page.get(j)+", ");
                }
            }
        }
        
        // 2) 중복값 허용 여부
        List<String> is_duplicate_per_page = new ArrayList<>();
        List<List<String>> is_duplicate = new ArrayList<>();
        System.out.println("is_duplicate[][] : ");
        // i : page_num 의 개수
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 표시
            System.out.print("- [Page "+(i+1)+"] : ");
            
            // j : question_id_num 의 개수
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 질문 개수 만큼 페이지당 질문 식변번호에 저장 
                is_duplicate_per_page.add(request.getParameterValues("is_duplicate_p"+(i+1))[j]);
                
                // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 임시 저장소 청소
                if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
                {
                    System.out.println(is_duplicate_per_page.get(j));
                    is_duplicate.add(i, is_duplicate_per_page);
                    is_duplicate_per_page.clear();
                }
                else
                {
                    // 그렇지 않으면, 중간 출력
                    System.out.print(is_duplicate_per_page.get(j)+", ");
                }
            }
        }
        
        // 3-3. MATRIX_QUESTION 관련 폼 데이터 입수
        // 1) 표형 질문번호
        List<String> matrix_num_per_question = new ArrayList<>();
        List<List<String>> matrix_num_per_page = new ArrayList<>();
        List<List<List<String>>> matrix_num = new ArrayList<>();
        System.out.println("matrix_num[][][] : ");
        // i : page_num 의 개수
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 표시
            System.out.println("- [Page "+(i+1)+"] : ");
            
            // j : 페이지당 question 의 개수
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 질문 번호 표시
                System.out.print("-- [Question "+(j+1)+"] : ");
                
                // k : 질문당 choice 의 개수
                for(int k = 0; k < request.getParameterValues("matrix_num_p"+(i+1)+"_q"+(j+1)).length; k++)
                {
                    // 보기 개수만큼 choice_num_per_question 에 저장
                    matrix_num_per_question.add(request.getParameterValues("matrix_num_p"+(i+1)+"_q"+(j+1))[k]);
                    
                    // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 임시 저장소 청소
                    if(k == request.getParameterValues("matrix_num_p"+(i+1)+"_q"+(j+1)).length - 1)
                    {
                        System.out.println(matrix_num_per_question.get(k));
                        matrix_num_per_page.add(j, matrix_num_per_question);
                        matrix_num_per_question.clear();
                    }
                    else
                    {
                        System.out.print(matrix_num_per_question.get(k)+", ");
                    }
                }
                
                // j번째 질문에 대한 보기 번호를 모은 정보 출력
                System.out.println("- [Page "+(i+1)+"] : "+matrix_num_per_page.get(j));
                
                // 마지막 question 번호에 대한 배열 데이터의 리스트를 현재 페이지의 리스트로 묶어서 저장
                if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
                {
                    matrix_num.add(i, matrix_num_per_page);
                    matrix_num_per_page.clear();
                }
            }
        }
        
        // 2) 표형 질문내용
        List<String> matrix_contents_per_question = new ArrayList<>();
        List<List<String>> matrix_contents_per_page = new ArrayList<>();
        List<List<List<String>>> matrix_contents = new ArrayList<>();
        System.out.println("matrix_contents[][][] : ");
        // i : page_num 의 개수
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 표시
            System.out.println("- [Page "+(i+1)+"] : ");
            
            // j : 페이지당 question 의 개수
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 질문 번호 표시
                System.out.print("-- [Question "+(j+1)+"] : ");
                
                // k : 질문당 choice 의 개수
                for(int k = 0; k < request.getParameterValues("matrix_contents_p"+(i+1)+"_q"+(j+1)).length; k++)
                {
                    // 보기 개수만큼 choice_num_per_question 에 저장
                    matrix_contents_per_question.add(request.getParameterValues("matrix_contents_p"+(i+1)+"_q"+(j+1))[k]);
                    
                    // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 임시 저장소 청소
                    if(k == request.getParameterValues("matrix_contents_p"+(i+1)+"_q"+(j+1)).length - 1)
                    {
                        System.out.println(matrix_contents_per_question.get(k));
                        matrix_contents_per_page.add(j, matrix_contents_per_question);
                        matrix_contents_per_question.clear();
                    }
                    else
                    {
                        System.out.print(matrix_contents_per_question.get(k)+", ");
                    }
                }
                
                // j번째 질문에 대한 보기 번호를 모은 정보 출력
                System.out.println("- [Page "+(i+1)+"] : "+matrix_contents_per_page.get(j));
                
                // 마지막 question 번호에 대한 저장
                if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
                {
                    matrix_contents.add(i, matrix_contents_per_page);
                    matrix_contents_per_page.clear();
                }
            }
        }
        
        // 3-4. MATRIX_CHOICE 관련 폼 데이터 입수
        // 1) 표형 보기번호
        List<String> matrix_choice_num_per_question = new ArrayList<>();
        List<List<String>> matrix_choice_num_per_page = new ArrayList<>();
        List<List<List<String>>> matrix_choice_num = new ArrayList<>();
        System.out.println("matrix_choice_num[][][] : ");
        // i : page_num 의 개수
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 표시
            System.out.println("- [Page "+(i+1)+"] : ");
            
            // j : 페이지당 question 의 개수
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 질문 번호 표시
                System.out.print("-- [Question "+(j+1)+"] : ");
                
                // k : 질문당 choice 의 개수
                for(int k = 0; k < request.getParameterValues("matrix_choice_num_p"+(i+1)+"_q"+(j+1)).length; k++)
                {
                    // 보기 개수만큼 choice_num_per_question 에 저장
                    matrix_choice_num_per_question.add(request.getParameterValues("matrix_choice_num_p"+(i+1)+"_q"+(j+1))[k]);
                    
                    // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 임시 저장소 청소
                    if(k == request.getParameterValues("matrix_choice_num_p"+(i+1)+"_q"+(j+1)).length - 1)
                    {
                        System.out.println(matrix_choice_num_per_question.get(k));
                        matrix_choice_num_per_page.add(j, matrix_choice_num_per_question);
                        matrix_choice_num_per_question.clear();
                    }
                    else
                    {
                        System.out.print(matrix_choice_num_per_question.get(k)+", ");
                    }
                }
                
                // j번째 질문에 대한 보기 번호를 모은 정보 출력
                System.out.println("- [Page "+(i+1)+"] : "+matrix_choice_num_per_page.get(j));
                
                // 마지막 question 번호에 대한 저장
                if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
                {
                    matrix_choice_num.add(i, matrix_choice_num_per_page);
                    matrix_choice_num_per_page.clear();
                }
            }
        }
        
        // 2) 표형 보기내용
        List<String> matrix_choice_contents_per_question = new ArrayList<>();
        List<List<String>> matrix_choice_contents_num_per_page = new ArrayList<>();
        List<List<List<String>>> matrix_choice_contents = new ArrayList<>();
        System.out.println("matrix_choice_contents[][][] : ");
        // i : page_num 의 개수
        for(int i = 0; i < request.getParameterValues("page_num").length; i++)
        {
            // 페이지 번호 표시
            System.out.println("- [Page "+(i+1)+"] : ");
            
            // j : 페이지당 question 의 개수
            for(int j = 0; j < request.getParameterValues("question_id_num_p"+(i+1)).length; j++)
            {
                // 질문 번호 표시
                System.out.print("-- [Question "+(j+1)+"] : ");
                
                // k : 질문당 choice 의 개수
                for(int k = 0; k < request.getParameterValues("matrix_choice_contents_p"+(i+1)+"_q"+(j+1)).length; k++)
                {
                    // 보기 개수만큼 choice_num_per_question 에 저장
                    matrix_choice_contents_per_question.add(request.getParameterValues("matrix_choice_contents_p"+(i+1)+"_q"+(j+1))[k]);
                    
                    // 마지막 순번 데이터에 대한 출력 마감 처리 및 저장, 임시 저장소 청소
                    if(k == request.getParameterValues("matrix_choice_contents_p"+(i+1)+"_q"+(j+1)).length - 1)
                    {
                        System.out.println(matrix_choice_contents_per_question.get(k));
                        matrix_choice_contents_num_per_page.add(j, matrix_choice_contents_per_question);
                        matrix_choice_contents_per_question.clear();
                    }
                    else
                    {
                        System.out.print(matrix_choice_contents_per_question.get(k)+", ");
                    }
                }
                
                // j번째 질문에 대한 보기 번호를 모은 정보 출력
                System.out.println("- [Page "+(i+1)+"] : "+matrix_choice_contents_num_per_page.get(j));
                
                // 마지막 question 번호에 대한 표형 보기내용들의 리스트를 저장
                if(j == request.getParameterValues("question_id_num_p"+(i+1)).length - 1)
                {
                    matrix_choice_contents.add(i, matrix_choice_contents_num_per_page);
                    matrix_choice_contents_num_per_page.clear();
                }
            }
        }
        
		// <세션/폼에서 넘어온 데이터 VO에 저장>
		// 1. 넘어온 세션 데이터에 대해 각 VO에 모두 저장한다.
		// 2. 이번에는 아까와 달리 중복된 세션 데이터라도 빠짐없이 저장해야 한다.
        // -----------------------------------------------------------
		// 3-1. [survey] 패키지의 BasicSurveyInfo 에 setter로 저장
		basicSurveyInfoVO.setSurvey_id_num(survey_id_num);
		basicSurveyInfoVO.setSurvey_type(survey_type);
		basicSurveyInfoVO.setAdmin_title(admin_title);
		basicSurveyInfoVO.setSurvey_start_date(survey_start_date);
		basicSurveyInfoVO.setSurvey_end_date(survey_end_date);
		basicSurveyInfoVO.setAdmin_id(admin_id);
		basicSurveyInfoVO.setTitle_input(title_input);
		basicSurveyInfoVO.setSurvey_notice(survey_notice);
		basicSurveyInfoVO.setAttached_image(attached_image);
		basicSurveyInfoVO.setSurvey_end_notice(survey_end_notice);
		basicSurveyInfoVO.setLast_modify_date(last_modify_date);
		basicSurveyInfoVO.setIs_last_modify(is_last_modify);
		basicSurveyInfoVO.setIs_collect_data(is_collect_data);
		basicSurveyInfoVO.setIs_limit_respondent(is_limit_respondent);
		basicSurveyInfoVO.setLimit_respondent_num(limit_respondent_num);
		// -----------------------------------------------------------
		// 3-2. [survey] 패키지의 AddSurveyInfo 에 setter로 저장
		addSurveyInfoVO.setSurvey_id_num(survey_id_num);
		addSurveyInfoVO.setIs_anonymous_respondent(is_anonymous_respondent);
		addSurveyInfoVO.setIs_collect_add_info(is_collect_add_info);
		addSurveyInfoVO.setIs_certify_id(is_certify_id);
		// -----------------------------------------------------------
		// 3-3. [survey] 패키지의 IdCertificationVO 에 setter로 저장
		idCertificationVO.setSurvey_id_num(survey_id_num);
		idCertificationVO.setCertification_notice(certification_notice);
		idCertificationVO.setCertification_info(certification_info);
		// -----------------------------------------------------------
		// 3-4. [survey] 패키지의 AddInfoCollectVO 에 setter로 저장
		addInfoCollectVO.setSurvey_id_num(survey_id_num);
		addInfoCollectVO.setGender(gender);
		addInfoCollectVO.setAge(age);
		addInfoCollectVO.setEducation(education);
		addInfoCollectVO.setMarriage(marriage);
		addInfoCollectVO.setSalary(salary);
		addInfoCollectVO.setReligion(religion);
		// -----------------------------------------------------------
		// 3-5. [composition] 패키지의 QuestionInfoVO 에 setter로 저장
		questionInfoVO.setSurvey_id_num(survey_id_num);
		questionInfoVO.setPage_num(page_num);
		questionInfoVO.setQuestion_id_num(question_id_num);
		questionInfoVO.setQuestion_type(question_type);
		questionInfoVO.setQuestion_contents(question_contents);
		// -----------------------------------------------------------
		// 3-6. [composition] 패키지의 ChoiceInfoVO 에 setter로 저장
		choiceInfoVO.setSurvey_id_num(survey_id_num);
		choiceInfoVO.setQuestion_id_num(question_id_num);
		choiceInfoVO.setChoice_description(choice_description);
		choiceInfoVO.setChoice_num(choice_num);
		choiceInfoVO.setChoice_contents(choice_contents);
		choiceInfoVO.setChoice_file_path(choice_file_path);
		// -----------------------------------------------------------
		// 3-7. [composition] 패키지의 MultipleChoiceVO 에 setter로 저장
		multipleChoiceVO.setSurvey_id_num(survey_id_num);
		multipleChoiceVO.setQuestion_id_num(question_id_num);
		multipleChoiceVO.setChoice_count(choice_count);
		multipleChoiceVO.setIs_other_choice(is_other_choice);
		multipleChoiceVO.setMin_multiple_choice(min_multiple_choice);
		multipleChoiceVO.setMax_multiple_choice(max_multiple_choice);
		// -----------------------------------------------------------
		// 3-8. [composition] 패키지의 SubjectiveChoiceVO 에 setter로 저장
		subjectiveChoiceVO.setSurvey_id_num(survey_id_num);
		subjectiveChoiceVO.setQuestion_id_num(question_id_num);
		subjectiveChoiceVO.setIs_personal_info(is_personal_info);
		subjectiveChoiceVO.setIs_duplicate(is_duplicate);
		// -----------------------------------------------------------
		// 3-9. [composition] 패키지의 MatrixQuestionVO 에 setter로 저장
		matrixQuestionVO.setSurvey_id_num(survey_id_num);
		matrixQuestionVO.setQuestion_id_num(question_id_num);
		matrixQuestionVO.setMatrix_num(matrix_num);
		matrixQuestionVO.setMatrix_contents(matrix_contents);
		// -----------------------------------------------------------
		// 3-10. [composition] 패키지의 MatrixChoiceVO 에 setter로 저장
		matrixChoiceVO.setSurvey_id_num(survey_id_num);
		matrixChoiceVO.setQuestion_id_num(question_id_num);
		matrixChoiceVO.setMatrix_choice_num(matrix_choice_num);
		matrixChoiceVO.setMatrix_choice_contents(matrix_choice_contents);
		
		// <카운트 변수 설정/출력 및 입력된 데이터에 대한 분기 처리>
		// 1. 넘어온 매개변수들 중 일부만 넘어올 수 있다.
		// 2. 넘어온 매개변수들의 입력된 상태에 맞춰서 처리해야 한다.
		// 3. 반복 insert문(<foreach> 태그의 반복 수행문) 사용하기 위해 DAO에 전달할 카운트 변수를 먼저 설정한다.
		// -----------------------------------------------------------
		System.out.println();
		System.out.println("<카운트 변수 정보>");
		// 3-1. 페이지 수 
		int page_count = request.getParameterValues("page_num").length;
		System.out.println("1. 페이지 수 : "+page_count);
		
		// 3-2. 페이지별 질문 수
		List<Integer> question_count = new ArrayList<>();
		System.out.println("2. 질문 수 : ");
		for(int i = 0; i < page_count; i++) // i : 페이지 순번
		{
		    // 페이지별 질문의 개수를 페이지 번호 별로 저장
		    question_count.add(i, request.getParameterValues("question_id_num_p"+(i+1)).length);
		    
		    // 페이지별 질문의 개수를 출력
		    System.out.println(i+" 페이지에 대한 질문 수 : "+question_count.get(i));
		}
		
		// 3-3. 질문별 표형(행) 질문 개수
		List<Integer> matrix_question_count_per_page = new ArrayList<>();
		List<List<Integer>> matrix_question_count = new ArrayList<>();
		System.out.println();
		System.out.println("3. 질문별 표형(행) 질문 개수 : ");
		for(int i = 0; i < page_count; i++)
		{
		    // 페이지 번호 출력
		    System.out.println("["+i+" 페이지]");
		    
		    // 페이지당 질문의 개수만큼 반복
		    for(int j = 0; j < question_count.get(i); j++)
		    {
		        // 페이지당 질문번호 단위로 표형 질문의 개수를 request 객체로부터 전달 받음
		        int matrix_question_count_per_question = request.getParameterValues("matrix_num_p"+(i+1)+"_q"+(j+1)).length;
		        
		        // 페이지당 질문번호 단위로 표형 질문의 개수를 저장
		        matrix_question_count_per_page.add(j, matrix_question_count_per_question);
		        
		        // 질문 번호 및 개수값 출력
                System.out.println(i+" 페이지의 "+j+"번 질문에 대한 표형(행) 질문의 개수 : "+matrix_question_count_per_page.get(j));
		    }
		    
		    // 페이지당 마지막 질문번호에 도달시 i+1 페이지의 matrix_question_count 에 저장 처리
		    matrix_question_count.add(i, matrix_question_count_per_page);
		    
		    // 청소
		    matrix_question_count_per_page.clear();
		}
		
		// 3-4. 질문별 표형(열) 보기 개수
        List<Integer> matrix_choice_count_per_page = new ArrayList<>();
        List<List<Integer>> matrix_choice_count = new ArrayList<>();
        System.out.println();
        System.out.println("4. 질문별 표형(열) 보기 개수 : ");
        for(int i = 0; i < page_count; i++)
        {
            // 페이지 번호 출력
            System.out.println("["+i+" 페이지]");
            
            // 페이지당 질문의 개수만큼 반복
            for(int j = 0; j < question_count.get(i); j++)
            {
                // 페이지당 질문번호 단위로 표형 질문의 개수를 request 객체로부터 전달 받음
                int matrix_choice_count_per_question = request.getParameterValues("matrix_num_p"+(i+1)+"_q"+(j+1)).length;
                
                // 페이지당 질문번호 단위로 표형 질문의 개수를 저장
                matrix_choice_count_per_page.add(j, matrix_choice_count_per_question);
                
                // 질문 번호 및 개수값 출력
                System.out.println(i+" 페이지의 "+j+"번 질문에 대한 표형(행) 질문의 개수 : "+matrix_choice_count_per_page.get(j));
            }
            
            // 페이지당 마지막 질문번호에 도달시 i+1 페이지의 matrix_question_count 에 저장 처리
            matrix_choice_count.add(i, matrix_choice_count_per_page);
            
            // 청소
            matrix_choice_count_per_page.clear();
        }
		// -----------------------------------------------------------
        // 4-1. BasicSurveyInfoVO 값 -> 넘어오면 처리 
        if(basicSurveyInfoVO != null)
        {
            basicSurveyInfoVO_Result = surveyQuestionCompoService.addBasicSurveyInfo(basicSurveyInfoVO);
        }
        // -----------------------------------------------------------
        // 4-2. AddSurveyInfoVO 값 -> 넘어오면 처리 
        if(addSurveyInfoVO != null)
        {
            addSurveyInfoVO_Result = surveyQuestionCompoService.addAddSurveyInfo(addSurveyInfoVO);
        }
        // -----------------------------------------------------------
        // 4-3. IdCertificationVO 값 -> 넘어오면 처리
        if(idCertificationVO != null)
        {
            idCertificationVO_Result = surveyQuestionCompoService.addIdCertification(idCertificationVO);
        }
        // -----------------------------------------------------------
        // 4-4. AddInfoCollectVO 값 -> 넘어오면 처리
        if(addInfoCollectVO != null)
        {
            addInfoCollectVO_Result = surveyQuestionCompoService.addAddInfoCollect(addInfoCollectVO);
        }
        // -----------------------------------------------------------
		// 4-5. ChoiceInfoVO 값 -> 넘어오면 처리  
		if(choiceInfoVO != null)
		{
			choiceInfoVO_Result = surveyQuestionCompoService.addChoiceInfo(choiceInfoVO, page_count, question_count);
		}
		// -----------------------------------------------------------
		// 4-6. MatrixChoiceVO 값 -> 넘어오면 처리 
		if(matrixChoiceVO != null)
		{
			matrixChoiceVO_Result = surveyQuestionCompoService.addMatrixChoice(matrixChoiceVO, page_count, question_count);
		}
		// -----------------------------------------------------------
		// 4-7. MatrixQuestionVO 값 -> 넘어오면 처리 
		if(matrixQuestionVO != null)
		{
			matrixQuestionVO_Result = surveyQuestionCompoService.addMatrixQuestion(matrixQuestionVO, page_count, question_count);
		}
		// -----------------------------------------------------------
		// 4-8. MultipleChoiceVO 값 -> 넘어오면 처리
		if(multipleChoiceVO != null)
		{
			multipleChoiceVO_Result = surveyQuestionCompoService.addMultipleChoice(multipleChoiceVO, page_count);
		}
		// -----------------------------------------------------------
		// 4-9. QuestionInfoVO 값 -> 넘어오면 처리
		if(questionInfoVO != null)
		{
			questionInfoVO_Result = surveyQuestionCompoService.addQuestionInfo(questionInfoVO, page_count);
		}
		// -----------------------------------------------------------
		// 4-10. SubjectiveChoiceVO 값 -> 넘어오면 처리
		if(subjectiveChoiceVO != null)
		{
			subjectiveChoiceVO_Result = surveyQuestionCompoService.addSubjectiveChoice(subjectiveChoiceVO, page_count);
		}
		
		// <리디렉션 처리>
		// 1. ModelAndView 객체에 redirect 주소값 전송
		// 2. 해당 주소값을 가진 ModelAndView 객체를 리턴시킴
		ModelAndView mav = new ModelAndView("redirect:/composition/survey_result_main.do");
		return mav;
	}
}