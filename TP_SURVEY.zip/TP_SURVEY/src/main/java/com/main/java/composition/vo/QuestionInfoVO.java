package com.main.java.composition.vo;

import org.springframework.stereotype.Component;

import lombok.*;

@Getter
@Setter

@Component("QuestionInfoVO")
public class QuestionInfoVO 
{
	private int survey_id_num; // 설문 식별번호
	private int[] page_num; // 페이지 번호
	private int[] question_id_num; // 질문 식별번호
	private String[] question_type; // 질문 유형
	private String[] question_contents; // 질문 내용
	// private String is_required_response; // 필수 응답 여부 -> 추후 논의하여 활성화 여부 결정
}