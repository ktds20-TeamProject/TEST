package com.main.java.composition.vo;

import java.util.List;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

// QUESTION_INFO 테이블 참조
@Component("QuestionInfoVO")
public class QuestionInfoVO 
{
	private String survey_id_num;                 // 설문 식별번호
	private List<String> page_num;                // 페이지 번호   : 페이지가 여러 개이다.
	private List<List<String>> question_id_num;   // 질문 식별번호 : 페이지가 여러 개이고, 페이지별 질문이 여러 개이다.
	private List<List<String>> question_type;     // 질문 유형     : 페이지가 여러 개이고, 페이지별 질문이 여러 개이다.
	private List<List<String>> question_contents; // 질문 내용     : 페이지가 여러 개이고, 페이지별 질문이 여러 개이다.
	// private List<List<String>> is_required_response; // 필수 응답 여부 -> 추후 논의하여 활성화 여부 결정
}