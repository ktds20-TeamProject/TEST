package com.main.java.composition.vo;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Component("MatrixChoiceVO")
public class MatrixChoiceVO 
{
	private String survey_id_num;                                            // 설문 식별번호
	private List<String> page_num;                                           // 페이지 번호   : 페이지는 여러 개이다.
	private Map<Integer, List<String>> question_id_num;                      // 질문 식별번호 : 페이지는 여러 개이며, 페이지별 질문은 여러 개이다.
	private Map<Integer, Map<Integer, List<String>>> matrix_choice_num;      // 표형 보기번호 : 페이지는 여러 개이며, 페이지별 질문은 여러 개이며, 질문별 보기는 여러 개이다.
	private Map<Integer, Map<Integer, List<String>>> matrix_choice_contents; // 표형 보기내용 : 페이지는 여러 개이며, 페이지별 질문은 여러 개이며, 질문별 보기는 여러 개이다. 
}