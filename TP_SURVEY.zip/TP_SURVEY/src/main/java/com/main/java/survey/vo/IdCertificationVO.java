package com.main.java.survey.vo;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Component("idCertificationVO")
public class IdCertificationVO           // 본인확인 
{
	private String survey_id_num;        // 설문 식별번호 -- page 1
	private String certification_notice; // 본인확인 안내문 -- page 1
}
