package com.main.java.composition.dao;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;

public interface SurveyQuestionCompoDAO 
{
    // [survey] 패키지
    public int insertBasicSurveyInfo(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException;
    public int insertAddSurveyInfo(AddSurveyInfoVO addSurveyInfoVO) throws DataAccessException;
    public int insertIdCertification(IdCertificationVO idCertificationVO) throws DataAccessException;
    public int insertAddInfoCollect(AddInfoCollectVO addInfoCollectVO) throws DataAccessException;
	
    // [composition] 패키지
    public int insertQuestionInfo(Map<String, Object> question_info_map, int page_count, List<Integer> question_counts) throws DataAccessException;
    public int insertChoiceInfo(Map<String, Object> choice_info_map, int page_count, List<Integer> question_counts, List<Integer> choice_counts) throws DataAccessException;
    public int insertMultipleChoice(Map<String, Object> multiple_choice_map) throws DataAccessException;
    public int insertSubjectiveChoice(Map<String, Object> subjective_choice_map) throws DataAccessException;
    public int insertMatrixQuestion(Map<String, Object> matrix_question_map) throws DataAccessException;
	public int insertMatrixChoice(Map<String, Object> matrix_choice_map) throws DataAccessException;
}