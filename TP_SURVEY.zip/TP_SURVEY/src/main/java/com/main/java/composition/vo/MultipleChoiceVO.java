package com.main.java.composition.vo;

import java.util.List;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Component("MultipleChoiceVO")
public class MultipleChoiceVO 
{
	private int survey_id_num;               // 설문 식별번호
	private List<Integer> question_id_num;   // 질문 식별번호
	private List<String> choice_description; // 보기 설명 : 페이지가 여러 개이고, 페이지별 질문이 여러 개이다.
	private List<String> choice_type;        // 보기 유형 : 
	// private List<String> choice_count;    // 질문 하나당 보기 개수 -> 활성화 여부 논의 중
	private List<String> is_other_choice;    // 기타 응답 여부
}