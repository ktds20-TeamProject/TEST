package com.main.java.composition.vo;

import org.springframework.stereotype.Component;

import lombok.*;

@Getter
@Setter

@Component("MultipleChoiceVO")
public class MultipleChoiceVO 
{
	private int survey_id_num; // 설문 식별번호
	private int[] question_id_num; // 질문 식별번호
	private String[] choice_description; // 보기 설명
	private String[] choice_type; // 보기 유형
	private int[] choice_count; // 질문 하나당 보기 개수
	private String[] is_other_choice; // 기타 응답 여부
	private String[] other_contents; // 기타 응답 내용
}