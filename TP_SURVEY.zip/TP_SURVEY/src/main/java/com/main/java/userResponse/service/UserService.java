package com.main.java.userResponse.service;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import com.main.java.composition.vo.TotalChoiceInfoVO;
import com.main.java.composition.vo.TotalQuestionInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.userResponse.vo.UserVO;


public interface UserService {
	//유저 메인 리스트 가져오기
	public List selectSurveyList(BasicSurveyInfoVO basicSurveyInfo)throws DataAccessException;
	
	//유저 설문 동의문 가져오기
	public BasicSurveyInfoVO selectagreement(String survey_id_num) throws DataAccessException;
	
	//문항 정보 가져오기
	public List<TotalQuestionInfoVO> questionInfoView(Map paraMapquestionInfo)throws Exception;
	
	//설문 총 질문갯수
	public int totalQuestionNum(Map paraMapquestionInfo) throws Exception; 
	
	//해당페이지 질문갯수
	public int countQuestion(Map paraMapquestionInfo) throws Exception; 
	
	//객관식 보기 최대갯수
	public int maxChoiceNum(String survey_id_num)throws Exception;
	
	//표형 질문 최대갯수
	public int maxMatrixQuestionNum(String survey_id_num)throws Exception;
	
	//표형 보기 최대갯수
	public int maxMatrixChoiceNum(String survey_id_num)throws Exception;
	
	//해당페이지 첫 문항 번호
	public int firstQuestionNumOfPage(Map paraMapquestionInfo) throws Exception; 
	
	//표형문항 질문 정보
	public List<TotalChoiceInfoVO> matrixTableQuestionInfoView(Map paraMap)throws Exception;
	
	//표형문항 답변 정보
	public List<TotalChoiceInfoVO> matrixTableChoiceInfoView(Map paraMap)throws Exception;
	
	//마지막 페이지 번호 정보
	public int maxPageNum(String survey_id_num)throws Exception;
	
	//웅답정보 저장
	public int insertUserResponse(List surveyResponse)throws Exception;
	
	//마지막유저 번호
	public int selectUserNum(String survey_id_num)throws Exception;
	
	//설문 종료문 불러오기
	public String selectsurveyEndNotice(String survey_id_num)throws Exception;
	
}
