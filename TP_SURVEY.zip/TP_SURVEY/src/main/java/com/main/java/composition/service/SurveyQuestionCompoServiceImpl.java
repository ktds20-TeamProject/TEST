package com.main.java.composition.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.main.java.composition.dao.SurveyQuestionCompoDAO;
import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;

@Service("compositionService")
@Transactional(propagation = Propagation.REQUIRED)
public class SurveyQuestionCompoServiceImpl implements SurveyQuestionCompoService 
{
    /* 의존성 주입 */
    
	@Autowired
	private SurveyQuestionCompoDAO surveyQuestionCompoDAO;
	
	//----------------------------------------------------------------------------
	
	/* [survey] 패키지 */
	
	@Override
    public int addBasicSurveyInfo(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertBasicSurveyInfo(basicSurveyInfoVO);
    }
	
	@Override
    public int addAddSurveyInfo(AddSurveyInfoVO addSurveyInfoVO) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertAddSurveyInfo(addSurveyInfoVO);
    }
	
	@Override
    public int addIdCertification(IdCertificationVO idCertificationVO) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertIdCertification(idCertificationVO);
    }
	
	@Override
    public int addAddInfoCollect(AddInfoCollectVO addInfoCollectVO) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertAddInfoCollect(addInfoCollectVO);
    }
	
	//----------------------------------------------------------------------------
	
	/* [composition(new survey)] 패키지 */
	
    @Override
    public int addQuestionInfo(Map<String, Object> question_info_map, int page_count, List<Integer> question_counts) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertQuestionInfo(question_info_map, page_count, question_counts);
    }
    
	@Override
	public int addChoiceInfo(Map<String, Object> choice_info_map) throws DataAccessException
	{
		return surveyQuestionCompoDAO.insertChoiceInfo(choice_info_map);
	}

    @Override
    public int addMultipleChoice(Map<String, Object> multiple_choice_map) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertMultipleChoice(multiple_choice_map);
    }
    
    @Override
    public int addSubjectiveChoice(Map<String, Object> subjective_choice_map) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertSubjectiveChoice(subjective_choice_map);
    }
    
    @Override
    public int addMatrixQuestion(Map<String, Object> matrix_choice_map) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertMatrixQuestion(matrix_choice_map);
    }
    
	@Override
	public int addMatrixChoice(Map<String, Object> matrix_question_map) throws DataAccessException
	{
		return surveyQuestionCompoDAO.insertMatrixChoice(matrix_question_map);
	}
}
