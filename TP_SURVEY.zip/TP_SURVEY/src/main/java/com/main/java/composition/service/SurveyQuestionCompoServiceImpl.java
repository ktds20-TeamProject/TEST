package com.main.java.composition.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.main.java.composition.dao.SurveyQuestionCompoDAO;
import com.main.java.composition.vo.ChoiceInfoVO;
import com.main.java.composition.vo.MatrixChoiceVO;
import com.main.java.composition.vo.MatrixQuestionVO;
import com.main.java.composition.vo.MultipleChoiceVO;
import com.main.java.composition.vo.QuestionInfoVO;
import com.main.java.composition.vo.SubjectiveChoiceVO;
import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;

@Service("compositionService")
@Transactional(propagation = Propagation.REQUIRED)
public class SurveyQuestionCompoServiceImpl implements SurveyQuestionCompoService 
{
	@Autowired
	private SurveyQuestionCompoDAO surveyQuestionCompoDAO;
	
	@Override
    public int addBasicSurveyInfo(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertBasicSurveyInfo(basicSurveyInfoVO);
    }
	
	@Override
    public int addAddSurveyInfo(AddSurveyInfoVO addSurveyInfoVO) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertAddSurveyInfo(addSurveyInfoVO);
    }
	
	@Override
    public int addIdCertification(IdCertificationVO idCertificationVO) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertIdCertification(idCertificationVO);
    }
	
	@Override
    public int addAddInfoCollect(AddInfoCollectVO addInfoCollectVO) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertAddInfoCollect(addInfoCollectVO);
    }
	
	@Override
	public int addChoiceInfo(ChoiceInfoVO choiceInfoVO, int page_count, List<Integer> question_count) throws DataAccessException
	{
		return surveyQuestionCompoDAO.insertChoiceInfo(choiceInfoVO, page_count, question_count);
	}
	
	@Override
	public int addMatrixChoice(MatrixChoiceVO matrixChoiceVO, int page_count, List<Integer> question_count) throws DataAccessException
	{
		return surveyQuestionCompoDAO.insertMatrixChoice(matrixChoiceVO, page_count, question_count);
	}
	
	@Override
	public int addMatrixQuestion(MatrixQuestionVO matrixQuestionVO, int page_count, List<Integer> question_count) throws DataAccessException
	{
		return surveyQuestionCompoDAO.insertMatrixQuestion(matrixQuestionVO, page_count, question_count);
	}
	
	@Override
	public int addMultipleChoice(MultipleChoiceVO multipleChoiceVO, int page_count) throws DataAccessException
	{
		return surveyQuestionCompoDAO.insertMultipleChoice(multipleChoiceVO, page_count);
	}
	
	@Override
	public int addQuestionInfo(QuestionInfoVO questionInfoVO, int page_count) throws DataAccessException
	{
		return surveyQuestionCompoDAO.insertQuestionInfo(questionInfoVO, page_count);
	}
	
	@Override
	public int addSubjectiveChoice(SubjectiveChoiceVO subjectiveChoiceVO, int page_count) throws DataAccessException
	{
		return surveyQuestionCompoDAO.insertSubjectiveChoice(subjectiveChoiceVO, page_count);
	}
}
