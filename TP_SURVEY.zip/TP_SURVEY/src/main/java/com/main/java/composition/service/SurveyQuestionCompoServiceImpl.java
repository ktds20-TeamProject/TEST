package com.main.java.composition.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.main.java.composition.dao.SurveyQuestionCompoDAO;
import com.main.java.composition.vo.ChoiceInfoVO;
import com.main.java.composition.vo.MatrixChoiceVO;
import com.main.java.composition.vo.MatrixQuestionVO;
import com.main.java.composition.vo.MultipleChoiceVO;
import com.main.java.composition.vo.QuestionInfoVO;
import com.main.java.composition.vo.SubjectiveChoiceVO;
import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;

@Service("compositionService")
@Transactional(propagation = Propagation.REQUIRED)
public class SurveyQuestionCompoServiceImpl implements SurveyQuestionCompoService 
{
	@Autowired
	private SurveyQuestionCompoDAO surveyQuestionCompoDAO;
	
	@Override
    public int addBasicSurveyInfo(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertBasicSurveyInfo(basicSurveyInfoVO);
    }
	
	@Override
    public int addAddSurveyInfo(AddSurveyInfoVO addSurveyInfoVO) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertAddSurveyInfo(addSurveyInfoVO);
    }
	
	@Override
    public int addIdCertification(IdCertificationVO idCertificationVO) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertIdCertification(idCertificationVO);
    }
	
	@Override
    public int addAddInfoCollect(AddInfoCollectVO addInfoCollectVO) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertAddInfoCollect(addInfoCollectVO);
    }
	
	@Override
	public int addChoiceInfo(ChoiceInfoVO choiceInfoVO) throws DataAccessException
	{
		return surveyQuestionCompoDAO.insertChoiceInfo(choiceInfoVO);
	}
	
	@Override
	public int addMatrixChoice(MatrixChoiceVO matrixChoiceVO) throws DataAccessException
	{
		return surveyQuestionCompoDAO.insertMatrixChoice(matrixChoiceVO);
	}
	
	@Override
	public int addMatrixQuestion(MatrixQuestionVO matrixQuestionVO) throws DataAccessException
	{
		return surveyQuestionCompoDAO.insertMatrixQuestion(matrixQuestionVO);
	}
	
	@Override
	public int addMultipleChoice(MultipleChoiceVO multipleChoiceVO) throws DataAccessException
	{
		return surveyQuestionCompoDAO.insertMultipleChoice(multipleChoiceVO);
	}
	
	@Override
	public int addQuestionInfo(QuestionInfoVO questionInfoVO) throws DataAccessException
	{
		return surveyQuestionCompoDAO.insertQuestionInfo(questionInfoVO);
	}
	
	@Override
	public int addSubjectiveChoice(SubjectiveChoiceVO subjectiveChoiceVO) throws DataAccessException
	{
		return surveyQuestionCompoDAO.insertSubjectiveChoice(subjectiveChoiceVO);
	}
}
