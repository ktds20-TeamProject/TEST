package com.main.java.composition.service;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.main.java.composition.dao.SurveyQuestionCompoDAO;
import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.IdCertificationVO;

@Service("compositionService")
@Transactional(propagation = Propagation.REQUIRED)
public class SurveyQuestionCompoServiceImpl implements SurveyQuestionCompoService 
{
    /* 의존성 주입 */
    
	@Autowired
	private SurveyQuestionCompoDAO surveyQuestionCompoDAO;
	
	//----------------------------------------------------------------------------
	
	/* 기타 */
	
	@Override
	public Date getSurvey_creation_date() throws DataAccessException
	{
		Date survey_creation_date = null;
		survey_creation_date = surveyQuestionCompoDAO.getSurvey_creation_date();
		return survey_creation_date;
	}
	
	@Override
	public String getSurvey_id_num() throws DataAccessException
	{
		String survey_id_num = "";
		survey_id_num = surveyQuestionCompoDAO.getSurvey_id_num();
		return survey_id_num;
	}
	
	//----------------------------------------------------------------------------
	
	/* [survey] 패키지 */
	
	@Override
    public int addBasicSurveyInfo(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertBasicSurveyInfo(basicSurveyInfoVO);
    }
	
	@Override
    public int addAddSurveyInfo(AddSurveyInfoVO addSurveyInfoVO) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertAddSurveyInfo(addSurveyInfoVO);
    }
	
	@Override
    public int addIdCertification(IdCertificationVO idCertificationVO) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertIdCertification(idCertificationVO);
    }
	
	@Override
    public int addAddInfoCollect(AddInfoCollectVO addInfoCollectVO) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertAddInfoCollect(addInfoCollectVO);
    }
	
	//----------------------------------------------------------------------------
	
	/* [composition(new survey)] 패키지 */
	
    @Override
    public int addQuestionInfo(Map<String, Object> question_info_map, int page_count, List<Integer> question_counts) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertQuestionInfo(question_info_map, page_count, question_counts);
    }
    
	@Override
	public int addChoiceInfo(Map<String, Object> choice_info_map, int page_count, List<Integer> question_counts, List<Integer> choice_counts) throws DataAccessException
	{
		return surveyQuestionCompoDAO.insertChoiceInfo(choice_info_map, page_count, question_counts, choice_counts);
	}

    @Override
    public int addMultipleChoice(Map<String, Object> multiple_choice_map, int page_count, List<Integer> question_counts) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertMultipleChoice(multiple_choice_map, page_count, question_counts);
    }
    
    @Override
    public int addSubjectiveChoice(Map<String, Object> subjective_choice_map, int page_count, List<Integer> question_counts) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertSubjectiveChoice(subjective_choice_map, page_count, question_counts);
    }
    
    @Override
    public int addMatrixQuestion(Map<String, Object> matrix_question_map, int page_count, List<Integer> question_counts, List<Integer> matrix_questions) throws DataAccessException
    {
        return surveyQuestionCompoDAO.insertMatrixQuestion(matrix_question_map, page_count, question_counts, matrix_questions);
    }
    
	@Override
	public int addMatrixChoice(Map<String, Object> matrix_question_map, int page_count, List<Integer> question_counts, List<Integer> matrix_choices) throws DataAccessException
	{
		return surveyQuestionCompoDAO.insertMatrixChoice(matrix_question_map, page_count, question_counts, matrix_choices);
	}
}
