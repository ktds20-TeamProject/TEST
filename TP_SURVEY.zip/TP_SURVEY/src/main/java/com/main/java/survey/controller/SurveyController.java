package com.main.java.survey.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.main.java.survey.service.SurveyService;
import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.AddressEmailVO;
import com.main.java.survey.vo.AddressInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.ChoiceInfoVO;
import com.main.java.survey.vo.IdCertificationVO;
import com.main.java.survey.vo.MatrixChoiceVO;
import com.main.java.survey.vo.MatrixQuestionVO;
import com.main.java.survey.vo.MultipleChoiceVO;
import com.main.java.survey.vo.QuestionInfoVO;
import com.main.java.survey.vo.SubjectiveChoiceVO;

@Controller("SurveyController")
public class SurveyController {
	@Autowired
	private SurveyService surveyService;
	@Autowired
	AddInfoCollectVO addInfoCollect;
	@Autowired
	AddSurveyInfoVO addSurveyInfo;
	@Autowired
	BasicSurveyInfoVO basicSurveyInfo;
	@Autowired
	IdCertificationVO idCertification;
	@Autowired
	ChoiceInfoVO choiceInfo;
	@Autowired
	MatrixChoiceVO matrixChoice;
	@Autowired
	MatrixQuestionVO matrixQuestion;
	@Autowired
	MultipleChoiceVO multipleChoice;
	@Autowired
	QuestionInfoVO questionInfo;
	@Autowired
	SubjectiveChoiceVO subjectiveChoice;
	@Autowired
	AddressInfoVO addressInfoVO;
	@Autowired
	AddressEmailVO addressEmailVO;
	
	
	
//설문 리스트 페이지
	@RequestMapping(value = "/survey_info_and_option.do", method = RequestMethod.GET)
	private ModelAndView survey_info_and_option(HttpServletRequest request, HttpServletResponse response) {
		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView();
		mav.setViewName(viewName);
		return mav;
	}
	
	//설문 만들기 클릭
	@RequestMapping(value = "/surveymake.do", method = RequestMethod.GET)
	private ModelAndView surveymake(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:/survey_info_and_option.do");
		return mav;
		
	}
	
	//설문 정보 및 옵션 설정 페이지에서 다음버튼 누르기
	@RequestMapping(value = "/next_survey_info_and_option.do", method = RequestMethod.GET)
	private ModelAndView next_survey_info_and_option (HttpServletRequest request, HttpServletResponse response)
	{
		
		HttpSession session = request.getSession(); // 기존세션에 추가(세션이 없다면 세션 생성)
		
		//VO객체생성
		BasicSurveyInfoVO basicSurveyInfo = new BasicSurveyInfoVO();
		AddSurveyInfoVO addSurveyInfo = new AddSurveyInfoVO();
		
		//설문관리제목
		basicSurveyInfo.setAdmin_title(request.getParameter("administrativeTitle")); //파라미터로 값 받아오기
		
		//시작날짜 종료날짜 sqlDate로 형변환
		String surveyStartDate = request.getParameter("surveyStartDate");
		String surveyEndDate = request.getParameter("endDate");
		java.sql.Date survey_start_date = java.sql.Date.valueOf(surveyStartDate);
		java.sql.Date survey_end_date = java.sql.Date.valueOf(surveyEndDate);
		
		//시작날짜 종료날짜 객체저장
		basicSurveyInfo.setSurvey_start_date(survey_start_date);
		basicSurveyInfo.setSurvey_end_date(survey_end_date);
		
		//익명응답여부
		addSurveyInfo.setIs_anonymous_respondent(request.getParameter("isAnonymous"));
		
		//응답자 제한 여부
		basicSurveyInfo.setIs_limit_respondent(request.getParameter("isLimit"));
		
		//응답자 제한 수
		basicSurveyInfo.setLimit_respondent_num(request.getParameter("limitNum"));
		
		//본인확인여부
		addSurveyInfo.setIs_certify_id(request.getParameter("isConfirmIdentification"));
		
		//세션에 객체추가(설문 기본정보)
		session.setAttribute("basicSurveyInfo", basicSurveyInfo);
		session.setAttribute("addSurveyInfo", addSurveyInfo);
		
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:/survey_new_compo.do"); //리다이렉트로 /SurveyQuestionCompo.do 실행
		return mav;
	}
	
	//설문 기본정보 페이지
	@RequestMapping(value = "/survey_new_compo.do", method = RequestMethod.GET)
	private ModelAndView SurveyBasicComposition(HttpServletRequest request, HttpServletResponse response) {
		
		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView();
		mav.setViewName(viewName);
		return mav;
	}

	
	
	
	
	
	
	
	
	
	// 주소록 화면 접속
    @RequestMapping(value = "/admin_survey_send.do", method = { RequestMethod.GET, RequestMethod.POST })
    public ModelAndView surveySendForm(@RequestParam(value = "survey_id_num", required = false) String survey_id_num,
            HttpServletRequest request, HttpServletResponse response) throws Exception {
        String viewName = (String) request.getAttribute("viewName");
        ModelAndView mav = new ModelAndView();
        mav.addObject("survey_id_num", survey_id_num);
        mav.setViewName(viewName);
        return mav;
    }
    
    //저장 버튼 - 주소록 저장 (기능)
    //@Override
    @RequestMapping(value = "/survey_address_save.do", method = { RequestMethod.GET, RequestMethod.POST })
    @ResponseBody
    public Map<String, Integer> surveyAddressSave (@RequestParam Map<String, Object> parameters) throws Exception {
    	//받아온 JSON 파라미터를 받아옴
    	String userListJson = parameters.get("userList").toString();
    	ObjectMapper mapper = new ObjectMapper();
    	List<AddressInfoVO> userList = mapper.readValue(userListJson, new TypeReference<ArrayList<AddressInfoVO>>() {}); 
    	String emailInfoJson = parameters.get("emailInfo").toString();
    	AddressEmailVO emailInfo = mapper.readValue(emailInfoJson, new TypeReference<AddressEmailVO>() {});
    	String survey_id_num = (String) parameters.get("survey_id_num");
    	
    	int resultU = 0;
    	int resultE = 0;
    	
    	//주소록 테이블 리셋하고 수신자 리스트 정보를 저장
    	int deleteU = surveyService.deleteAddressInfo(survey_id_num);
    	for (int i=0; i<userList.size(); i++) {
    		AddressInfoVO vo = userList.get(i);
    		vo.setSurvey_id_num(survey_id_num);
    		resultU = surveyService.insertAddressInfo(vo);
    	}
    	//메일정보 테이블 리셋하고 메일 정보를 저장
    	int deleteE = surveyService.deleteAddressEmail(survey_id_num);
    	emailInfo.setSurvey_id_num(survey_id_num);
    	resultE = surveyService.insertAddressEmail(emailInfo);
    	
    	Map <String, Integer> resultMap = new HashMap();
    	resultMap.put("resultU", resultU);
    	resultMap.put("resultE", resultE);
    	return resultMap;
    }
    
    //완료 버튼 - 주소록 저장 및 메일 발신 (기능)
    //@Override
    @RequestMapping(value = "/survey_send.do", method = { RequestMethod.GET, RequestMethod.POST })
    public ModelAndView surveySend(@RequestParam(value = "survey_id_num", required = false) String survey_id_num,
    		@ModelAttribute("AddressInfoList") AddressInfoVO AddressInfoList,
            @ModelAttribute("AddressEmail") AddressEmailVO AddressEmail,
            RedirectAttributes rAttr, HttpServletRequest request, HttpServletResponse response) throws Exception {
    	ModelAndView mav = new ModelAndView();
//    	HttpSession session = request.getSession();
    	
        //이 설문의 기본 정보 불러오기
    	BasicSurveyInfoVO surveyInfo = surveyService.surveyInfoView(survey_id_num);
    	//VO형태로 가져온 수신자 리스트(List<VO>형태) 꺼내기
    	List <AddressInfoVO> userList = AddressInfoList.getAddressInfoVOList();
    	
    	//주소록 테이블 리셋하고 수신자 리스트 정보를 저장
    	int deleteU = surveyService.deleteAddressInfo(survey_id_num);
    	for (int i=0; i<userList.size(); i++) {
    		AddressInfoVO vo = userList.get(i);
    		vo.setSurvey_id_num(survey_id_num);
    		int result = surveyService.insertAddressInfo(vo);
    	}
    	//메일정보 테이블 리셋하고 메일 정보를 저장
    	int deleteE = surveyService.deleteAddressEmail(survey_id_num);
    	AddressEmail.setSurvey_id_num(survey_id_num);
    	int result = surveyService.insertAddressEmail(AddressEmail);

    	//수신자 리스트에 메일 발송
    	surveyService.surveySendMail(surveyInfo, userList, AddressEmail.getEmail_title(), AddressEmail.getEmail_content(), request);

    	//페이지 나가면서 세션에서 서베이 아이디 넘에 대한 정보도 삭제 (세션에 뭐 남아잇는지 보고 체크하기)
//    	session.removeAttribute(survey_id_num);
    	
    	rAttr.addAttribute("result", "mailSendingDone");
        mav.setViewName("redirect:/admin_list.do");
        return mav;
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//설문 문제 페이지에서 저장 누르기
	@RequestMapping(value = "/surveySave.do", method = RequestMethod.GET)
	public ModelAndView surveySave(HttpServletRequest request, HttpServletResponse response) throws ParseException 
	{
		HttpSession session = request.getSession();
		
		Date date = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String formattedDate = simpleDateFormat.format(date);
		java.sql.Date today = java.sql.Date.valueOf(formattedDate);
		
		String admin_id = String.valueOf(session.getAttribute("adminId")); //로그인 아이디
		
		
		int lastSurveyNum=surveyService.selectLastsurveyNum(basicSurveyInfo);
		String survey_id_num = Integer.toString(lastSurveyNum+1); //설문식별번호
		String question_id_num = "1번문항"; //질문식별번호
		String page_num = "1번페이지"; //페이지번호
		
		
		
		
		//AddSurveyInfoVO 추가설문정보_세터
		addSurveyInfo.setSurvey_id_num(survey_id_num);
		addSurveyInfo.setIs_anonymous_respondent((String)session.getAttribute("is_anonymous_respondent"));
		addSurveyInfo.setIs_collect_add_info("false");
		addSurveyInfo.setIs_certify_id((String)session.getAttribute("is_confirm_identification"));
		
		int result1 = 0;
		result1 = surveyService.addAddSurveyInfo(addSurveyInfo);
		
		
		
		//String >> sqlDate 형변환
		String getStartTime = (String)session.getAttribute("survey_start_date");
		java.sql.Date startDateTime = java.sql.Date.valueOf(getStartTime);
		
		String getEndTime = (String)session.getAttribute("survey_end_date");
		java.sql.Date endDateTime = java.sql.Date.valueOf(getEndTime);
		
		//BasicSurveyInfoVO //기본설문정보_세터
		basicSurveyInfo.setSurvey_id_num(survey_id_num);
		basicSurveyInfo.setSurvey_type((String)request.getParameter("question_type"));
		basicSurveyInfo.setAdmin_title((String)session.getAttribute("admin_title"));
		basicSurveyInfo.setSurvey_start_date(startDateTime);
		basicSurveyInfo.setSurvey_end_date(endDateTime);
		basicSurveyInfo.setAdmin_id(admin_id);
		basicSurveyInfo.setTitle_input((String)session.getAttribute("title_input"));
		basicSurveyInfo.setSurvey_notice((String)session.getAttribute("survey_notice"));
		basicSurveyInfo.setAttached_image("이미지 경로입니다.");
		basicSurveyInfo.setSurvey_end_notice("설문종료문입니다.");
		basicSurveyInfo.setSurvey_creation_date(today);
		basicSurveyInfo.setLast_modify_date(today);
		basicSurveyInfo.setIs_last_modify("최신 수정여부");
		basicSurveyInfo.setIs_limit_respondent((String)session.getAttribute("is_limit_respondent"));
		basicSurveyInfo.setLimit_respondent_num((String)session.getAttribute("limit_respondent_num"));
		
		int result2 = 0;
		result2 = surveyService.addBasicSurveyInfo(basicSurveyInfo);
		
		
		//ChoiceInfoVO //객관식 보기정보_세터
		for(int i=1; i<6; i++){
		choiceInfo.setSurvey_id_num(survey_id_num);
		choiceInfo.setQuestion_id_num(question_id_num);
		choiceInfo.setChoice_num(i+"번");
		choiceInfo.setChoice_contents((String)request.getParameter("choice_contents"));
		choiceInfo.setChoice_file_path("보기별 첨부파일 경로");
		choiceInfo.setPage_num(page_num);
		
		int result3 = 0;
		result3 = surveyService.addChoiceInfo(choiceInfo);
		}
		
		
		//MultipleChoiceVO //객관식보기 세터
		multipleChoice.setSurvey_id_num(survey_id_num);
		multipleChoice.setQuestion_id_num(question_id_num);
		multipleChoice.setChoice_type("보기유형");
		multipleChoice.setChoice_count("5개");
		multipleChoice.setIs_other_choice((String)request.getParameter("is_other_choice"));
		multipleChoice.setMin_multiple_choice((String)request.getParameter("min_multiple_choice"));
		multipleChoice.setMax_multiple_choice((String)request.getParameter("max_multiple_choice"));
		multipleChoice.setPage_num(page_num);
		
		int result4= 0;
		result4 = surveyService.addMultipleChoice(multipleChoice);
		
		
		//QuestionInfoVO 질문정보_세터
		questionInfo.setQuestion_id_num(question_id_num);
		questionInfo.setSurvey_id_num(survey_id_num);
		questionInfo.setPage_num(page_num);
		questionInfo.setQuestion_type((String)request.getParameter("question_type"));
		questionInfo.setQuestion_contents((String)request.getParameter("question_contents"));
		questionInfo.setIs_required_response("true");
		questionInfo.setChoice_description((String)request.getParameter("choice_description"));
		
		int result5 = 0;
		result5 = surveyService.addQuestionInfo(questionInfo);
		
		
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:/admin_list.do");
		return mav;
	}
	

}
