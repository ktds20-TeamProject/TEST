package com.main.java.composition.vo;

import org.springframework.stereotype.Component;

import lombok.*;

@Getter
@Setter

@Component("ChoiceInfoVO")
public class ChoiceInfoVO 
{
	private int survey_id_num;             // 설문 식별번호
	private int[] question_id_num;         // 질문 식별번호 : 설문 하나당 질문은 여러개이다.
	private int[][] choice_num;            // 보기 입력번호 : 설문 하나당 질문은 여러개이며, 질문 하나당 보기가 여러개이다.
	private String[][] choice_contents;    // 보기 입력내용 : 설문 하나당 질문은 여러개이며, 질문 하나당 보기가 여러개이다.
	private String[][] choice_file_path;   // 보기별 첨부파일 경로 : 설문 하나당 질문은 여러개이며, 질문 하나당 보기가 여러개이다.
}