package com.main.java.composition.vo;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Component("ChoiceInfoVO")
public class ChoiceInfoVO 
{
	private String survey_id_num;      // 설문 식별번호
	private String page_num;           // 페이지 번호        : 페이지가 여러 개이다.
	private String question_id_num;    // 질문 식별번호      : 페이지가 여러 개이고, 페이지별 질문이 여러 개이다.
	private String choice_description; // 보기 설명          : 페이지가 여러 개이고, 페이지별 질문이 여러 개이다.
	private String choice_num;         // 보기 입력번호      : 페이지가 여러 개이고, 페이지별 질문이 여러 개이고, 질문별 보기가 여러 개이다.
	private String choice_contents;    // 보기 입력내용      : 페이지가 여러 개이고, 페이지별 질문이 여러 개이고, 질문별 보기가 여러 개이다. 
	private String choice_file_path;   // 보기 첨부파일 경로 : 페이지가 여러 개이고, 페이지별 질문이 여러 개이고, 질문별 보기가 여러 개이다.
}