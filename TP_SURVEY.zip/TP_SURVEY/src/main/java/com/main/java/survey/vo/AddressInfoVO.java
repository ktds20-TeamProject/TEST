package com.main.java.survey.vo;

import java.util.List;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString

@Component("addressInfoVO")
public class AddressInfoVO {
	
	private String survey_id_num;
	private String address_name;
	private String address_phone_num;
	private String address_email;
	
	private List<AddressInfoVO> addressInfoVOList;

}
