package com.main.java.admin.service;

import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.main.java.admin.passwordSHA256;
import com.main.java.admin.dao.AdminDAO;
import com.main.java.admin.vo.AdminVO;
import com.main.java.composition.vo.TotalChoiceInfoVO;
import com.main.java.composition.vo.TotalQuestionInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.userResponse.vo.TotalUserSurveyVO;

@Service("adminService")
@Transactional(propagation = Propagation.REQUIRED)
public class AdminServiceImpl implements AdminService{
	@Autowired
	private JavaMailSender mailSender;	
	@Autowired
	private AdminDAO adminDAO;

	//로그인
	@Override
	public AdminVO login(AdminVO adminVO) throws Exception{
		return adminDAO.login(adminVO);
	}
	
	//회원가입
	@Override
	public int join(AdminVO admin) throws DataAccessException {
		return adminDAO.insertAdmin(admin);
	}
	
	//비밀번호 체크
	@Override
	public AdminVO pwCheck(AdminVO adminVO) throws Exception {
		return adminDAO.pwCheck(adminVO);
	}
	
	//회원정보 수정
	@Override
	public int adminUpdate(AdminVO admin) throws DataAccessException {
		return adminDAO.updateAdmin(admin);
	}
	
	//회원정보 수정화면에 기존 정보 출력
	@Override
	public AdminVO infoView(AdminVO adminVO) throws Exception {
		return adminDAO.infoView(adminVO);
	}
	
	//아이디 중복확인
	@Override
	public int idDuplicated(String adminId) {
		return adminDAO.idDuplicated(adminId);
	}
	
	//회원탈퇴
	@Override
	public int deleteAdmin(AdminVO admin) throws DataAccessException {
		return adminDAO.deleteAdmin(admin);
	}
	//아이디 찾기
	@Override
	public List<String> admin_find_id(AdminVO admin) throws Exception {
		List<String> result = adminDAO.selectAllResult(admin);
		System.out.println("Service:"+result);
		return result;
	}	
	
	//비밀번호 찾기 유효성 검증
	@Override
	public AdminVO findPwCheck(AdminVO admin) throws Exception {
		return adminDAO.findPwCheck(admin);
	}
	
	
	//임시비밀번호 난수 만들기
	private String init() throws Exception {
		Random ran = new Random();
		StringBuffer sb = new StringBuffer();
		int num = 0;

		do {
			num = ran.nextInt(75) + 48;
			if ((num >= 48 && num <= 57) || (num >= 65 && num <= 90) || (num >= 97 && num <= 122)) {
				sb.append((char) num);
			} else {
				continue;
			}

		} while (sb.length() < size);
		if (lowerCheck) {
			return sb.toString().toLowerCase();
		}
		return sb.toString();
	}
	
	//난수를 이용해 키 생성하기
	private boolean lowerCheck;
	private int size;

	public String getKey(boolean lowerCheck, int size) throws Exception {
		this.lowerCheck = lowerCheck;
		this.size = size;
		return init();
	}

	//비밀번호 찾기 이메일 발송
	@Override
	public void findPwSendMail(String adminId, String email, HttpServletRequest request) throws Exception {
		//난수 임시비밀번호 생성
		String key=getKey(false,6);
		//메일 발송시 사용할 정보 불러오기
		AdminVO vo = adminDAO.findPwSendMail(adminId);
		String name = vo.getName();
		String id = vo.getAdminId();
		//메일 발송
		MimeMessage mail = mailSender.createMimeMessage();
		String htmlStr = "<h2> 안녕하세요, "+id+" ("+name+") 님</h2><br><br>"
				+ "<p>보고 정보 시스템 설문조사 플랫폼 아이디에 대한 임시 비밀번호가 발급되었습니다.</p><br>"
				+ "<p>임시 발급된 비밀번호는 <p><br><h2 style='color:blue; background-color:yellow; text-align:center;'>[ "+key+" ]</h2><br><p>이며 "
				+ "로그인 후 정보수정에서 비밀번호를 변경해주시기 바랍니다.</p><br><br>"
				+ "<p>감사합니다.</p>";
		try {
			mail.setSubject("[보고 설문조사] 임시 비밀번호가 발급되었습니다.", "utf-8");
			mail.setText(htmlStr, "utf-8", "html");
			mail.addRecipient(RecipientType.TO, new InternetAddress(email));
			mailSender.send(mail);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		//비밀번호 암호화
		key=passwordSHA256.encrypt(key);
		//암호화된 임시비밀번호를 데이터베이스에 업데이트
		vo.setPassword(key);
		int result = adminDAO.updateAdmin(vo);
	}
	
	//검색 전후 레코드 개수
	@Override
	public int surveyListCount(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException {
		return this.adminDAO.surveyListCount(basicSurveyInfoVO);
	}	
	
	//관리자 설문 관리 리스트
	@Override
	public List admin_list(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException {
		List mainList = null;
		mainList = adminDAO.surveyMainList(basicSurveyInfoVO);
		//System.out.println("service"+mainList);
		return mainList;
	}	
	
	//통계 - 설문 기본 정보 조회
		@Override
		public BasicSurveyInfoVO surveyInfoView(String survey_id_num) throws Exception {
			return adminDAO.surveyInfoView(survey_id_num);
		}
		
		//통계 - 질문 개수 카운트
		@Override
		public int countQuestion(String survey_id_num) throws Exception {
			return adminDAO.countQuestion(survey_id_num);
		}
		
		//통계 - 응답 개수 카운트
		@Override
		public int countResponse(String survey_id_num) throws Exception {
			return adminDAO.countResponse(survey_id_num);
		}
		
		//통계 - 이메일 발송 개수 카운트
		@Override
		public double countMailsend(String survey_id_num) throws Exception {
			return adminDAO.countMailsend(survey_id_num);
		}
		
		//통계 - 질문 기본 정보 조회
		@Override
		public List <TotalQuestionInfoVO> questionInfoView(String survey_id_num) throws Exception {
			return adminDAO.questionInfoView(survey_id_num);
		}
		
		//통계 - 객관식 보기 질문정보 조회
		@Override
		public TotalQuestionInfoVO MqInfoView(Map paraMap) throws Exception  {
			return adminDAO.MqInfoView(paraMap);
		}
		
		//통계 - 객관식 보기 개수 카운트
		@Override
		public int countMqC(Map paraMap) throws Exception  {
			return adminDAO.countMqC(paraMap);
		}
		
		//통계 - 객관식 보기 정보 조회
		@Override
		public List <TotalChoiceInfoVO> mcInfoView(Map paraMap) throws Exception {
			return adminDAO.mcInfoView(paraMap);
		}
		
		//통계 - 주관식 중복 여부 정보 조회
		@Override
		public TotalChoiceInfoVO scInfoView(Map paraMap) throws Exception {
			return adminDAO.scInfoView(paraMap);
		}
		
		//통계 - 객관식 표형 질문 개수 카운트
		@Override
		public int countMtqQ(Map paraMap) throws Exception  {
			return adminDAO.countMtqQ(paraMap);
		}

		//통계 - 객관식 표형 보기 개수 카운트
		@Override
		public int countMtqC(Map paraMap) throws Exception  {
			return adminDAO.countMtqC(paraMap);
		}
		
		//통계 - 객관식 표형 질문 정보 조회
		@Override
		public List <TotalChoiceInfoVO> mTableQInfoView(Map paraMap) throws Exception {
			return adminDAO.mTableQInfoView(paraMap);
		}
		
		//통계 - 객관식 표형 보기 정보 조회
		@Override
		public List <TotalChoiceInfoVO> mTableCInfoView(Map paraMap) throws Exception {
			return adminDAO.mTableCInfoView(paraMap);
		}
		
		//통계 - 객관식 개별 응답 정보 조회
		@Override
		public TotalUserSurveyVO mResponseView(Map paraMap) throws Exception {
			return adminDAO.mResponseView(paraMap);
		}
		
		//통계 - 객관식/주관식 총 응답 수 조회
		@Override
		public int CountMResponse(Map paraMap) throws Exception  {
			return adminDAO.CountMResponse(paraMap);
		}
		
		//통계 - 주관식 개별 응답 정보 조회
		@Override
		public List <TotalUserSurveyVO> sResponseView(Map paraMap) throws Exception {
			return adminDAO.sResponseView(paraMap);
		}
		
		//통계 - 표형 총 응답 수 조회
		@Override
		public int CountMTResponse(Map paraMap) throws Exception  {
			return adminDAO.CountMTResponse(paraMap);
		}
		
		//통계 - 표형 개별 응답 정보 조회
		@Override
		public TotalUserSurveyVO mTableResponseView(Map paraMap) throws Exception {
			return adminDAO.mTableResponseView(paraMap);
		}

		@Override
		public void deleteSurvey(String survey_id_num) throws Exception {
			adminDAO.SurveyDelete(survey_id_num);	
		}
		//조회 - 설문별 주소록
	      @Override
	      public List listAddress(String survey_id_num) throws DataAccessException {
	         List addressList = null;
	         addressList = adminDAO.selectAddressList(survey_id_num);
	         return addressList;
	      }		
			
			//통계 - 차트용 보기 정보 조회
			@Override
			public List <Integer> ChartChoice(Map paraMap) throws Exception {
				return adminDAO.ChartChoice(paraMap);
			}
			
			//통계 - 차트용 응답 정보 조회
			@Override
			public int ChartResponse(Map paraMap) throws Exception {
				return adminDAO.ChartResponse(paraMap);
			}
			
			//상세 통계 질문정보 조회
			@Override
			public TotalQuestionInfoVO detailQ(Map paraMap) throws Exception {
				return adminDAO.detailQ(paraMap);
			}
			
			//상세 통계 보기정보 조회
			@Override
			public List <String> detailC(Map paraMap) throws Exception {
				return adminDAO.detailC(paraMap);
			}
			
			//상세 통계 응답정보 조회
			@Override
			public List <String> detailR(Map paraMap) throws Exception {
				return adminDAO.detailR(paraMap);
			}
			
			

		
}
