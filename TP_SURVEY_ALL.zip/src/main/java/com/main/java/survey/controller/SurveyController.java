package com.main.java.survey.controller;

import java.io.UnsupportedEncodingException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.main.java.survey.vo.AddressEmailVO;
import com.main.java.survey.vo.AddressInfoVO;

public interface SurveyController {
	
	//설문 정보 및 옵션 설정 페이지
	public ModelAndView survey_info_and_option(HttpServletRequest request, HttpServletResponse response);
	
	//설문 만들기 클릭
	public ModelAndView surveymake(HttpServletRequest request, HttpServletResponse response);
	
	//설문 정보 및 옵션 설정 페이지에서 다음버튼 누르기
	public ModelAndView next_survey_info_and_option (HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException;
	
	//설문 기본정보 페이지
	public ModelAndView SurveyBasicComposition(HttpServletRequest request, HttpServletResponse response);
	
	// 주소록 화면 접속
	public ModelAndView surveySendForm(@RequestParam(value = "survey_id_num", required = false) String survey_id_num,
            HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	//저장 버튼 - 주소록 저장 (기능)
	public Map<String, Integer> surveyAddressSave (@RequestParam Map<String, Object> parameters) throws Exception;
	
	//완료 버튼 - 주소록 저장 및 메일 발신 (기능)
	public ModelAndView surveySend(@RequestParam(value = "survey_id_num", required = false) String survey_id_num,
    		@ModelAttribute("AddressInfoList") AddressInfoVO AddressInfoList,
            @ModelAttribute("AddressEmail") AddressEmailVO AddressEmail,
            RedirectAttributes rAttr, HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	
	
}
