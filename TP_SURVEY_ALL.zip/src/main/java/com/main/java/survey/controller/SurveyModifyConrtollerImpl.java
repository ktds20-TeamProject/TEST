package com.main.java.survey.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.main.java.admin.service.AdminService;
import com.main.java.composition.vo.TotalChoiceInfoVO;
import com.main.java.composition.vo.TotalQuestionInfoVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.ChoiceInfoVO;
import com.main.java.survey.vo.MatrixChoiceVO;
import com.main.java.survey.vo.MatrixQuestionVO;
import com.main.java.survey.vo.MultipleChoiceVO;
import com.main.java.survey.vo.QuestionInfoVO;
import com.main.java.userResponse.service.UserService;
import com.main.java.survey.service.SurveyModifyService;

@Controller("SurveyModifyConrtoller")
public class SurveyModifyConrtollerImpl implements SurveyModifyConrtoller{
	
	@Autowired
	private SurveyModifyService surveyModifyService;
	@Autowired
	private UserService userService;
	@Autowired
	private AdminService adminService;
	@Autowired
	QuestionInfoVO questionInfo;
	@Autowired 
	BasicSurveyInfoVO basicSurveyInfo;
	@Autowired
	TotalQuestionInfoVO totalQuestionInfo;
	@Autowired
	TotalChoiceInfoVO totalChoiceInfo;
	@Autowired
	AddSurveyInfoVO addSurveyInfo;
	@Autowired
	MultipleChoiceVO multipleChoice;
	@Autowired
	ChoiceInfoVO choiceInfo;
	@Autowired
	MatrixQuestionVO matrixQuestion;
	@Autowired
	MatrixChoiceVO matrixChoice;
	
	
	 
	//admin_list에서 수정버튼 클릭
	@Override
	@RequestMapping(value = "/survey_modify_option.do", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView survey_modify_option(String survey_id_num, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		HttpSession sessionModify = request.getSession(true);
		
		//설문번호 세션저장
		sessionModify.setAttribute("survey_id_num", survey_id_num);
		
		//설문정보를 받아올 객체 생성
		BasicSurveyInfoVO basicSurveyInfo = new BasicSurveyInfoVO();
		
		//설문 추가정보를 받아올 객체 생성
		AddSurveyInfoVO addSurveyInfo = new AddSurveyInfoVO();
		
		//설문정보 받아오기
		basicSurveyInfo = surveyModifyService.selectbasicSurveyInfo(survey_id_num);
		
		//설문 추가정보 받아오기
		addSurveyInfo = surveyModifyService.selectaddSurveyInfo(survey_id_num);
		
		
		//<c:foreach>를 돌릴 시간(hour) 배열 만드기
		List<String> hour =new ArrayList<String>();
		for(int i=0;i<24;i++) {
			if(i<10) {
				String j ="0"+String.valueOf(i);
				hour.add(j);
			}
			else {
			String j = String.valueOf(i);
			hour.add(j);
			}
		}
		
		//<c:foreach>를 돌릴 분(minute) 배열 만드기
		List<String> minute =new ArrayList<String>();
		for(int i=0;i<60;i++) {
			if(i<10) {
				String j ="0"+String.valueOf(i);
				minute.add(j);
			}
			else {
			String j = String.valueOf(i);
			minute.add(j);
			}
		}
		
		System.out.println(basicSurveyInfo.getSurvey_end_date());
		System.out.println(basicSurveyInfo.getSurvey_end_date());
		System.out.println(basicSurveyInfo.getSurvey_end_date());
		System.out.println(basicSurveyInfo.getSurvey_end_date());
		System.out.println(basicSurveyInfo.getSurvey_end_date());
		System.out.println(basicSurveyInfo.getSurvey_end_date());
		
		
		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView();
		mav.setViewName(viewName);
		mav.addObject("basicSurveyInfo", basicSurveyInfo);
		mav.addObject("addSurveyInfo", addSurveyInfo);
		mav.addObject("hour", hour);
		mav.addObject("minute", minute);
		return mav;
	}
	
	
	
	//설문 정보 및 옵션 설정 수정페이지에서 다음버튼 누르기
	@Override
	@RequestMapping(value = "/next_survey_modify_option.do", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView next_survey_modify_option(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession sessionModify = request.getSession(true);
		
		//수정된 입력값 받아와서 객체저장 후 세션 넘기기
		//DB에 업데이트 시킬 정보
		
		//VO객체생성
		BasicSurveyInfoVO basicSurveyInfo = new BasicSurveyInfoVO();
		AddSurveyInfoVO addSurveyInfo = new AddSurveyInfoVO();
		
		//설문관리제목 객체저장
		basicSurveyInfo.setAdmin_title(request.getParameter("administrativeTitle")); //파라미터로 값 받아오기
		
		//시작날짜 종료날짜 sqlDate로 형변환
		String surveyStartDate = request.getParameter("survey_start_date");
		String surveyEndDate = request.getParameter("survey_end_date");
		java.sql.Date survey_start_date = java.sql.Date.valueOf(surveyStartDate);
		java.sql.Date survey_end_date = java.sql.Date.valueOf(surveyEndDate);
		
		//설문 시작날짜 설문 종료날짜 객체저장
		basicSurveyInfo.setSurvey_start_date(survey_start_date);
		basicSurveyInfo.setSurvey_end_date(survey_end_date);
		
		//설문 시작 시간/분 객체저장
		basicSurveyInfo.setSurvey_start_hour(request.getParameter("survey_start_hour"));
		basicSurveyInfo.setSurvey_start_minute(request.getParameter("survey_start_minute"));
		
		//설문 종료 시간/분 객체저장
		basicSurveyInfo.setSurvey_end_hour(request.getParameter("survey_end_hour"));
		basicSurveyInfo.setSurvey_end_minute(request.getParameter("survey_end_minute"));
		
		//응답자 제한 여부
		basicSurveyInfo.setIs_limit_respondent(request.getParameter("is_limit_respondent"));
		
		//응답자 제한 수
		basicSurveyInfo.setLimit_respondent_num(request.getParameter("limit_respondent_num"));
		
		//익명응답여부
		addSurveyInfo.setIs_anonymous_respondent(request.getParameter("is_anonymous_respondent"));
		
		//세션에 객체추가(설문 기본정보)
		sessionModify.setAttribute("basicSurveyInfo", basicSurveyInfo);
		sessionModify.setAttribute("addSurveyInfo", addSurveyInfo);
		
		
		
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:/survey_modify_compo.do");
		return mav;
	}
	
	
	
	//설문 문항작성 수정페이지 이동
	@Override
	@RequestMapping(value = "/survey_modify_compo.do", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView survey_modify_compo(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		HttpSession sessionModify = request.getSession(true);
		
		//세션에 저장된 설문번호 꺼내기
		String survey_id_num = (String)sessionModify.getAttribute("survey_id_num");
		
		//설문정보를 받아올 객체 생성
		BasicSurveyInfoVO basicSurveyInfo = new BasicSurveyInfoVO();
		
		//객관식/드롭다운 보기정보 받아올 객체생성
		List<MultipleChoiceVO> multipleChoice = new ArrayList<MultipleChoiceVO>();
		
		//보기 번호별 정보 받아올 객체생성
		List<ChoiceInfoVO> choiceInfo =new ArrayList<ChoiceInfoVO>();
				
		//표형문항읠 질문정보를 받아올 객체 생성
		List<MatrixQuestionVO> matrixQuestion = new ArrayList<MatrixQuestionVO>();
				
		//표형문항읠 보기정보를 받아올 객체 생성
		List<MatrixChoiceVO> matrixChoice = new ArrayList<MatrixChoiceVO>();
		
		//설문정보 받아오기
		basicSurveyInfo = surveyModifyService.selectbasicSurveyInfo(survey_id_num);
		
		//보기  정보  받아오기
		multipleChoice = surveyModifyService.selectMultipleChoice(survey_id_num);
		
		//보기 번호별 정보 받아오기
		choiceInfo = surveyModifyService.selectChoiceInfo(survey_id_num);
		
		//표형문항의 질문정보 받아오기
		matrixQuestion = surveyModifyService.selectMatrixQuestion(survey_id_num);
		
		//표형문항의 보기정보 받아오기
		matrixChoice = surveyModifyService.selectMatrixChoice(survey_id_num);
		
		//마지막 페이지 번호 가져오기
		int maxPageNum = userService.maxPageNum(survey_id_num);
				
		//문항 번호별 문항정보
		List<QuestionInfoVO> questionInfo = new ArrayList<QuestionInfoVO>();		
			
		//문항 번호별 문항정보(모든질문정보)
		questionInfo = surveyModifyService.selectQuestionInfo(survey_id_num);	
		
		//받아온 문항정보 ToString으로 형변환 후 라스트에 다시 담기 / 형변환을 안하면 객체의 값이 아닌 객체가 바라보는 주소값이 넘어감
		List<Object> QuestionInfo = new ArrayList<Object>();
		for(int i = 0;i<questionInfo.size();i++) {
			QuestionInfoVO Question = new QuestionInfoVO();
			Question = questionInfo.get(i);
			Question.toString();
			QuestionInfo.add(Question);
		}
		//보기정보 ToString
		List<Object> multipleChoiceInfo = new ArrayList<Object>();
		for(int i = 0;i<multipleChoice.size();i++) {
			MultipleChoiceVO multiplechoice = new MultipleChoiceVO();
			multiplechoice = multipleChoice.get(i);
			multiplechoice.toString();
			multipleChoiceInfo.add(multiplechoice);
		}
		//보기번호별 정보 ToString
		List<Object> ChoiceInfo = new ArrayList<Object>();
		for(int i = 0;i<choiceInfo.size();i++) {
			ChoiceInfoVO choiceinfo = new ChoiceInfoVO();
			choiceinfo = choiceInfo.get(i);
			choiceinfo.toString();
			ChoiceInfo.add(choiceinfo);
		}
		//배열문항 질문정보 ToString
		List<Object> MatrixQuestion = new ArrayList<Object>();
		for(int i = 0;i<matrixQuestion.size();i++) {
			MatrixQuestionVO matrixquestion = new MatrixQuestionVO();
			matrixquestion = matrixQuestion.get(i);
			matrixquestion.toString();
			MatrixQuestion.add(matrixquestion);
		}
		//배열문항 보기정보 ToString
		List<Object> MatrixChoice = new ArrayList<Object>();
		for(int i = 0;i<matrixChoice.size();i++) {
			MatrixChoiceVO matrixchoice = new MatrixChoiceVO();
			matrixchoice = matrixChoice.get(i);
			matrixchoice.toString();
			MatrixChoice.add(matrixchoice);
		}
		
		System.out.println(basicSurveyInfo);
		System.out.println(basicSurveyInfo);
		System.out.println(basicSurveyInfo);
		System.out.println(basicSurveyInfo);
		System.out.println(basicSurveyInfo);
		System.out.println(basicSurveyInfo);
		
		

		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView();
		mav.setViewName(viewName);
		mav.addObject("basicSurveyInfo",basicSurveyInfo);
		mav.addObject("maxPageNum",maxPageNum);
		mav.addObject("QuestionInfo",QuestionInfo);
		mav.addObject("multipleChoiceInfo",multipleChoiceInfo);
		mav.addObject("ChoiceInfo",ChoiceInfo);
		mav.addObject("MatrixQuestion",MatrixQuestion);
		mav.addObject("MatrixChoice",MatrixChoice);
		return mav;
	}
	
	//설문 삭제 후 다시 저장하기
		//설문업데이트
		@Override
		@RequestMapping(value = { "survey_modify_update.do" }, method = { RequestMethod.GET, RequestMethod.POST })
		public ModelAndView main(RedirectAttributes rAttr,
				HttpServletRequest request, HttpServletResponse response) throws Exception {
			ModelAndView mav = new ModelAndView();
			mav.setViewName("redirect:/admin_survey_send.do");
			return mav;
		
		}



}
