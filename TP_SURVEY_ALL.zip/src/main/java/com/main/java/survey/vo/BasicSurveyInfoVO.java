package com.main.java.survey.vo;

import java.sql.Date;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Component("basicSurveyInfoVO")
public class BasicSurveyInfoVO
{
    // DB 관련 변수 1
    private String survey_id_num;           // 설문 식별번호
    private String survey_type;             // 설문 유형
    private String admin_title;             // 관리용 제목
    private Date survey_start_date;         // 설문 시작 일자
    private Date survey_end_date;           // 설문 마감 일자
    private String admin_id;                // 등록자 아이디
    private String title_input;             // 제목입력
    private String survey_notice;           // 설문안내문
    private String attached_image;          // 설문 안내문의 첨부 이미지
    private String survey_end_notice;       // 설문 종료문
    private Date survey_creation_date;      // 설문 생성 일자
    private Date last_modify_date;          // 최종 수정 일자
    private String is_last_modify;          // 최신 수정 여부
    
    
    //2022-10-02(수) 20시 추가된 변수
    
    
    /* 2022-10-20(목) 아침회의에서 반영된 변수 */
    private String survey_start_hour;       // 설문 종료문
    private String survey_start_minute;     // 설문 종료문
    private String survey_end_hour;       	// 설문 종료문
    private String survey_end_minute;       // 설문 종료문
    
    
    private String consent_procedure_count; // 동의절차 개수
    private String consent_notice_1;        // 동의절차 안내문 1
    private String consent_notice_2;        // 동의절차 안내문 2
    
    // DB 관련 변수 2
    private String is_limit_respondent;     // 응답자 제한 여부
    private String limit_respondent_num;    // 응답자 제한 수
    
    // 페이징 관련 변수
    private int startrow; // 시작행 번호
    private int endrow;   // 끝행 번호
    
    // 검색어와 검색 필드 관련 변수
    private String find_field; // 검색 필드
    private String find_title; // 검색어
    
    
    //설문 상태 조회용 마감일자 변수
	private Date survey_end_date_r; //설문 마감 일자+1
	
	//엑셀 리스트 다운로드용 응답자 수
	private int responseCount;
    
    public BasicSurveyInfoVO()  { }
}
