package com.main.java.survey.controller;

import java.sql.Timestamp;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.main.java.survey.service.SurveyService;

import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.AddressEmailVO;
import com.main.java.survey.vo.AddressInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.ChoiceInfoVO;
import com.main.java.survey.vo.IdCertificationVO;
import com.main.java.survey.vo.ChoiceInfoVO;
import com.main.java.survey.vo.MatrixChoiceVO;
import com.main.java.survey.vo.MatrixQuestionVO;
import com.main.java.survey.vo.MultipleChoiceVO;
import com.main.java.survey.vo.QuestionInfoVO;
import com.main.java.survey.vo.SubjectiveChoiceVO;

@Controller("SurveyController")
public class SurveyControllerImpl implements SurveyController {
	@Autowired
	private SurveyService surveyService;
	@Autowired
	AddInfoCollectVO addInfoCollect;
	@Autowired
	AddSurveyInfoVO addSurveyInfo;
	@Autowired
	BasicSurveyInfoVO basicSurveyInfo;
	@Autowired
	IdCertificationVO idCertification;
	@Autowired
	ChoiceInfoVO choiceInfo;
	@Autowired
	MatrixChoiceVO matrixChoice;
	@Autowired
	MatrixQuestionVO matrixQuestion;
	@Autowired
	MultipleChoiceVO multipleChoice;
	@Autowired
	QuestionInfoVO questionInfo;
	@Autowired
	SubjectiveChoiceVO subjectiveChoice;
	@Autowired
	AddressInfoVO addressInfoVO;
	@Autowired
	AddressEmailVO addressEmailVO;
	
	
	
	
	
	//설문 정보 및 옵션 설정 페이지
	@Override
	@RequestMapping(value = "/survey_info_and_option.do", method = RequestMethod.GET)
	public ModelAndView survey_info_and_option(HttpServletRequest request, HttpServletResponse response) {
		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView();
		mav.setViewName(viewName);
		return mav;
	}
	
	//설문 만들기 클릭
	@Override
	@RequestMapping(value = "/surveymake.do", method = RequestMethod.GET)
	public ModelAndView surveymake(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:/survey_info_and_option.do");
		return mav;
		
	}
	
	//설문 정보 및 옵션 설정 페이지에서 다음버튼 누르기
	@Override
	@RequestMapping(value = "/next_survey_info_and_option.do", method = RequestMethod.GET)
	public ModelAndView next_survey_info_and_option (HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException
	{
		// <인코딩 방식 처리>
		request.setCharacterEncoding("utf-8");
		
		HttpSession surveyNew = request.getSession(); // 기존세션에 추가(세션이 없다면 세션 생성)
		
		//VO객체생성
		BasicSurveyInfoVO basicSurveyInfo = new BasicSurveyInfoVO();
		AddSurveyInfoVO addSurveyInfo = new AddSurveyInfoVO();
		
		// 설문관리제목
		basicSurveyInfo.setAdmin_title(request.getParameter("admin_title")); //파라미터로 값 받아오기
		
		// 시작날짜 종료날짜 sqlDate로 형변환
		String surveyStartDate = request.getParameter("survey_start_date");
		String surveyEndDate = request.getParameter("survey_end_date");
		java.sql.Date survey_start_date = java.sql.Date.valueOf(surveyStartDate);
		java.sql.Date survey_end_date = java.sql.Date.valueOf(surveyEndDate);
		
		//시작날짜 종료날짜 객체저장
		basicSurveyInfo.setSurvey_start_date(survey_start_date);
		basicSurveyInfo.setSurvey_end_date(survey_end_date);
		
		//설문 시작 시간/분 객체저장
		basicSurveyInfo.setSurvey_start_hour(request.getParameter("startHour"));
		basicSurveyInfo.setSurvey_start_minute(request.getParameter("startMinute"));
		
		//설문 종료 시간/분 객체저장
		basicSurveyInfo.setSurvey_end_hour(request.getParameter("endHour"));
		basicSurveyInfo.setSurvey_end_minute(request.getParameter("endMinute"));
		
		//응답자 제한 여부
		basicSurveyInfo.setIs_limit_respondent(request.getParameter("isLimit"));
		
		// 응답자 제한 여부
		basicSurveyInfo.setIs_limit_respondent(request.getParameter("is_limit_respondent"));
		
		// 응답자 제한 수
		basicSurveyInfo.setLimit_respondent_num(request.getParameter("limit_respondent_num"));
		
		// 본인확인여부
		addSurveyInfo.setIs_certify_id(request.getParameter("is_certify_id"));
		
		//세션에 객체추가(설문 기본정보)
		surveyNew.setAttribute("basicSurveyInfo", basicSurveyInfo);
		surveyNew.setAttribute("addSurveyInfo", addSurveyInfo);
		
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:/survey_new_compo.do"); //리다이렉트로 /SurveyQuestionCompo.do 실행
		return mav;
	}
	
	//설문 기본정보 페이지
	@Override
	@RequestMapping(value = "/survey_new_compo.do", method = RequestMethod.GET)
	public ModelAndView SurveyBasicComposition(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession surveyNew = request.getSession(); // 기존세션에 추가(세션이 없다면 세션 생성)
		
		String survey_id_num = String.valueOf(surveyNew.getAttribute("survey_id_num"));
		
		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView();
		mav.addObject("survey_id_num", survey_id_num);
		mav.setViewName(viewName);
		return mav;
	}

	
	// 주소록 화면 접속
	@Override
    @RequestMapping(value = "/admin_survey_send.do", method = { RequestMethod.GET, RequestMethod.POST })
    public ModelAndView surveySendForm(@RequestParam(value = "survey_id_num", required = false) String survey_id_num,
            HttpServletRequest request, HttpServletResponse response) throws Exception {
        String viewName = (String) request.getAttribute("viewName");
        ModelAndView mav = new ModelAndView();
        mav.addObject("survey_id_num", survey_id_num);
        mav.setViewName(viewName);
        return mav;
    }
    
    //저장 버튼 - 주소록 저장 (기능)
    @Override
    @RequestMapping(value = "/survey_address_save.do", method = { RequestMethod.GET, RequestMethod.POST })
    @ResponseBody
    public Map<String, Integer> surveyAddressSave (@RequestParam Map<String, Object> parameters) throws Exception {
    	//받아온 JSON 파라미터를 받아옴
    	String userListJson = parameters.get("userList").toString();
    	ObjectMapper mapper = new ObjectMapper();
    	List<AddressInfoVO> userList = mapper.readValue(userListJson, new TypeReference<ArrayList<AddressInfoVO>>() {}); 
    	String emailInfoJson = parameters.get("emailInfo").toString();
    	AddressEmailVO emailInfo = mapper.readValue(emailInfoJson, new TypeReference<AddressEmailVO>() {});
    	String survey_id_num = (String) parameters.get("survey_id_num");
    	
    	int resultU = 0;
    	int resultE = 0;
    	
    	//주소록 테이블 리셋하고 수신자 리스트 정보를 저장
    	int deleteU = surveyService.deleteAddressInfo(survey_id_num);
    	for (int i=0; i<userList.size(); i++) {
    		AddressInfoVO vo = userList.get(i);
    		vo.setSurvey_id_num(survey_id_num);
    		resultU = surveyService.insertAddressInfo(vo);
    	}
    	//메일정보 테이블 리셋하고 메일 정보를 저장
    	int deleteE = surveyService.deleteAddressEmail(survey_id_num);
    	emailInfo.setSurvey_id_num(survey_id_num);
    	resultE = surveyService.insertAddressEmail(emailInfo);
    	
    	Map <String, Integer> resultMap = new HashMap();
    	resultMap.put("resultU", resultU);
    	resultMap.put("resultE", resultE);
    	return resultMap;
    }
    
    //완료 버튼 - 주소록 저장 및 메일 발신 (기능)
    @Override
    @RequestMapping(value = "/survey_send.do", method = { RequestMethod.GET, RequestMethod.POST })
    public ModelAndView surveySend(@RequestParam(value = "survey_id_num", required = false) String survey_id_num,
    		@ModelAttribute("AddressInfoList") AddressInfoVO AddressInfoList,
            @ModelAttribute("AddressEmail") AddressEmailVO AddressEmail,
            RedirectAttributes rAttr, HttpServletRequest request, HttpServletResponse response) throws Exception {
    	ModelAndView mav = new ModelAndView();
//    	HttpSession session = request.getSession();
    	
        //이 설문의 기본 정보 불러오기
    	BasicSurveyInfoVO surveyInfo = surveyService.surveyInfoView(survey_id_num);
    	//VO형태로 가져온 수신자 리스트(List<VO>형태) 꺼내기
    	List <AddressInfoVO> userList = AddressInfoList.getAddressInfoVOList();
    	
    	//주소록 테이블 리셋하고 수신자 리스트 정보를 저장
    	int deleteU = surveyService.deleteAddressInfo(survey_id_num);
    	for (int i=0; i<userList.size(); i++) {
    		AddressInfoVO vo = userList.get(i);
    		vo.setSurvey_id_num(survey_id_num);
    		int result = surveyService.insertAddressInfo(vo);
    	}
    	//메일정보 테이블 리셋하고 메일 정보를 저장
    	int deleteE = surveyService.deleteAddressEmail(survey_id_num);
    	AddressEmail.setSurvey_id_num(survey_id_num);
    	AddressEmail.setEmail_content(AddressEmail.getEmail_content().replace("\r\n", "<br>"));
    	int result = surveyService.insertAddressEmail(AddressEmail);

    	//수신자 리스트에 메일 발송
    	surveyService.surveySendMail(surveyInfo, userList, AddressEmail.getEmail_title(), AddressEmail.getEmail_content(), request);

    	//페이지 나가면서 세션에서 서베이 아이디 넘에 대한 정보도 삭제 (세션에 뭐 남아잇는지 보고 체크하기)
//    	session.removeAttribute(survey_id_num);
    	
    	rAttr.addAttribute("result", "mailSendingDone");
        mav.setViewName("redirect:/admin_list.do");
        return mav;
    }
	
	
}
