package com.main.java.survey.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.ChoiceInfoVO;
import com.main.java.survey.vo.MatrixChoiceVO;
import com.main.java.survey.vo.MatrixQuestionVO;
import com.main.java.survey.vo.MultipleChoiceVO;
import com.main.java.survey.vo.QuestionInfoVO;

public interface SurveyModifyDAO {

	BasicSurveyInfoVO selectbasicSurveyInfo(String survey_id_num) throws DataAccessException;
	
	AddSurveyInfoVO selectaddSurveyInfo(String survey_id_num) throws DataAccessException;
	
	List<QuestionInfoVO> selectQuestionInfo(String survey_id_num) throws DataAccessException;
	
	List<MultipleChoiceVO> selectMultipleChoice(String survey_id_num) throws DataAccessException;

	List<ChoiceInfoVO> selectChoiceInfo(String survey_id_num) throws DataAccessException;
	
	List<MatrixQuestionVO> selectMatrixQuestion(String survey_id_num) throws DataAccessException;
	
	List<MatrixChoiceVO> selectMatrixChoice(String survey_id_num) throws DataAccessException;

}
