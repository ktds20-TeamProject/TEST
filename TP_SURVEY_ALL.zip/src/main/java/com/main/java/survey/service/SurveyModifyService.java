package com.main.java.survey.service;

import org.springframework.dao.DataAccessException;

import java.util.List;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.ChoiceInfoVO;
import com.main.java.survey.vo.MatrixChoiceVO;
import com.main.java.survey.vo.MatrixQuestionVO;
import com.main.java.survey.vo.MultipleChoiceVO;
import com.main.java.survey.vo.QuestionInfoVO;

public interface SurveyModifyService {
	
	//설문정보 가져오기
	public BasicSurveyInfoVO selectbasicSurveyInfo(String survey_id_num) throws DataAccessException;
	
	//설문 추가정보 가져오기
	public AddSurveyInfoVO selectaddSurveyInfo(String survey_id_num) throws DataAccessException;
	
	//보기  정보  받아오기
	public  List<MultipleChoiceVO>  selectMultipleChoice(String survey_id_num) throws DataAccessException;
	
	//보기 번호별 정보 받아오기
	public  List<ChoiceInfoVO>  selectChoiceInfo(String survey_id_num) throws DataAccessException;
	
	//표형문항의 질문정보 받아오기
	public  List<MatrixQuestionVO>  selectMatrixQuestion(String survey_id_num) throws DataAccessException;
	
	//표형문항의 보기정보 받아오기
	public  List<MatrixChoiceVO>  selectMatrixChoice(String survey_id_num) throws DataAccessException;
	
	//모든 질문정보 가져오기
	public List<QuestionInfoVO> selectQuestionInfo(String survey_id_num) throws DataAccessException;
	
}
