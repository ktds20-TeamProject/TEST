package com.main.java.survey.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

public interface SurveyModifyConrtoller {
	
	//admin_list에서 수정버튼 클릭 > 수정페이지로이동
	public ModelAndView survey_modify_option(String survey_id_num, HttpServletRequest request,
	HttpServletResponse response)throws Exception;
	
	//설문 정보 및 옵션 설정 수정페이지에서 다음버튼 누르기
	public ModelAndView next_survey_modify_option(HttpServletRequest request, HttpServletResponse response);
	
	//설문 문항작성 수정페이지 이동
	public ModelAndView survey_modify_compo(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	public ModelAndView main(RedirectAttributes rAttr,
			HttpServletRequest request, HttpServletResponse response) throws Exception;
}
