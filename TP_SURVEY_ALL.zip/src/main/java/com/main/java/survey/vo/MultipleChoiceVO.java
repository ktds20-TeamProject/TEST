package com.main.java.survey.vo;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component("multipleChoiceVO")
public class MultipleChoiceVO {//객관식 보기
	
	private String survey_id_num; //설문 식별번호
	private String question_id_num; //질문식별번호
	private String choice_type; //보기유형
	private String choice_count; //보기갯수
	private String is_other_choice; //기타응답 여부
	private String min_multiple_choice; //객관식 최소답변 수 
	private String max_multiple_choice; //객관식 최대답변 수
	private String page_num; //페이지번호
}
