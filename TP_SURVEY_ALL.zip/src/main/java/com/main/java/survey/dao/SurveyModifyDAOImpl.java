package com.main.java.survey.dao;

import org.springframework.dao.DataAccessException;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.ChoiceInfoVO;
import com.main.java.survey.vo.MatrixChoiceVO;
import com.main.java.survey.vo.MatrixQuestionVO;
import com.main.java.survey.vo.MultipleChoiceVO;
import com.main.java.survey.vo.QuestionInfoVO;

@Repository("SurveyModifyDAO")
public class SurveyModifyDAOImpl implements SurveyModifyDAO{
	
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public BasicSurveyInfoVO selectbasicSurveyInfo(String survey_id_num) throws DataAccessException {
		BasicSurveyInfoVO selectbasicSurveyInfo = sqlSession.selectOne("mapper.survey.SurveyModify.selectbasicSurveyInfo",survey_id_num);
		return selectbasicSurveyInfo;
		
	}

	@Override
	public AddSurveyInfoVO selectaddSurveyInfo(String survey_id_num) throws DataAccessException {
		AddSurveyInfoVO selectaddSurveyInfo = sqlSession.selectOne("mapper.survey.SurveyModify.selectaddSurveyInfo",survey_id_num);
		return selectaddSurveyInfo;
	}
	
	
	@Override
	public List<QuestionInfoVO> selectQuestionInfo(String survey_id_num) throws DataAccessException {
		List<QuestionInfoVO> selectQuestionInfo = sqlSession.selectList("mapper.survey.SurveyModify.selectQuestionInfo",survey_id_num);
		return selectQuestionInfo;
	}

	@Override
	public List<MultipleChoiceVO> selectMultipleChoice(String survey_id_num) throws DataAccessException {
		List<MultipleChoiceVO> selectMultipleChoice = sqlSession.selectList("mapper.survey.SurveyModify.selectMultipleChoice",survey_id_num);
		return selectMultipleChoice;
	}

	@Override
	public List<ChoiceInfoVO> selectChoiceInfo(String survey_id_num) throws DataAccessException {
		List<ChoiceInfoVO> selectChoiceInfo = sqlSession.selectList("mapper.survey.SurveyModify.selectChoiceInfo",survey_id_num);
		return selectChoiceInfo;
	}

	@Override
	public List<MatrixQuestionVO> selectMatrixQuestion(String survey_id_num) throws DataAccessException {
		List<MatrixQuestionVO> selectMatrixQuestion  = sqlSession.selectList("mapper.survey.SurveyModify.selectMatrixQuestion",survey_id_num);
		return selectMatrixQuestion;
	}

	@Override
	public List<MatrixChoiceVO> selectMatrixChoice(String survey_id_num) throws DataAccessException {
		List<MatrixChoiceVO> selectMatrixChoice = sqlSession.selectList("mapper.survey.SurveyModify.selectMatrixChoice",survey_id_num);
		return selectMatrixChoice;
	}

}
