package com.main.java.survey.service;

import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.main.java.survey.vo.ChoiceInfoVO;
import com.main.java.survey.vo.MatrixChoiceVO;
import com.main.java.survey.vo.MatrixQuestionVO;
import com.main.java.survey.vo.MultipleChoiceVO;
import com.main.java.survey.vo.QuestionInfoVO;
import com.main.java.survey.vo.SubjectiveChoiceVO;
import com.main.java.survey.dao.SurveyDAO;
import com.main.java.survey.vo.AddInfoCollectVO;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.AddressEmailVO;
import com.main.java.survey.vo.AddressInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.survey.vo.ChoiceInfoVO;
import com.main.java.survey.vo.IdCertificationVO;
import com.main.java.survey.vo.MatrixChoiceVO;
import com.main.java.survey.vo.MatrixQuestionVO;
import com.main.java.survey.vo.MultipleChoiceVO;
import com.main.java.survey.vo.QuestionInfoVO;
import com.main.java.survey.vo.SubjectiveChoiceVO;



@Service("surveyService")
@Transactional(propagation = Propagation.REQUIRED)
public class SurveyServiceImpl implements  SurveyService{
	
	@Autowired
	private SurveyDAO surveyDAO;
	
	@Autowired
	private JavaMailSender mailSender;	
	
	@Override
	public int addAddInfoCollect(AddInfoCollectVO addInfoCollect) throws DataAccessException {
		return surveyDAO.insertAddInfoCollect(addInfoCollect);
	}


	@Override
	public int addAddSurveyInfo(AddSurveyInfoVO addSurveyInfo) throws DataAccessException {
		return surveyDAO.insertAddSurveyInfo(addSurveyInfo);
	}


	@Override
	public int addBasicSurveyInfo(BasicSurveyInfoVO basicSurveyInfo) throws DataAccessException {
		
		return surveyDAO.insertBasicSurveyInfo(basicSurveyInfo);
	}


	@Override
	public int addIdCertification(IdCertificationVO idCertification) throws DataAccessException {
		return surveyDAO.insertIdCertification(idCertification);
	}


	@Override
	public int addChoiceInfo(ChoiceInfoVO choiceInfo) throws DataAccessException {
		return surveyDAO.insertChoiceInfo(choiceInfo);
	}


	@Override
	public int addMatrixChoice(MatrixChoiceVO matrixChoice) throws DataAccessException {
		return surveyDAO.insertMatrixChoice(matrixChoice);
	}


	@Override
	public int addMatrixQuestion(MatrixQuestionVO matrixQuestion) throws DataAccessException {
		return surveyDAO.insertMatrixQuestion(matrixQuestion);
	}


	@Override
	public int addMultipleChoice(MultipleChoiceVO ultipleChoice) throws DataAccessException {
		return surveyDAO.insertMultipleChoice(ultipleChoice);
	}


	@Override
	public int addQuestionInfo(QuestionInfoVO questionInfo) throws DataAccessException {
		return surveyDAO.insertQuestionInfo(questionInfo);
	}


	@Override
	public int addSubjectiveChoice(SubjectiveChoiceVO subjectiveChoice) throws DataAccessException {
		return surveyDAO.insertSubjectiveChoice(subjectiveChoice);
	}

	//최신에 작성된 문서번호(Max survey num)
	@Override
	public int selectLastsurveyNum(BasicSurveyInfoVO basicSurveyInfo) throws DataAccessException {
		return surveyDAO.selectLastSurveyNum(basicSurveyInfo);
	}
	
	
	
	
	
	
	
	
	//(임시작성) 설문 메일 발송
    //설문 내용에 바인딩할 설문 정보(제목, 설문번호 등 필요), 수신자 정보(이름, 이메일) 파라미터로 받아옴
	//메일 제목과 내용 받아옴
    @Override
	public void surveySendMail(BasicSurveyInfoVO vo, List<AddressInfoVO> userList, String email_title, String email_content,
			HttpServletRequest request) throws Exception {
		//메일 발송시 사용할 설문 정보 불러오기
        String surveyTitle = vo.getTitle_input();
        String surveyNum = vo.getSurvey_id_num();
        //입력된 메일 제목과 내용을 ***기준으로 배열로 변경
        String[] email_titleArr = email_title.split("\\*\\*\\*");
        String[] email_contentArr = email_content.split("\\*\\*\\*");
        //메일내용 전환에 사용할 ArrayList 선언, 값 삽입
        List<String> email_titleArr2 = new ArrayList<>();
        for(int i=0; i<email_titleArr.length; i++) {
        	email_titleArr2.add(email_titleArr[i]);
		}
        List<String> email_contentArr2 = new ArrayList<>();
        for(int i=0; i<email_contentArr.length; i++) {
        	email_contentArr2.add(email_contentArr[i]);
		}

        MimeMessage mail = mailSender.createMimeMessage();
        //수신자 수 만큼 for문 반복
        for (int i=0; i<userList.size(); i++) {
            //메일 발송시 사용할 개인정보 불러오기
            //List<vo>구조라는 가정 하에 작성되었으며 변수명 또한 임의지정됨 (수정예정)
            String name = userList.get(i).getAddress_name();
            String email = userList.get(i).getAddress_email();
            
            //메일 제목/내용 ArrayList에서 대치할 부분들을 대치하고 다시 String으로 전환
            if (email_contentArr.length>1) {
    			for(int j=1; j<email_contentArr.length; j=j+2) {
    				if (email_contentArr2.get(j).equalsIgnoreCase("name")) {
    					email_contentArr2.remove(j);
    					email_contentArr2.add(j,name);
    				} else if (email_contentArr2.get(j).equalsIgnoreCase("surveyTitle")) {
    					email_contentArr2.remove(j);
    					email_contentArr2.add(j,surveyTitle);
    				}
    			}
    		}
            if (email_titleArr.length>1) {
    			for(int j=1; j<email_titleArr.length; j=j+2) {
    				if (email_titleArr2.get(j).equalsIgnoreCase("name")) {
    					email_titleArr2.remove(j);
    					email_titleArr2.add(j,name);
    				} else if (email_contentArr2.get(j).equalsIgnoreCase("surveyTitle")) {
    					email_titleArr2.remove(j);
    					email_titleArr2.add(j,surveyTitle);
    				}
    			}
    		}
            String email_titleRe = "";
            for (String item : email_titleArr2) {
            	email_titleRe += item;
            }
            String email_contentRe = "";
            for (String item : email_contentArr2) {
            	email_contentRe += item;
            }
            
            //템플릿과 합친 메일 내용 작성
            String htmlStr = "<div style='text-align:center;'><div style='display:inline-block; padding:0.5em; height:6.5em; width:80%; background-color:#352f66; '><p style='margin-top:0.6em; margin-bottom:0.6em; color:white;font-size:1.5em; text-align:center; font-weight: bold'>[보고 정보 시스템] </p><p style='color:white; text-align:center; font-size:1em;'>설문조사 참여 알림 메일</p></div></div>"
                    +"<div style='text-align:center;'><div style='display:inline-block; padding:0.6em; width:80%;'>"
                    +"<table style='margin-top:3em; width:100%; border-left:#aaaaaa solid 1px; border-right:#aaaaaa solid 1px; text-align:start; margin-bottom:3em;'>"
                    +"<tr><td style='font-weight:bold; font-size:1.2em; padding-left:1em;'>"
                    +"안녕하세요, "+name+"님</td></tr><tr><td style='padding-top:1.6em; padding-left:1em; font-size:1em;'>"
                    +email_contentRe
                    +"</td></tr></table><a href=\""
                    +"http://localhost:8090/agree_terms.do?survey_id_num="+surveyNum
                    +"\"><p style='text-align:center; height:2.5em; width:15em; padding:1em 0 0 0; margin:auto; background-color:#352f66; font-weight:bold; color:rgb(255, 255, 123); font-size:1em; border-radius: 1em; text-decoration:none;'>설문조사 바로가기</p></a></div></div>";
           
            //메일 정보 바인딩해 발송
            try {
                mail.setSubject(email_titleRe, "utf-8");
                mail.setText(htmlStr, "utf-8", "html");
                mail.addRecipient(RecipientType.TO, new InternetAddress(email));
                mailSender.send(mail);
            } catch (MessagingException e) {
                e.printStackTrace();
            }
        }
    }
    
    //설문 기본 정보 조회
    @Override
	public BasicSurveyInfoVO surveyInfoView(String survey_id_num) throws Exception {
		return surveyDAO.surveyInfoView(survey_id_num);
	}
    
    //주소록 기존 데이터 삭제
    @Override
    public int deleteAddressInfo (String survey_id_num) throws DataAccessException {
    	return surveyDAO.deleteAddressInfo (survey_id_num);
    }
    
    //주소록 데이터 삽입
    @Override
    public int insertAddressInfo (AddressInfoVO vo) throws DataAccessException {
    	return surveyDAO.insertAddressInfo(vo);
    }
    
  //주소록 기존 데이터 삭제
    @Override
    public int deleteAddressEmail (String survey_id_num) throws DataAccessException {
    	return surveyDAO.deleteAddressEmail  (survey_id_num);
    }
    
    //이메일 데이터 삽입
    @Override
    public int insertAddressEmail (AddressEmailVO vo) throws DataAccessException {
    	return surveyDAO.insertAddressEmail(vo);
    }
	
	
	
	
	
	
	
	
	
}
