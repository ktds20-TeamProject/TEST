package com.main.java.excelDown.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.main.java.admin.service.AdminService;
import com.main.java.composition.vo.TotalChoiceInfoVO;
import com.main.java.composition.vo.TotalQuestionInfoVO;
import com.main.java.excelDown.service.ExcelDownService;
import com.main.java.survey.vo.AddSurveyInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.userResponse.vo.TotalUserSurveyVO;
import com.main.java.userResponse.vo.UserVO;

@Controller("ExcelDownController")
public class ExcelDownControllerImpl implements ExcelDownController {

	@Autowired
	private ExcelDownService excelDownService;
	@Autowired
	private AdminService adminService;
	@Autowired // 의존성 주입
	BasicSurveyInfoVO basicSurveyInfoVO;
	@Autowired
	TotalQuestionInfoVO totalQuestionInfoVO;
//	@Autowired
//	TotalChoiceInfoVO totalChoiceInfoVO;
	@Autowired
	AddSurveyInfoVO addSurveyInfoVO;
	@Autowired
	TotalUserSurveyVO totalUserSurveyVO;
	@Autowired
	UserVO userVO;

	// 파일 경로 및 이름 지정
	public static String filePath = "C:\\Users\\User\\Downloads";
	public String fileName = "";

	@Override
	@RequestMapping(value = "/excelDown1.do", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView excel_down(@ModelAttribute("ExcelVO") BasicSurveyInfoVO basicSurveyInfoVO,
			HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		Date date = new Date();
		SimpleDateFormat format = new SimpleDateFormat("yyMMddhhmm");
		String dateStr = format.format(date);
		String fileName = "SurveyList_Excel_"+dateStr+".xlsx";

		// Workbook(엑셀) 및 시트 생성
		// Workbook wb = new HSSFWorkbook();
		Workbook wb = new XSSFWorkbook();
		Sheet sheet = wb.createSheet("응답결과");

		// 행, 셀 생성
		Row row = null;
		Cell cell = null;
		int rowNo = 0;

		// 게시판 목록조회
		List<BasicSurveyInfoVO> rowList = new ArrayList<BasicSurveyInfoVO>();
		rowList = excelDownService.selectAllResult();
		// 응답자 목록조회
		for (int i=0; i<rowList.size(); i++) {
			int count = excelDownService.count(i+1);
			rowList.get(i).setResponseCount(count);
		}

		System.out.println("나와라요 : " + rowList);
		// 셀 넓이 설정
		sheet.setDefaultColumnWidth(5); // sheet 전체 기본 넓이
		sheet.setColumnWidth(1, 15000); // 특정 셀 넓이 설정 => 1=B cell 2100=7.63
		sheet.setColumnWidth(2, 7000); // 7=H 3400=12.63
		sheet.setColumnWidth(3, 3500);
		sheet.setColumnWidth(4, 3000);

		// 폰트 설정
		Font headFont = wb.createFont();
		headFont.setFontName("Arial"); // 글꼴
		headFont.setFontHeight((short) 260); // 글자 크기 -> 260 = 13point
		headFont.setBold(true); // 두껍게

		Font bodyFont = wb.createFont();
		bodyFont.setFontName("Arial"); // 글꼴
		bodyFont.setFontHeight((short) 220); // 글자 크기 -> 260 = 13point
		bodyFont.setBold(false); // 두껍게

		// 테이블 헤더용 스타일
		CellStyle headStyle = wb.createCellStyle();
		// 가는 경계선 지정
		headStyle.setBorderTop(BorderStyle.THIN);
		headStyle.setBorderBottom(BorderStyle.THIN);
		headStyle.setBorderLeft(BorderStyle.THIN);
		headStyle.setBorderRight(BorderStyle.THIN);
		// 배경색 지정 = 노란색
		headStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
		headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		headStyle.setAlignment(HorizontalAlignment.CENTER);
		headStyle.setFont(headFont); // 위에 선언한 폰트 적용

		// body 테두리 스타일 지정(BorderStyle.THIN = 가는선)
		CellStyle bodyStyle = wb.createCellStyle();
		bodyStyle.setBorderTop(BorderStyle.THIN);
		bodyStyle.setBorderBottom(BorderStyle.THIN);
		bodyStyle.setBorderLeft(BorderStyle.THIN);
		bodyStyle.setBorderRight(BorderStyle.THIN);
		bodyStyle.setAlignment(HorizontalAlignment.CENTER);
		headStyle.setFont(bodyFont); // 위에 선언한 폰트 적용
		// Header 생성
		row = (sheet).createRow(rowNo++);
		cell = row.createCell(0);
		cell.setCellStyle(headStyle);
		cell.setCellValue("번호");
		cell = row.createCell(1);
		cell.setCellStyle(headStyle);
		cell.setCellValue("제목");
		cell = row.createCell(2);
		cell.setCellStyle(headStyle);
		cell.setCellValue("진행기간");
		cell = row.createCell(3);
		cell.setCellStyle(headStyle);
		cell.setCellValue("작성자");
		cell = row.createCell(4);
		cell.setCellStyle(headStyle);
		cell.setCellValue("총 응답자 수");

		// Body 생성(행, 셀 적용)
		for (BasicSurveyInfoVO vo : rowList) {
			row = sheet.createRow(rowNo++);
			cell = row.createCell(0);
			cell.setCellValue(vo.getSurvey_id_num());
			cell.setCellStyle(bodyStyle);
			cell = row.createCell(1);
			cell.setCellValue(vo.getAdmin_title());
			cell.setCellStyle(bodyStyle);
			cell = row.createCell(2);
			cell.setCellValue(vo.getSurvey_start_date() + " ~ " + vo.getSurvey_end_date());
			cell.setCellStyle(bodyStyle);
			cell = row.createCell(3);
			cell.setCellValue(vo.getAdmin_id());
			cell.setCellStyle(bodyStyle);
			cell = row.createCell(4);
			cell.setCellValue(vo.getResponseCount());
			cell.setCellStyle(bodyStyle);
		}

		// 엑셀 파일 저장
		FileOutputStream out = new FileOutputStream(new File(filePath, fileName));
		wb.write(out);
		out.close();

		ModelAndView mav = new ModelAndView("redirect:/admin_list.do");
		System.out.println("엑셀1 저장 끝");
		return mav;
	}


//-------------------------------------------------------------------------------------------------	
//	 여기부터 엑셀다운2 시작

//	//@Override
//	@RequestMapping(value = "/excelDown2.do", method = { RequestMethod.GET, RequestMethod.POST })
//	public ModelAndView excel_down2(@ModelAttribute("ExcelVO2") BasicSurveyInfoVO basicSurveyInfoVO,
//			@RequestParam("survey_id_num") String survey_id_num, HttpServletRequest request,
//			HttpServletResponse response) throws Exception {
//		System.out.println("엑셀2 저장 시작");
//
//		Date date = new Date();
//		SimpleDateFormat format = new SimpleDateFormat("yyMMddhhmm");
//		String dateStr = format.format(date);
//		String fileName = "SurveyResult_Excel_"+dateStr+".xlsx";
//
//		// Workbook(엑셀) 및 시트 생성
//		Workbook wb = new XSSFWorkbook();
//		Sheet sheet1 = wb.createSheet("개요");
//		Sheet sheet2 = wb.createSheet("상세결과");
//		Sheet sheet3 = wb.createSheet("응답결과분석");
//
//		// 행, 셀 생성
//		Row row = null;
//		Cell cell = null;
//		int rowNo = 0;
//
//		Map<String, Object> paraMap = new HashMap();
//		paraMap.put("survey_id_num", survey_id_num);
//		Map<String, Object> uRMap = new HashMap();
//		uRMap.put("survey_id_num", survey_id_num);
//
//		// 게시판 목록조회
//		List<BasicSurveyInfoVO> rowList = new ArrayList<BasicSurveyInfoVO>();
//		rowList = excelDownService.selectAllResult(survey_id_num);
//		List<TotalQuestionInfoVO> lookupList = new ArrayList<TotalQuestionInfoVO>();
//		lookupList = excelDownService.lookupAllResult(survey_id_num);
////		List<TotalChoiceInfoVO> answerList = new ArrayList<TotalChoiceInfoVO>();
////		answerList = excelDownService.answerListAllResult(survey_id_num);
//		List<TotalUserSurveyVO> ttlUserSVList = new ArrayList<TotalUserSurveyVO>();
//		int Qcount = adminService.countQuestion(survey_id_num);
//		for (int i = 0; i < Qcount; i++) {
//			paraMap.put("question_id_num", i++);
//			ttlUserSVList = adminService.sResponseView(paraMap);
//		}
//		List<UserVO> userVOList = new ArrayList<UserVO>();
//		int UserResp = excelDownService.userRespondentContent(survey_id_num);
//		for (int i = 0; i < UserResp; i++) { 
//			uRMap.put("question_id_num", i++);
//			userVOList = excelDownService.무슨맵퍼id를적어야하냐(uRMap);
//		}
//		
//
//		
//		// 셀 넓이 설정
////		sheet1.setDefaultColumnWidth(4); // sheet 전체 기본 넓이
//		sheet1.setColumnWidth(0, 5500); // 특정 셀 넓이 설정 => 1=B cell 2100=7.63
//		sheet1.setColumnWidth(1, 5000); // 7=H 3400=12.63
//		sheet1.setColumnWidth(2, 5500);
//		sheet1.setColumnWidth(3, 5000);
//
//		sheet2.setColumnWidth(0, 8000); // 특정 셀 넓이 설정 => 1=B cell 2100=7.63
//		sheet2.setColumnWidth(1, 4000); // 7=H 3400=12.63
//		sheet2.setColumnWidth(2, 4000);
//
//		// 폰트 설정
//		Font mainTitleFont = wb.createFont();
//		mainTitleFont.setFontName("Arial"); // 글꼴
//		mainTitleFont.setFontHeight((short) 340); // 글자 크기(1point = 20)
//		mainTitleFont.setBold(true); // 두껍게
//
//		Font subTitleFont = wb.createFont();
//		subTitleFont.setFontName("Arial"); // 글꼴
//		subTitleFont.setFontHeight((short) 260); // 글자 크기(1point = 20)
//		subTitleFont.setBold(true); // 두껍게
//
//		Font headFont = wb.createFont();
//		headFont.setFontName("Arial");
//		headFont.setFontHeight((short) 220);
//		headFont.setBold(false);
//
//		Font bodyFont = wb.createFont();
//		bodyFont.setFontName("Arial");
//		bodyFont.setFontHeight((short) 220);
//		bodyFont.setBold(false);
//
//		Font timeFont = wb.createFont();
//		timeFont.setBold(true);
//
//		// 스타일 설정
//		CellStyle mainTitleStyle = wb.createCellStyle();
//		mainTitleStyle.setBorderTop(BorderStyle.THIN);
//		mainTitleStyle.setBorderBottom(BorderStyle.THIN);
//		mainTitleStyle.setBorderLeft(BorderStyle.THIN);
//		mainTitleStyle.setBorderRight(BorderStyle.THIN);
//		mainTitleStyle.setAlignment(HorizontalAlignment.CENTER);
//		mainTitleStyle.setFont(mainTitleFont);
//
//		CellStyle subTitleStyle = wb.createCellStyle();
//		subTitleStyle.setBorderTop(BorderStyle.THICK);
//		subTitleStyle.setBorderBottom(BorderStyle.THIN);
//		subTitleStyle.setBorderLeft(BorderStyle.THIN);
//		subTitleStyle.setBorderRight(BorderStyle.THIN);
//		subTitleStyle.setAlignment(HorizontalAlignment.LEFT);
//		subTitleStyle.setFont(subTitleFont);
//
//		CellStyle headStyle = wb.createCellStyle();
//		headStyle.setBorderTop(BorderStyle.THIN);
//		headStyle.setBorderBottom(BorderStyle.THIN);
//		headStyle.setBorderLeft(BorderStyle.THIN);
//		headStyle.setBorderRight(BorderStyle.THIN);
//		headStyle.setAlignment(HorizontalAlignment.LEFT);
//		headStyle.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
//		headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
//		headStyle.setFont(headFont);
//
//		CellStyle subHeadStyle = wb.createCellStyle();
//		subHeadStyle.setBorderTop(BorderStyle.THIN);
//		subHeadStyle.setBorderBottom(BorderStyle.THIN);
//		subHeadStyle.setBorderLeft(BorderStyle.THIN);
//		subHeadStyle.setBorderRight(BorderStyle.THIN);
//		subHeadStyle.setAlignment(HorizontalAlignment.LEFT);
//		subHeadStyle.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
//		subHeadStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
//		subHeadStyle.setFont(headFont);
//
//		CellStyle bodyStyle = wb.createCellStyle();
//		bodyStyle.setBorderTop(BorderStyle.THIN);
//		bodyStyle.setBorderBottom(BorderStyle.THIN);
//		bodyStyle.setBorderLeft(BorderStyle.THIN);
//		bodyStyle.setBorderRight(BorderStyle.THIN);
//		bodyStyle.setAlignment(HorizontalAlignment.LEFT);
//		bodyStyle.setFont(bodyFont);
//
//		CellStyle timeStyle = wb.createCellStyle();
//		timeStyle.setAlignment(HorizontalAlignment.RIGHT);
//		timeStyle.setVerticalAlignment(VerticalAlignment.CENTER);
//		timeStyle.setFont(timeFont);
//
//		// 첫번째 시트 시작 - 개요
//		row = sheet1.createRow(1);
//		for (int i = 0; i < 4; i++) {
//			cell = row.createCell(i);
//			cell.setCellValue(basicSurveyInfoVO.getAdmin_title());
//			cell.setCellStyle(mainTitleStyle);
//		}
//		sheet1.addMergedRegion(new CellRangeAddress(1, 1, 0, 3));
//
//		// 4번째 줄 다운 받은 시간 표시
//		row = sheet1.createRow(3);
//		cell = row.createCell(3);
//		cell.setCellStyle(timeStyle);
//		cell.setCellValue(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").format(LocalDateTime.now()));
//
//		for (BasicSurveyInfoVO vo : rowList) {
//			row = sheet1.createRow(4);
//			for (int i = 0; i < 4; i++) {
//				cell = row.createCell(i);
//				cell.setCellValue("◆ 기본 정보");
//				cell.setCellStyle(subTitleStyle);
//			}
//			sheet1.addMergedRegion(new CellRangeAddress(4, 4, 0, 3)); // 기본정보
//			row = sheet1.createRow(5);
//			cell = row.createCell(0);
//			cell.setCellValue("제목");
//			cell.setCellStyle(headStyle);
//			for (int i = 1; i < 4; i++) {
//				cell = row.createCell(i);
//				cell.setCellValue(vo.getAdmin_title());
//				cell.setCellStyle(bodyStyle);
//			}
//			sheet1.addMergedRegion(new CellRangeAddress(5, 5, 1, 3)); // 제목
//			row = sheet1.createRow(6);
//			cell = row.createCell(0);
//			cell.setCellValue("기간");
//			cell.setCellStyle(headStyle);
//			for (int i = 1; i < 4; i++) {
//				cell = row.createCell(i);
//				cell.setCellValue(vo.getSurvey_start_date() + " ~ " + vo.getSurvey_end_date());
//				cell.setCellStyle(bodyStyle);
//			}
//			sheet1.addMergedRegion(new CellRangeAddress(6, 6, 1, 3)); // 기간
//			row = sheet1.createRow(7);
//			cell = row.createCell(0);
//			cell.setCellValue("진행상태");
//			cell.setCellStyle(headStyle);
//			cell = row.createCell(1);
//			cell.setCellValue("종료"); // 머지 후 추가or삭제 예정
//			cell.setCellStyle(bodyStyle);
//			cell = row.createCell(2);
//			cell.setCellValue("익명응답");
//			cell.setCellStyle(headStyle);
//			cell = row.createCell(3);
//			cell.setCellValue("사용안함"); // 머지 후 추가할듯
//			cell.setCellStyle(bodyStyle);
//
//		}
//
//		// 10번째 줄부터 기본정보
//		for (TotalQuestionInfoVO vo : lookupList) {
//			row = sheet1.createRow(9);
//			for (int i = 0; i < 4; i++) {
//				cell = row.createCell(i);
//				cell.setCellValue("◆ 참여현황(전체)");
//				cell.setCellStyle(subTitleStyle);
//			}
//			sheet1.addMergedRegion(new CellRangeAddress(9, 9, 0, 3)); // 참여현황(전체)
//			row = sheet1.createRow(10);
//			cell = row.createCell(0);
//			cell.setCellValue("설문 응답자수(응답률)");
//			cell.setCellStyle(headStyle);
//			for (int i = 1; i < 4; i++) {
//				cell = row.createCell(i);
//				cell.setCellValue(vo.getCount() + ("0%")); // 퍼센트 VO연결 or 카운트값에 따라 계산 필요
//				cell.setCellStyle(bodyStyle);
//			}
//			sheet1.addMergedRegion(new CellRangeAddress(10, 10, 1, 3)); // 설문 응답자수(응답률)
//		} // 첫번째 시트 끝
//
//		// 두번째 시트 시작 - 전체 응답결과
//		row = sheet2.createRow(1);
//		cell = row.createCell(0);
//		cell.setCellValue("◆ 문항별 상세 결과");
//		cell.setCellStyle(mainTitleStyle);
//		sheet2.addMergedRegion(new CellRangeAddress(1, 1, 0, 2));
//
//		int i = 0; // for문 돌리는 횟수
//		int j = 3; // row(세로 셀)
//		int k = 0; // if문 내에 있는 for문에서 i역할
//		int l = 0; // 응답수, 응답률
//		int m = 0; // 응답 내용 호출
//
//		for (i = 0, j = 2, l = 0, m = 0; i < lookupList.size(); i++, l++, m++) {
//			j++;
//			TotalQuestionInfoVO lookupExList = lookupList.get(i); // 테이블 값 다음 행 출력
//			TotalUserSurveyVO lookupUSList = ttlUserSVList.get(l);
//			UserVO userList = userVOList.get(m);
//			if (lookupExList.getQuestion_type().equals("주관식")) {
//				row = sheet2.createRow(j);
//				for (int h = 0; h < 3; h++) {
//					cell = row.createCell(h);
//					cell.setCellValue(lookupExList.getQuestion_id_num() + ". " + lookupExList.getQuestion_contents());
//					cell.setCellStyle(headStyle);
//					sheet2.addMergedRegion(new CellRangeAddress(j, j, 0, 2));
//				}
//				j++;
//				row = sheet2.createRow(j);
//				for (int h = 0; h < 3; h++) {
//					cell = row.createCell(h);
//					cell.setCellValue("답변");
//					cell.setCellStyle(subHeadStyle);
//					sheet2.addMergedRegion(new CellRangeAddress(j, j, 0, 2));
//				}
//				j++;
//				// 주관식 답변들
//				row = sheet2.createRow(j);
//				for (int h = 0; h < 3; h++) {
//					cell = row.createCell(h);
//				cell.setCellValue(userList.getRespondent_subjective());
//					cell.setCellStyle(bodyStyle);
//					sheet2.addMergedRegion(new CellRangeAddress(j, j, 0, 2));
//				}
//			} else if (lookupExList.getQuestion_type().equals("객관식(RADIO)")) {
//				row = sheet2.createRow(j);
//				for (int h = 0; h < 3; h++) {
//					cell = row.createCell(h);
//					cell.setCellValue(lookupExList.getQuestion_id_num() + ". " + lookupExList.getQuestion_contents());
//					cell.setCellStyle(headStyle);
//					sheet2.addMergedRegion(new CellRangeAddress(j, j, 0, 2));
//				}
//				j++;
//				row = sheet2.createRow(j);
//				cell = row.createCell(0);
//				cell.setCellValue("보기");
//				cell.setCellStyle(subHeadStyle);
//				cell = row.createCell(1);
//				cell.setCellValue("응답자수(명)");
//				cell.setCellStyle(subHeadStyle);
//				cell = row.createCell(2);
//				cell.setCellValue("응답률(%)");
//				cell.setCellStyle(subHeadStyle);
//				for (k = 0; k < Integer.parseInt(lookupExList.getChoice_description()); k++, j++) {
//					row = sheet2.createRow(j);
//					cell = row.createCell(0);
//					cell.setCellValue((k + 1) + ". " + userList.getRespondent_multiple());
//					cell = row.createCell(1);
//					cell.setCellValue(lookupUSList.getMultiple_count());
//					cell.setCellStyle(bodyStyle);
//					cell = row.createCell(2);
//					cell.setCellValue(lookupUSList.getMultiple_percent());
//					cell.setCellStyle(bodyStyle);
//				}
//			} else if (lookupExList.getQuestion_type().equals("객관식(표형)")) {
//				row = sheet2.createRow(j);
//				for (int h = 0; h < 3; h++) {
//					cell = row.createCell(h);
//					cell.setCellValue(lookupExList.getQuestion_id_num() + ". " + lookupExList.getQuestion_contents());
//					cell.setCellStyle(headStyle);
//					sheet2.addMergedRegion(new CellRangeAddress(j, j, 0, 2));
//				}
//				j++;
//				row = sheet2.createRow(j);
//				cell = row.createCell(0);
//				cell.setCellValue("보기");
//				cell.setCellStyle(subHeadStyle);
//				cell = row.createCell(1);
//				cell.setCellValue("응답자수(명)");
//				cell.setCellStyle(subHeadStyle);
//				cell = row.createCell(2);
//				cell.setCellValue("응답률(%)");
//				cell.setCellStyle(subHeadStyle);
//				for (k = 0; k < Integer.parseInt(lookupExList.getChoice_description()); k++, j++) {
//					row = sheet2.createRow(j);
//					cell = row.createCell(0);
//					cell.setCellValue((k + 1) + ". " + userList.getMatrix_num());
//					cell.setCellStyle(bodyStyle);
//					cell = row.createCell(1);
//					cell.setCellValue(lookupUSList.getMatrix_count());
//					cell.setCellStyle(bodyStyle);
//					cell = row.createCell(2);
//					cell.setCellValue(lookupUSList.getMatrix_percent());
//					cell.setCellStyle(bodyStyle);
//				}
//			} else if (lookupExList.getQuestion_type().equals("객관식(드롭다운)")) {
//				row = sheet2.createRow(j);
//				for (int h = 0; h < 3; h++) {
//					cell = row.createCell(h);
//					cell.setCellValue(lookupExList.getQuestion_id_num() + ". " + lookupExList.getQuestion_contents());
//					cell.setCellStyle(headStyle);
//					sheet2.addMergedRegion(new CellRangeAddress(j, j, 0, 2));
//				}
//				j++;
//				row = sheet2.createRow(j);
//				cell = row.createCell(0);
//				cell.setCellValue("보기");
//				cell.setCellStyle(subHeadStyle);
//				cell = row.createCell(1);
//				cell.setCellValue("응답자수(명)");
//				cell.setCellStyle(subHeadStyle);
//				cell = row.createCell(2);
//				cell.setCellValue("응답률(%)");
//				cell.setCellStyle(subHeadStyle);
//				for (k = 0; k < Integer.parseInt(lookupExList.getChoice_description()); k++, j++) {
//					row = sheet2.createRow(j); // row
//					cell = row.createCell(0);
//					cell.setCellValue((k + 1) + ". " + userList.getRespondent_multiple());
//					cell.setCellStyle(bodyStyle);
//					cell = row.createCell(1);
//					cell.setCellValue(lookupUSList.getMultiple_count()); // 없음
//					cell.setCellStyle(bodyStyle);
//					cell = row.createCell(2);
//					cell.setCellValue(lookupUSList.getMultiple_percent()); // 없음
//					cell.setCellStyle(bodyStyle);
//				}
//			}
//		}
//
//		// 엑셀 파일 저장
//		FileOutputStream out = new FileOutputStream(new File(filePath, fileName));
//		wb.write(out);
//		out.close();
//
//		
//		ModelAndView mav = new ModelAndView("redirect:/survey_result_main.do");
//		System.out.println("엑셀2 저장 끝");
//		return mav;
//	}

}
