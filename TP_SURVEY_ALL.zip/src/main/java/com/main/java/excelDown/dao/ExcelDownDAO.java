package com.main.java.excelDown.dao;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import com.main.java.composition.vo.TotalChoiceInfoVO;
import com.main.java.composition.vo.TotalQuestionInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.userResponse.vo.TotalUserSurveyVO;
import com.main.java.userResponse.vo.UserVO;

public interface ExcelDownDAO {

	public List<BasicSurveyInfoVO> selectAllResult() throws DataAccessException;

	public List<TotalQuestionInfoVO> lookupAllResult(String survey_id_num) throws DataAccessException;

//	public List<TotalChoiceInfoVO> answerListAllResult(String survey_id_num) throws DataAccessException;

//	public List<UserVO> userVOListAllResult(String survey_id_num) throws DataAccessException;
	
	public int userRespondentContent(String survey_id_num) throws DataAccessException;
	
	public List 무슨맵퍼id를적어야하냐(Map uRMap) throws DataAccessException;
	
	public int count(int survey_id_num) throws DataAccessException;

	


}
