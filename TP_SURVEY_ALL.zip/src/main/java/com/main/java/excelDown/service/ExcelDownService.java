package com.main.java.excelDown.service;

import java.util.List;
import java.util.Map;

import com.main.java.composition.vo.TotalChoiceInfoVO;
import com.main.java.composition.vo.TotalQuestionInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.userResponse.vo.TotalUserSurveyVO;
import com.main.java.userResponse.vo.UserVO;

public interface ExcelDownService {

	public List<BasicSurveyInfoVO> selectAllResult() throws Exception;
	public List<TotalQuestionInfoVO> lookupAllResult(String survey_id_num) throws Exception;
//	public List<TotalChoiceInfoVO> answerListAllResult(String survey_id_num) throws Exception;
	public int userRespondentContent(String survey_id_num) throws Exception;
	public List<UserVO> 무슨맵퍼id를적어야하냐(Map uRMap) throws Exception;
	public int count(int survey_id_num) throws Exception;
	

}
