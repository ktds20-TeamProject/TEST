package com.main.java.excelDown.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.java.composition.vo.TotalChoiceInfoVO;
import com.main.java.composition.vo.TotalQuestionInfoVO;
import com.main.java.excelDown.dao.ExcelDownDAO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.userResponse.vo.TotalUserSurveyVO;
import com.main.java.userResponse.vo.UserVO;

@Service("excelDownService")
public class ExcelDownServiceImpl implements ExcelDownService {
	
	@Autowired
	private ExcelDownDAO excelDownDAO;
	
	@Override
	public List<BasicSurveyInfoVO> selectAllResult() throws Exception {
		List<BasicSurveyInfoVO> result = excelDownDAO.selectAllResult();
		System.out.println("asdfasdf : " + result);
		return result;
		
	}

	@Override
	public List<TotalQuestionInfoVO> lookupAllResult(String survey_id_num) throws Exception {
		List<TotalQuestionInfoVO> result = excelDownDAO.lookupAllResult(survey_id_num);
		return result;
	}

//	@Override
//	public List<TotalChoiceInfoVO> answerListAllResult(String survey_id_num) throws Exception {
//		List<TotalChoiceInfoVO> result = excelDownDAO.answerListAllResult(survey_id_num);
//		return result; 
//	}
	
	@Override
	public int userRespondentContent(String survey_id_num) throws Exception {
		return excelDownDAO.userRespondentContent(survey_id_num);
	}
	
	@Override
	public List<UserVO> 무슨맵퍼id를적어야하냐(Map uRMap) throws Exception {
		return excelDownDAO.무슨맵퍼id를적어야하냐(uRMap); 
	}
	
	
	@Override
	public int count(int survey_id_num) throws Exception {
		return excelDownDAO.count(survey_id_num);
	}
	
}
