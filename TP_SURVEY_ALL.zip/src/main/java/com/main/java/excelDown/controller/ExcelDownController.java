package com.main.java.excelDown.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.main.java.survey.vo.BasicSurveyInfoVO;

public interface ExcelDownController {
	 
	public ModelAndView excel_down(@ModelAttribute("ExcelVO") BasicSurveyInfoVO basicSurveyInfoVO, 
			
    		HttpServletRequest request, HttpServletResponse response) throws Exception;

//	public ModelAndView excel_down2(@ModelAttribute("ExcelVO2") BasicSurveyInfoVO basicSurveyInfoVO,
//			@RequestParam("survey_id_num")String survey_id_num,
//    		HttpServletRequest request, HttpServletResponse response) throws Exception;
}
