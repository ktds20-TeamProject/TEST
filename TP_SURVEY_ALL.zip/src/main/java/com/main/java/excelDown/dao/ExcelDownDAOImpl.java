package com.main.java.excelDown.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.main.java.composition.vo.TotalChoiceInfoVO;
import com.main.java.composition.vo.TotalQuestionInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.userResponse.vo.TotalUserSurveyVO;
import com.main.java.userResponse.vo.UserVO;

@Repository("excelDownDAO")
public class ExcelDownDAOImpl implements ExcelDownDAO {

	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public List<BasicSurveyInfoVO> selectAllResult() throws DataAccessException {
		List<BasicSurveyInfoVO> result = sqlSession.selectList("mapper.survey.ExcelDownloadList");
		System.out.println("ㅁㄴㅇㄻㄴㅇㅇㄹ : "+ result);
		return result;
	}

	@Override
	public List<TotalQuestionInfoVO> lookupAllResult(String survey_id_num) throws DataAccessException {
		List<TotalQuestionInfoVO> result = sqlSession.selectList("mapper.survey.questionInfoView", survey_id_num);
		return result;
	}

//	@Override
//	public List<TotalChoiceInfoVO> answerListAllResult(String survey_id_num) throws DataAccessException {
//		List<TotalChoiceInfoVO> result = sqlSession.selectList("mapper.survey.BasicSurveyInfo.가져올곳이한개가아닌데어쩌지", survey_id_num);
//		return result;
//	}

	@Override
	public int userRespondentContent(String survey_id_num) throws DataAccessException {
		int result = sqlSession.selectOne("mapper.survey.ttlUserRespondent", survey_id_num);
		return result;
	}
	
	@Override
	public List 무슨맵퍼id를적어야하냐(Map uRMap) throws DataAccessException {
		List<UserVO> result = sqlSession.selectList("mapper.survey.무슨맵퍼id를적어야하냐", uRMap);
		return result;
	}
	
	@Override
	public int count(int survey_id_num) throws DataAccessException {
		int result = sqlSession.selectOne("mapper.survey.count", survey_id_num);
		return result;
	}
	
}
