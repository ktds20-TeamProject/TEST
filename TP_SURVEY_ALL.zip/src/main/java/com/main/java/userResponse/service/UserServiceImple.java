package com.main.java.userResponse.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.main.java.composition.vo.TotalChoiceInfoVO;
import com.main.java.composition.vo.TotalQuestionInfoVO;
import com.main.java.survey.dao.SurveyDAO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.userResponse.dao.UserDAO;
import com.main.java.userResponse.vo.UserVO;

import org.springframework.stereotype.Service;


@Service("UserService")
public class UserServiceImple implements UserService{
	@Autowired
	private UserDAO userDAO;
	
	
	
	//유저 메인 리스트 가져오기
	@Override
	public List selectSurveyList(BasicSurveyInfoVO basicSurveyInfo) throws DataAccessException {
		List mainList = null;
		mainList = userDAO.selectSurveyList(basicSurveyInfo);
		System.out.println("service"+mainList);
		return mainList;
	}



	//유저 설문 동의문 가져오기
	@Override
	public BasicSurveyInfoVO selectagreement(String survey_id_num) throws DataAccessException {
		BasicSurveyInfoVO agreement = userDAO.selectagreement(survey_id_num);
		return agreement;
	}



	//문항 정보 가져오기
	@Override
	public List<TotalQuestionInfoVO> questionInfoView(Map paraMapquestionInfo) throws Exception {
		return userDAO.questionInfoView(paraMapquestionInfo);
	}

	
	//설문 총 질문갯수
		@Override
		public int totalQuestionNum(Map paraMapquestionInfo) throws Exception {
			return userDAO.totalQuestionNum(paraMapquestionInfo);
		}
	
	
	//해당페이지 질문갯수
	@Override
	public int countQuestion(Map paraMapquestionInfo) throws Exception {
		return userDAO.countQuestion(paraMapquestionInfo);
	}
	

	//객관식 보기 최대갯수
	@Override
	public int maxChoiceNum(String survey_id_num) throws Exception {
		
		return userDAO.maxChoiceNum(survey_id_num);
	}

	
	//표형 질문 최대갯수
	@Override
	public int maxMatrixQuestionNum(String survey_id_num) throws Exception {
		return userDAO.maxMatrixQuestionNum(survey_id_num);
	}


	//표형 보기 최대갯수
	@Override
	public int maxMatrixChoiceNum(String survey_id_num) throws Exception {
		return userDAO.maxMatrixChoiceNum(survey_id_num);
	}
	


	//표형문항 질문 정보
	@Override
	public List<TotalChoiceInfoVO> matrixTableQuestionInfoView(Map paraMap) throws Exception {
		return userDAO.matrixTableQuestionInfoView(paraMap);
	}



	//표형문항 답변 정보
	@Override
	public List<TotalChoiceInfoVO> matrixTableChoiceInfoView(Map paraMap) throws Exception {
		return userDAO.matrixTableChoiceInfoView(paraMap);
	}


	//마지막 페이지 번호
	@Override
	public int maxPageNum(String survey_id_num) throws Exception {
		return userDAO.maxPageNum(survey_id_num);
	}

	
	//해당페이지 첫 문항 번호
	@Override
	public int firstQuestionNumOfPage(Map paraMapquestionInfo) throws Exception {
		return userDAO.firstQuestionNumOfPage(paraMapquestionInfo);
	}

	@Override
	public int insertUserResponse(List surveyResponse) throws Exception {
		return userDAO.insertUserResponse(surveyResponse);
	}


	@Override
	public int selectUserNum(String survey_id_num) throws Exception {
		return userDAO.selectUserNum(survey_id_num);
	}



	@Override
	public String selectsurveyEndNotice(String survey_id_num) throws Exception {
		return userDAO.selectsurveyEndNotice(survey_id_num);
	}


}
