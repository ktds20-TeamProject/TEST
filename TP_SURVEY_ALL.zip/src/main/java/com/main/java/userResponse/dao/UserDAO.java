package com.main.java.userResponse.dao;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import com.main.java.survey.vo.BasicSurveyInfoVO;

public interface UserDAO {
	
	public List selectSurveyList(BasicSurveyInfoVO basicSurveyInfo) throws DataAccessException;
	
	public BasicSurveyInfoVO selectagreement(String survey_id_num) throws DataAccessException;
	
	public List questionInfoView(Map paraMapquestionInfo) throws DataAccessException;
	
	public int totalQuestionNum(Map paraMapquestionInfo) throws DataAccessException;
	
	public int countQuestion(Map paraMapquestionInfo) throws DataAccessException;
	
	public int maxChoiceNum(String survey_id_num) throws DataAccessException;
	
	public int maxMatrixQuestionNum(String survey_id_num) throws DataAccessException;
	
	public int maxMatrixChoiceNum(String survey_id_num) throws DataAccessException;
	
	public int firstQuestionNumOfPage(Map paraMapquestionInfo) throws DataAccessException;
	
	public List matrixTableQuestionInfoView(Map paraMap) throws DataAccessException;
	
	public List matrixTableChoiceInfoView(Map paraMap) throws DataAccessException;
	
	public int maxPageNum(String survey_id_num) throws DataAccessException;
	
	public int insertUserResponse(List surveyResponse) throws DataAccessException;
	
	public int selectUserNum(String survey_id_num) throws DataAccessException;

	public String selectsurveyEndNotice(String survey_id_num) throws DataAccessException;
}
