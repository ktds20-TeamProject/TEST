package com.main.java.userResponse.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.main.java.admin.service.AdminService;
import com.main.java.composition.vo.TotalChoiceInfoVO;
import com.main.java.composition.vo.TotalQuestionInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.userResponse.service.UserService;
import com.main.java.userResponse.vo.UserVO;

@Controller("UserController")
public class UserControllerImpl implements UserController {
	@Autowired
	private AdminService adminService;
	@Autowired
	private UserService userService;
	@Autowired
	BasicSurveyInfoVO basicSurveyInfo;
	@Autowired
	TotalQuestionInfoVO totalQuestionInfo;
	@Autowired
	UserVO userVO;
	
	//설문 리스트 유저화면
	@Override
	@RequestMapping(value = { "/", "/main.do" }, method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView main(HttpServletRequest request, HttpServletResponse response) {
		
		//질문 리스트 불러오기
		List surveyList = userService.selectSurveyList(basicSurveyInfo);
		
		
		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView();
		mav.setViewName(viewName);
		mav.addObject("surveyList", surveyList);
		return mav;
	}
	
	
	//설문 선택시 동의 화면
	@Override
	@RequestMapping(value = { "/agree_terms.do" }, method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView agree_terms(@RequestParam("survey_id_num") String survey_id_num, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		HttpSession userSession = request.getSession(true);
		
		//해당설문번호의 동의문 내용 불러오기
		BasicSurveyInfoVO basicSurveyInfo = userService.selectagreement(survey_id_num);
		
		//설문정보 세션에 저장
		userSession.setAttribute("basicSurveyInfo", basicSurveyInfo);
		
		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView();
		mav.setViewName(viewName);
		mav.addObject("survey_id_num", survey_id_num);
		mav.addObject("basicSurveyInfo", basicSurveyInfo);
		return mav;
	}

	
	//설문동의문의 동의 여부 저장 후 설문화면으로 넘기기
	@Override
	@RequestMapping(value = { "/agree_terms_next.do" }, method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView agree_terms_next(@RequestParam("survey_id_num") String survey_id_num, 
			@RequestParam("page_num") String page_num,HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		//동의문 동의 여부는 저장하지 않음 나중에 저장 하기로 하면 살리자
		/*
		//동의 확인 세션 저장
		HttpSession userSession = request.getSession(true);
		
		//동의문의 동의여부 파라미터 가져오기
		String agree1 = request.getParameter("agree1");
		String agree2 = request.getParameter("agree2");
		
		//동의여부 값이 null이 아니면 세션저장
		if(agree1 != null) {
			userSession.setAttribute("agree1", agree1);
		}
		//동의여부 동의 값이 null이 아니면 세션저장
		if(agree2 != null) {
			userSession.setAttribute("agree2", agree2);
		}
		*/
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:/response.do");
		mav.addObject("survey_id_num", survey_id_num);
		mav.addObject("page_num", page_num);
		return mav;
	}
	
	
	//설문화면 or 설문지 페이지 넘기기
	@Override
	@RequestMapping(value = { "/response.do" }, method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView response(@RequestParam("survey_id_num") String survey_id_num,
			@RequestParam("page_num") String page_num, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		String viewName = (String) request.getAttribute("viewName");

		//세션 받아오기
		HttpSession userSession = request.getSession(true);
		
		//설문정보 받아오기
		String basicSurveyInfo = request.getParameter("basicSurveyInfo");
		
		List<TotalQuestionInfoVO> questionInfo = new ArrayList<TotalQuestionInfoVO>();
		List<Object> choiceInfo = new ArrayList<Object>();

		// 문항정보 불러오기
		Map<String, Object> paraMapquestionInfo = new HashMap<String, Object>();
		paraMapquestionInfo.put("survey_id_num", survey_id_num);
		paraMapquestionInfo.put("page_num", page_num);
		questionInfo = userService.questionInfoView(paraMapquestionInfo);
		
		//설문 총 문항수 불러오기
		int totalQuestionNum = userService.totalQuestionNum(paraMapquestionInfo);
		
		// 해당페이지의 총 문항수 불러오기
		int countQuestion = userService.countQuestion(paraMapquestionInfo);
		
		// 모든 문항의 보기 갯수중 최댓값 불러오기
		int maxChoiceNum = userService.maxChoiceNum(survey_id_num);

		// 모든 표형문항의 질문 갯수 중 최댓값 불러오기
		int maxMatrixQuestionNum = userService.maxMatrixQuestionNum(survey_id_num);
		
		// 모든 표형문항의 보기 갯수 중 최댓값 불러오기
		int maxMatrixChoiceNum = userService.maxMatrixChoiceNum(survey_id_num);
		
		//설문의 마지막 페이지 번호 불러오기
		int maxPageNum = userService.maxPageNum(survey_id_num);
		
		//페이지의 첫문항 번호 ex) 1페이지는 1 고정 2페이지 6..3페이지 17....
		int firstQuestionNumOfPage = userService.firstQuestionNumOfPage(paraMapquestionInfo);
		
		//설문진행률( (100*(페이지 첫문항번호 -1)) / 총 문항 수 )
		int surveyProgress =((100*(firstQuestionNumOfPage-1))/totalQuestionNum);
		
		
		//세션에 설문지번호, 페이지번호, 마지막페이지번호 저장
		userSession.setAttribute("survey_id_num", survey_id_num);
		userSession.setAttribute("page_num", page_num);
		userSession.setAttribute("maxPageNum", maxPageNum);

		
		for (int i = 0; i < countQuestion; i++) {
			// 문항별 유형 불러오기
			String qustionType = questionInfo.get(i).getQuestion_type();

			// 쿼리문에 파라미터로 넘길 설문 번호/문항 번호
			Map<String, Object> paraMap = new HashMap<String, Object>();
			paraMap.put("survey_id_num", survey_id_num);
			paraMap.put("question_id_num",firstQuestionNumOfPage + i );

			
			// 문항이 객관식(객관식 기본 또는 드롭다운)일 경우
			if (qustionType.equalsIgnoreCase("multiple")||qustionType.equalsIgnoreCase("dropdown")) {
				TotalQuestionInfoVO choiceDefault = adminService.MqInfoView(paraMap);
				int choice_count = Integer.valueOf(choiceDefault.getChoice_count());
				questionInfo.get(i).setChoice_count(choice_count - 1);
				questionInfo.get(i).setMin_multiple_choice(choiceDefault.getMin_multiple_choice());
				questionInfo.get(i).setMax_multiple_choice(choiceDefault.getMax_multiple_choice());
				

				// 문항 번호 순서대로 보기값 저장
				List<TotalChoiceInfoVO> ChoiceInfo = adminService.mcInfoView(paraMap);
				
				//표형문항 라디오 value 설정
				for(int j=0; j < ChoiceInfo.size(); j++ ) {
					ChoiceInfo.get(j).setChoiceNum(j+1);
				}
				
				choiceInfo.add(ChoiceInfo);
			}

			// 문항이 주관식일 경우
			else if (qustionType.equalsIgnoreCase("subjective")) {
				TotalChoiceInfoVO choicesubjective = adminService.scInfoView(paraMap);
				// 문항 번호 순서대로 보기값 저장
				choiceInfo.add(choicesubjective);

			}

			// 문항이 배열(table/matrix)일 경우
			else if (qustionType.equalsIgnoreCase("matrix")) {
				
				
				// 이 질문의 총 표형 질문/보기개수 각각 불러오기, 이 질문의 질문정보에 세팅
				int countMTableQ = adminService.countMtqQ(paraMap);
				int countMTableC = adminService.countMtqC(paraMap);
				
				// jsp에서 forEach End속성에 사용하기 위해 질문 정보에 추가 세팅해줌
				questionInfo.get(i).setMatrix_q_count(countMTableQ - 1);
				questionInfo.get(i).setMatrix_c_count(countMTableC - 1);
				
				//표형문항의 질문정보 담아오기
				List<TotalChoiceInfoVO> matrixTableQuestionInfo = userService.matrixTableQuestionInfoView(paraMap);
				
				//표형문항의 보기 정보 담아오기
				List<TotalChoiceInfoVO> matrixTableChoiceInfo = userService.matrixTableChoiceInfoView(paraMap);
			
				
				//표형문항 라디오 value 설정
				for(int j=0; j < matrixTableChoiceInfo.size(); j++ ) {
					matrixTableChoiceInfo.get(j).setMatrixChoiceNum(j+1);
				}
				
				
				// 한 문항에 대한 정보들이므로 List에 한번에 담기
				List<List<TotalChoiceInfoVO>> mTableInfo = new ArrayList<List<TotalChoiceInfoVO>>();

				// 문항 열/행 각각의 List를 순서대로 담아줌
				mTableInfo.add(matrixTableQuestionInfo);
				mTableInfo.add(matrixTableChoiceInfo);

				// 한번에 담은 List를 문항 번호 순서대로 보기값 저장
				choiceInfo.add(mTableInfo);
			}
		}
		
		//객관식보기 갯수의 최댓값을 List로 만들어서 넘김
		List<Integer> maxChoiceNumList = new ArrayList<Integer>();
		for (int i = 0; i < maxChoiceNum; i++) {
			maxChoiceNumList.add(i);
		}
		
		//표형문항의 질문 갯수의 최댓값을 List로 만들어서 넘김
		List<Integer> maxMatrixQuestionNumList = new ArrayList<Integer>();
		for (int i = 0; i < maxMatrixQuestionNum; i++) {
			maxMatrixQuestionNumList.add(i);
		}
		
		//표형문항의 보기 갯수의 최댓값을 List로 만들어서 넘김
		List<Integer> maxMatrixChoiceNumList = new ArrayList<Integer>();
		for (int i = 0; i <  maxMatrixChoiceNum; i++) {
			maxMatrixChoiceNumList.add(i);
		}
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName(viewName);
		mav.addObject("questionInfo", questionInfo);
		mav.addObject("basicSurveyInfo", basicSurveyInfo);
		mav.addObject("surveyProgress", surveyProgress);
		mav.addObject("choiceInfo", choiceInfo);
		mav.addObject("maxChoiceNumList", maxChoiceNumList);
		mav.addObject("maxMatrixQuestionNumList", maxMatrixQuestionNumList);
		mav.addObject("maxMatrixChoiceNumList", maxMatrixChoiceNumList);
		mav.addObject("page_num", page_num);
		mav.addObject("maxPageNum", maxPageNum);
		return mav;
	}
	
	
	
	//설문지 다음페이지 넘기기
	@Override
	@RequestMapping(value = { "/response_next_page.do" }, method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView response_nextPage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		//설문 응답을 담을 세션 불러오기
		HttpSession userSession = request.getSession(true);
		
		String lastPagenum = (String)request.getParameter("page_num");
		
		//세션에 저장된 페이지 번호/설문지 번호/마지막 페이지번호 객체지정 
		int page_num = Integer.valueOf(lastPagenum);
		String survey_id_num = (String)userSession.getAttribute("survey_id_num");
		int maxPageNum = (int)userSession.getAttribute("maxPageNum");
		
		//응답날짜 저장
		Date date = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String formattedDate = simpleDateFormat.format(date);
		java.sql.Date responseDay = java.sql.Date.valueOf(formattedDate);
		
	
		//유저 답변을 저장할 List 객체 생성
		List<UserVO> surveyResponse = new ArrayList<UserVO>();
		
		//페이지 번호가 1보다 크면 세션에 담긴 객체 리스트를 위에 생성한 List에 추가하기
		if(page_num>1) {
		//유저 답변을 받아줄 리스트를 세션에서 받아오기
		List<UserVO> sessionList = (List)userSession.getAttribute("responseList");
		//세션객체 List >> 유저답변List
		for(int i =0; i<sessionList.size();i++) {
			surveyResponse.add(sessionList.get(i));
			System.out.println(surveyResponse.get(i));
			}
		}
		
		
		//답변 불러오기
		Enumeration<String> params = request.getParameterNames();
		
		//문항번호 : 답변 보여주기
		while (params.hasMoreElements()) {
			 String name = (String)params.nextElement();
			 String userResponse = (String)request.getParameter(name);
			 
			 //name은 문제번호_문제유형 으로 들어옴 
			 //ex)1_multipleChoiceDefault / 2_subjectiveType ...
			 //언더바의 인덱스 번호를 찾은 후 번호 +1 부터가 문항 유형
			 int indexOfUnderbar = name.indexOf("_");
			 
			 //문항 유형 추출
			 String questionType = name.substring(indexOfUnderbar+1);

			 //문항 유형이 객관식일 경우
			 if(questionType.equals("multipleChoiceDefault")) {
				 
				 //문항 번호 추출
				 //index 0부터 _(언더바) 전 까지
				 String Question_id_num = name.substring(0,indexOfUnderbar);
			
				 //설문번호,문항번호,응답날자,응답내용 저장
				 UserVO multipleResponse = new UserVO();
				 multipleResponse.setSurvey_id_num(survey_id_num);
				 multipleResponse.setQuestion_id_num(Question_id_num);
				 multipleResponse.setRespondent_date(responseDay);
				 multipleResponse.setRespondent_multiple(userResponse);
 
				//답변 리스트에 답변정보저장 
				surveyResponse.add(multipleResponse);
				 }
			 
			//문항 유형이 주관식일 경우
			else if(questionType.equals("subjectiveType")) {
				
				 //문항 번호 추출
				 //index 0부터 _(언더바) 전 까지
				 String Question_id_num = name.substring(0,indexOfUnderbar);
				
				//설문번호,문항번호,응답날자,응답내용 저장
				UserVO subjectiveResponse = new UserVO();
				subjectiveResponse.setSurvey_id_num(survey_id_num);
				subjectiveResponse.setQuestion_id_num(Question_id_num);
				subjectiveResponse.setRespondent_date(responseDay);
				subjectiveResponse.setRespondent_subjective(userResponse);
					 
				//답변 리스트에 답변정보저장 
				surveyResponse.add(subjectiveResponse);
				 }
				 
			 //문항 유형이 표형일 경우
			 else if(questionType.equals("multipleChoiceTable")) {
				 
				 
				 //표형문항은 문제번호-보기번호_문향유형 형식으로 들어옴
				 //ex) 3-2_multipleChoiceTable / 4-1_multipleChoiceTable...
				 //하이픈의 위치를 인덱스 번호를 추출해야 문제번호와 보기번호를 구분할 수 있음
				 int indexOfHyphen = name.indexOf("-");
				 
				 //표형문항의 번호
				 //index 0 부터 - (하이픈) 전까지
				 String Question_id_num = name.substring(0, indexOfHyphen);
				 
				 //표형 문항의 문제번호
				 //index - (하이픈)+1 부터 _ (언더바) 전까지
				 String matrix_num =  name.substring(indexOfHyphen+1, indexOfUnderbar);
	 
				 UserVO matrixResponse = new UserVO();
				 matrixResponse.setSurvey_id_num(survey_id_num);
				 matrixResponse.setQuestion_id_num(Question_id_num);
				 matrixResponse.setMatrix_num(matrix_num);
				 matrixResponse.setRespondent_date(responseDay);
				 matrixResponse.setRespondent_multiple(userResponse);
					 
				 //답변 리스트에 답변정보저장 
				 surveyResponse.add(matrixResponse);
				}
		}
		
		//답변 정보를 담은 리스트를 다시 세션객체에 저장
		userSession.setAttribute("responseList", surveyResponse);
		
		
		//mav객체 생성
		ModelAndView mav = new ModelAndView();
		
		
		//마지막페이지가 아니면 다음페이지로 넘기기
		if(page_num<maxPageNum) {
		
			//페이지 번호 +1
		int pagenNum = page_num+1;
		
		mav.setViewName("redirect:/response.do");
		
		//다음페이지에 설문번호 페이지번호 파라미터 넘기기
		mav.addObject("survey_id_num", survey_id_num);
		mav.addObject("page_num", pagenNum);
		}
		
		//마지막 페이지라면 DB에 저장 후 설문 종료문으로 보내기
		else if(page_num==maxPageNum) {
		mav.setViewName("redirect:/response_submit.do");
		}
		return mav;
	}

	
	//설문제출하기 버튼 클릭
	@Override
	@RequestMapping(value = { "/response_submit.do" }, method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView responseSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		//세션객체 불러오기
		HttpSession userSession = request.getSession(true);
		String survey_id_num = (String)userSession.getAttribute("survey_id_num");
		
		//응답정보를 담을 List 생성
		List<UserVO> surveyResponse = new ArrayList<UserVO>();
		
		//유저 답변을 받아줄 리스트를 세션에서 받아오기
		List<UserVO> sessionList = (List<UserVO>)userSession.getAttribute("responseList");
		
		//유저 ID_num을 지정하기 위해 마지막 유저 ID 가져오기
		int userNum = userService.selectUserNum(survey_id_num)+1;
		
		//유저번호 형변환
		String user_num = String.valueOf(userNum);
		
		//세션객체 List >> 유저답변List
		for(int i =0; i<sessionList.size();i++) {
			surveyResponse.add(sessionList.get(i));
			surveyResponse.get(i).setUser_num(user_num);
			System.out.println(surveyResponse.get(i));
			}
		
		//DB에 값 저장
		int result = 0;
		result=userService.insertUserResponse(surveyResponse);		
	
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:/survey_end.do");
		return mav;
	}

	
	//설문종료문
	@Override
	@RequestMapping(value = { "/survey_end.do" }, method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView survey_end_terms(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		//세션객체에서 설문번호 꺼내기
		HttpSession userSession = request.getSession(true);
		String survey_id_num = request.getParameter("survey_id_num");
				//(String)userSession.getAttribute("survey_id_num");
		
		//해당 설문지 설문 종료문 가져오기
		String surveyEndNotice = userService.selectsurveyEndNotice(survey_id_num);
		
		//세션삭제
		userSession.invalidate();
		
		String viewName = (String) request.getAttribute("viewName");
		ModelAndView mav = new ModelAndView();
		mav.setViewName(viewName);
		mav.addObject("surveyEndNotice", surveyEndNotice);
		return mav;
	}
}