package com.main.java.userResponse.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.main.java.composition.vo.TotalQuestionInfoVO;
import com.main.java.composition.vo.TotalChoiceInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.userResponse.vo.UserVO;

@Repository("UserDAO")
public class UserDAOImpl implements UserDAO{
	@Autowired
	private SqlSession sqlSession;
	
	
	@Override
	public List selectSurveyList(BasicSurveyInfoVO basicSurveyInfo) throws DataAccessException {
		List<BasicSurveyInfoVO> mainList = sqlSession.selectList("mapper.userResponse.User.surveyMainList", basicSurveyInfo);
		return mainList;
	}


	@Override
	public BasicSurveyInfoVO selectagreement(String survey_id_num) throws DataAccessException {
		BasicSurveyInfoVO agreement= sqlSession.selectOne("mapper.userResponse.User.selectagreement",survey_id_num);
		return agreement;
		
	}


	@Override
	public List questionInfoView(Map paraMapquestionInfo) throws DataAccessException {
		List <TotalQuestionInfoVO> questionInfo = sqlSession.selectList("mapper.userResponse.User.questionInfoView", paraMapquestionInfo);
		return questionInfo;
	}


	@Override
	public int totalQuestionNum(Map paraMapquestionInfo) throws DataAccessException {
		int result = sqlSession.selectOne("mapper.userResponse.User.totalQuestionNum", paraMapquestionInfo);
		return result;
	}
	
	
	@Override
	public int countQuestion(Map paraMapquestionInfo) throws DataAccessException {
		int result = sqlSession.selectOne("mapper.userResponse.User.countQuestion", paraMapquestionInfo);
		return result;
	}
	

	@Override
	public int maxChoiceNum(String survey_id_num) throws DataAccessException {
		int maxChoiceNum = sqlSession.selectOne("mapper.userResponse.User.maxChoiceNum", survey_id_num);
		return maxChoiceNum;
	}


	@Override
	public int maxMatrixQuestionNum(String survey_id_num) throws DataAccessException {
		int maxMatrixQuestionNum = sqlSession.selectOne("mapper.userResponse.User.maxMatrixQuestionNum", survey_id_num);
		return maxMatrixQuestionNum;
	}


	@Override
	public int maxMatrixChoiceNum(String survey_id_num) throws DataAccessException {
		int maxMatrixChoiceNum = sqlSession.selectOne("mapper.userResponse.User.maxMatrixChoiceNum", survey_id_num);
		return maxMatrixChoiceNum;
	}

	
	public int firstQuestionNumOfPage(Map paraMapquestionInfo) throws DataAccessException {
		int result = sqlSession.selectOne("mapper.userResponse.User.firstQuestionNumOfPage", paraMapquestionInfo);
		return result;
	}
	

	@Override
	public List matrixTableQuestionInfoView(Map paraMap) throws DataAccessException {
		List <TotalChoiceInfoVO> matrixTableQuestionInfoView = sqlSession.selectList("mapper.userResponse.User.matrixTableQuestionInfoView", paraMap);
		return matrixTableQuestionInfoView;
	}


	@Override
	public List matrixTableChoiceInfoView(Map paraMap) throws DataAccessException {
		List <TotalChoiceInfoVO> matrixTableChoiceInfoView = sqlSession.selectList("mapper.userResponse.User.matrixTableChoiceInfoView", paraMap);
		return matrixTableChoiceInfoView;
	}


	@Override
	public int maxPageNum(String survey_id_num) throws DataAccessException {
		int maxPageNum = sqlSession.selectOne("mapper.userResponse.User.maxPageNum", survey_id_num);
		return maxPageNum;
	}


	@Override
	public int insertUserResponse(List surveyResponse) throws DataAccessException {
		int insertUserResponse = sqlSession.insert("mapper.userResponse.User.insertUserResponse", surveyResponse);
		return insertUserResponse;
	}


	@Override
	public int selectUserNum(String survey_id_num) throws DataAccessException {
		int selectUserNum = sqlSession.selectOne("mapper.userResponse.User.selectUserNum", survey_id_num);
		return selectUserNum;
	}


	@Override
	public String selectsurveyEndNotice(String survey_id_num) throws DataAccessException {
		String selectsurveyEndNotice =  sqlSession.selectOne("mapper.userResponse.User.selectsurveyEndNotice", survey_id_num);
		return selectsurveyEndNotice;
	}


}
