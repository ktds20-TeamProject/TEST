package com.main.java.composition.vo;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Component("MultipleChoiceVO")
public class MultipleChoiceVO 
{
	private String survey_id_num;       // 설문 식별번호
	private String page_num;            // 페이지 번호        : 페이지가 여러 개이다.
	private String question_id_num;     // 질문 식별번호      : 페이지가 여러 개이며, 페이지별 질문이 여러 개이다.
	private String choice_type;			// 질문 유형		  : 페이지가 여러 개이며, 페이지별 질문이 여러 개이다.
	private String choice_count;        // 보기 개수          : 페이지가 여러 개이며, 페이지별 질문이 여러 개이다.
	private String is_other_choice;     // 기타 응답 여부     : 페이지가 여러 개이며, 페이지별 질문이 여러 개이다.
	private String min_multiple_choice; // 객관식 최소 답변수 : 페이지가 여러 개이며, 페이지별 질문이 여러 개이다.
	private String max_multiple_choice; // 객관식 최대 답변수 : 페이지가 여러 개이며, 페이지별 질문이 여러 개이다.
}