package com.main.java.admin.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.main.java.admin.vo.AdminVO;
import com.main.java.composition.vo.TotalChoiceInfoVO;
import com.main.java.composition.vo.TotalQuestionInfoVO;
import com.main.java.survey.vo.AddressInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.userResponse.vo.TotalUserSurveyVO;

@Repository("adminDAO")
public class AdminDAOImpl implements AdminDAO{
	@Autowired
	private SqlSession sqlSession;

	//로그인
	@Override
	public AdminVO login(AdminVO adminVO) throws DataAccessException{
		AdminVO vo = sqlSession.selectOne("mapper.admin.adminMapper.login", adminVO);
		return vo;
	}
	
	//회원가입
	@Override
	public int insertAdmin(AdminVO adminVO) throws DataAccessException {
		int result = sqlSession.insert("mapper.admin.adminMapper.insertAdmin", adminVO);
		return result;
	}
	
	//비밀번호 체크
	@Override
	public AdminVO pwCheck(AdminVO adminVO) throws DataAccessException {
		AdminVO vo = sqlSession.selectOne("mapper.admin.adminMapper.login", adminVO);
		return vo;
	}
	
	//회원정보 수정
	@Override
	public int updateAdmin(AdminVO adminVO) throws DataAccessException {
		int result = sqlSession.update("mapper.admin.adminMapper.updateAdmin", adminVO);
		return result;
	}
	
	//회원정보 수정화면에 기존 정보 출력 (회원의 모든 정보 불러오기)
	@Override
	public AdminVO infoView(AdminVO adminVO) throws DataAccessException {
		AdminVO vo = sqlSession.selectOne("mapper.admin.adminMapper.infoView", adminVO);
		return vo;
	}
	
	//아이디 중복확인
	@Override
	public int idDuplicated(String adminId) throws DataAccessException {
		int data = (Integer) sqlSession.selectOne("mapper.admin.adminMapper.idDuplicated", adminId);
		return data;
	}
	
	//회원탈퇴
	@Override
	public int deleteAdmin(AdminVO adminVO) throws DataAccessException {
		int result = sqlSession.delete("mapper.admin.adminMapper.deleteAdmin", adminVO);
		return result;
	}
	//아이디 찾기
	@Override
	public List<String> selectAllResult(AdminVO admin) throws DataAccessException {
		List<String> result= sqlSession.selectList("mapper.admin.adminMapper.findId", admin);
		System.out.println("DAO:"+result);
		return result;	
	}	
	
	//비밀번호 찾기 유효성 검증
	@Override
	public AdminVO findPwCheck(AdminVO adminVO) throws DataAccessException {
		AdminVO vo = sqlSession.selectOne("mapper.admin.adminMapper.findPwCheck", adminVO);
		return vo;
	}
	
	//비밀번호 찾기 메일 전송용
	@Override
	public AdminVO findPwSendMail(String adminId) throws DataAccessException {
		AdminVO vo = sqlSession.selectOne("mapper.admin.adminMapper.findPwSendMail", adminId);
		return vo;
	}
	
	//관리자 메인 검색 전후 레코드 개수
	@Override
	public int surveyListCount(BasicSurveyInfoVO basicSurveyInfoVO) {
		return this.sqlSession.selectOne("mapper.survey.surveyListCount", basicSurveyInfoVO);
	}
	
	//관리자 설문 관리 리스트
	@Override
	public List surveyMainList(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException {
		List<BasicSurveyInfoVO> mainList = null;//BasicSurveyInfoVO의 정보를 받아옴
		mainList = sqlSession.selectList("mapper.survey.surveyMainList", basicSurveyInfoVO);
		//System.out.println("dao"+mainList);
		return mainList;
	}
	//설문삭제
	@Override
	public void SurveyDelete(String survey_id_num) throws DataAccessException {
		sqlSession.delete("mapper.survey.deleteSurvey", survey_id_num);
	}	
	
    	//통계 - 설문 기본 정보 조회
		@Override
		public BasicSurveyInfoVO surveyInfoView(String survey_id_num) throws DataAccessException {
			BasicSurveyInfoVO vo = sqlSession.selectOne("mapper.survey.surveyInfoView", survey_id_num);
			return vo;
		}
		
		//통계 - 질문 개수 카운트
		@Override
		public int countQuestion(String survey_id_num) throws DataAccessException {
			int result = sqlSession.selectOne("mapper.survey.countQuestion", survey_id_num);
			return result;
		}
		
		//통계 - 응답 개수 카운트
			@Override
			public int countResponse(String survey_id_num) throws DataAccessException {
				int result = sqlSession.selectOne("mapper.survey.countResponse", survey_id_num);
				return result;
			}
			
		//통계 - 질문 기본 정보 조회
		@Override
		public List questionInfoView(String survey_id_num) throws DataAccessException {
			List <TotalQuestionInfoVO> vo = sqlSession.selectList("mapper.survey.questionInfoView", survey_id_num);
			return vo;
		}
		
		//통계 - 객관식 보기 질문정보 조회
		@Override
		public TotalQuestionInfoVO MqInfoView(Map paraMap) throws DataAccessException {
			TotalQuestionInfoVO vo = sqlSession.selectOne("mapper.survey.MqInfoView", paraMap);
			return vo;
		}
		
		//통계 - 객관식 보기 개수 카운트
		@Override
		public int countMqC(Map paraMap) throws DataAccessException {
			int result = sqlSession.selectOne("mapper.survey.countMqC", paraMap);
			return result;
		}
		
		//통계 - 객관식 보기 정보 조회
		@Override
		public List mcInfoView(Map paraMap) throws DataAccessException {
			List <TotalChoiceInfoVO> vo = sqlSession.selectList("mapper.survey.mcInfoView", paraMap);
			return vo;
		}
		
		//통계 - 주관식 중복 여부 정보 조회
		@Override
		public TotalChoiceInfoVO scInfoView(Map paraMap) throws DataAccessException {
			TotalChoiceInfoVO vo = sqlSession.selectOne("mapper.survey.scInfoView", paraMap);
			return vo;
		}
		
		//통계 - 객관식 표형 질문 개수 카운트
		@Override
		public int countMtqQ(Map paraMap) throws DataAccessException {
			int result = sqlSession.selectOne("mapper.survey.countMtqQ", paraMap);
			return result;
		}
		
		//통계 - 객관식 표형 보기 개수 카운트
		@Override
		public int countMtqC(Map paraMap) throws DataAccessException {
			int result = sqlSession.selectOne("mapper.survey.countMtqC", paraMap);
			return result;
		}
		
		//통계 - 객관식 표형 질문 정보 조회
		@Override
		public List mTableQInfoView(Map paraMap) throws DataAccessException {
			List <TotalChoiceInfoVO> vo = sqlSession.selectList("mapper.survey.mTableQInfoView", paraMap);
			return vo;
		}
		
		//통계 - 객관식 표형 보기 정보 조회
		@Override
		public List mTableCInfoView(Map paraMap) throws DataAccessException {
			List <TotalChoiceInfoVO> vo = sqlSession.selectList("mapper.survey.mTableCInfoView", paraMap);
			return vo;
		}
		
		//통계 - 객관식 개별 응답 정보 조회
		@Override
		public TotalUserSurveyVO mResponseView(Map paraMap)  throws DataAccessException {
			TotalUserSurveyVO vo = sqlSession.selectOne("mapper.survey.mResponseView", paraMap);
			return vo;
		}
		
		//통계 - 객관식/주관식 총 응답 수 조회
		@Override
		public int CountMResponse(Map paraMap) throws DataAccessException {
			int result = sqlSession.selectOne("mapper.survey.CountMResponse", paraMap);
			return result;
		}
		
		//통계 - 주관식 개별 응답 정보 조회
		@Override
		public List sResponseView(Map paraMap)  throws DataAccessException {
			List <TotalUserSurveyVO> vo = sqlSession.selectList("mapper.survey.sResponseView", paraMap);
			return vo;
		}
		
		//통계 - 표형 총 응답 수 조회
		@Override
		public int CountMTResponse(Map paraMap) throws DataAccessException {
			int result = sqlSession.selectOne("mapper.survey.CountMTResponse", paraMap);
			return result;
		}
		
		//통계 - 표형 개별 응답 정보 조회
		@Override
		public TotalUserSurveyVO mTableResponseView(Map paraMap)  throws DataAccessException {
			TotalUserSurveyVO vo = sqlSession.selectOne("mapper.survey.mTableResponseView", paraMap);
			return vo;
		}
		@Override
	      public List selectAddressList(String survey_id_num) throws DataAccessException {
	         List<AddressInfoVO> addressList = null;
	         addressList = sqlSession.selectList("mapper.survey.selectAddressList", survey_id_num);
	         return addressList;
	      }		
}
