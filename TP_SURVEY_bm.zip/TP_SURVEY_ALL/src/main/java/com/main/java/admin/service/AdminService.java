package com.main.java.admin.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.dao.DataAccessException;

import com.main.java.admin.vo.AdminVO;
import com.main.java.composition.vo.TotalChoiceInfoVO;
import com.main.java.composition.vo.TotalQuestionInfoVO;
import com.main.java.survey.vo.BasicSurveyInfoVO;
import com.main.java.userResponse.vo.TotalUserSurveyVO;

public interface AdminService {
	
	public AdminVO login(AdminVO adminVO) throws Exception;	//로그인
	public int join(AdminVO admin) throws DataAccessException;	//회원가입
	public AdminVO pwCheck(AdminVO adminVO) throws Exception;	//비밀번호 체크
	public int adminUpdate(AdminVO admin) throws DataAccessException;	//회원정보 수정
	public AdminVO infoView(AdminVO adminVO) throws Exception;	//회원정보 수정화면에 기존 정보 출력
	public int idDuplicated(String adminId);	//아이디 중복확인
	public int deleteAdmin(AdminVO admin) throws DataAccessException;	//회원탈퇴
	public List<String> admin_find_id(AdminVO admin) throws Exception; //아이디 찾기	
	public AdminVO findPwCheck(AdminVO admin) throws Exception;	//비밀번호 찾기 유효성 검증
	public void findPwSendMail(String adminId, String email, HttpServletRequest request) throws Exception;	//비밀번호 찾기 이메일 발송
	public int surveyListCount(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException; //관리자 메인 검색 전후 레코드 개수	
	public List admin_list(BasicSurveyInfoVO basicSurveyInfoVO) throws DataAccessException; //관리자 설문 관리 리스트	

	public BasicSurveyInfoVO surveyInfoView(String survey_id_num) throws Exception;  //통계 - 설문 기본 정보 조회
	public int countQuestion(String survey_id_num) throws Exception; //통계 - 질문 개수 카운트
	public int countResponse(String survey_id_num) throws Exception; //통계 - 응답 개수 카운트
	public List <TotalQuestionInfoVO> questionInfoView(String survey_id_num) throws Exception; //통계 - 질문 기본 정보 조회
	public TotalQuestionInfoVO MqInfoView(Map paraMap) throws Exception; //통계 - 객관식 보기 질문정보 조회
	public int countMqC(Map paraMap) throws Exception; //통계 - 객관식 보기 개수 카운트
	public List <TotalChoiceInfoVO> mcInfoView(Map paraMap) throws Exception; //통계 - 객관식 보기 정보 조회
	public TotalChoiceInfoVO scInfoView(Map paraMap) throws Exception; //통계 - 주관식 중복 여부 정보 조회
	public int countMtqQ(Map paraMap) throws Exception; //통계 - 객관식 표형 질문 개수 카운트
	public int countMtqC(Map paraMap) throws Exception; //통계 - 객관식 표형 보기 개수 카운트
	public List <TotalChoiceInfoVO> mTableQInfoView(Map paraMap) throws Exception; //통계 - 객관식 표형 질문 정보 조회
	public List <TotalChoiceInfoVO> mTableCInfoView(Map paraMap) throws Exception; //통계 - 객관식 표형 보기 정보 조회
	public TotalUserSurveyVO mResponseView(Map paraMap) throws Exception; //통계 - 객관식 개별 응답 정보 조회
	public int CountMResponse(Map paraMap) throws Exception; //통계 - 객관식/주관식 총 응답 수 조회
	public List <TotalUserSurveyVO> sResponseView(Map paraMap) throws Exception; //통계 - 주관식 개별 응답 정보 조회
	public int CountMTResponse(Map paraMap) throws Exception; //통계 - 표형 총 응답 수 조회
	public TotalUserSurveyVO mTableResponseView(Map paraMap) throws Exception; //통계 - 표형 개별 응답 정보 조회
	public void deleteSurvey(String survey_id_num) throws Exception;//설문 삭제
	public List listAddress(String survey_id_num) throws DataAccessException; //관리자 주소록 조회 리스트	
	
	
}